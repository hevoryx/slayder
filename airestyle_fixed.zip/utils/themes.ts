import { Theme } from '../types';

export const DEFAULT_THEME_ID = 'academic_navy';
const THEME_STORAGE_KEY = 'ai_slayd_selected_theme';

export const THEMES: Record<string, Theme> = {
  minimalist_light: {
    id: 'minimalist_light',
    name: 'Minimalist Light',
    style: 'minimalist',
    isDark: false,
    colors: {
      primary: '#0f172a',
      secondary: '#334155',
      accent: '#2563eb',
      background: '#ffffff',
      text: '#0f172a',
      textLight: '#64748b',
    },
    font: 'Plus Jakarta Sans',
  },
  academic_navy: {
    id: 'academic_navy',
    name: 'Academic Classic',
    style: 'academic',
    isDark: false,
    colors: {
      primary: '#1e3a8a',
      secondary: '#172554',
      accent: '#0284c7',
      background: '#f8fafc',
      text: '#0f172a',
      textLight: '#475569',
    },
    font: 'Plus Jakarta Sans',
  },
  corporate_slate: {
    id: 'corporate_slate',
    name: 'Corporate Executive',
    style: 'corporate',
    isDark: false,
    colors: {
      primary: '#0f172a',
      secondary: '#1e293b',
      accent: '#0d9488',
      background: '#ffffff',
      text: '#1e293b',
      textLight: '#475569',
    },
    font: 'Plus Jakarta Sans',
  },
  modern_blue: {
    id: 'modern_blue',
    name: 'Modern Azure',
    style: 'modern',
    isDark: false,
    colors: {
      primary: '#2563eb',
      secondary: '#1e3a8a',
      accent: '#0284c7',
      background: '#ffffff',
      text: '#0f172a',
      textLight: '#475569',
    },
    font: 'Plus Jakarta Sans',
  },
  minimal_dark: {
    id: 'minimal_dark',
    name: 'Executive Dark',
    style: 'dark',
    isDark: true,
    colors: {
      primary: '#f8fafc',
      secondary: '#e2e8f0',
      accent: '#38bdf8',
      background: '#090d16',
      text: '#f1f5f9',
      textLight: '#cbd5e1',
    },
    font: 'Plus Jakarta Sans',
  },
  nature_green: {
    id: 'nature_green',
    name: 'Clean Light Green',
    style: 'light',
    isDark: false,
    colors: {
      primary: '#059669',
      secondary: '#064e3b',
      accent: '#10b981',
      background: '#f0fdf4',
      text: '#064e3b',
      textLight: '#065f46',
    },
    font: 'Plus Jakarta Sans',
  },
  scientific_cyan: {
    id: 'scientific_cyan',
    name: 'Scientific Journal',
    style: 'scientific',
    isDark: false,
    colors: {
      primary: '#0e7490',
      secondary: '#164e63',
      accent: '#0284c7',
      background: '#f8fafc',
      text: '#0f172a',
      textLight: '#334155',
    },
    font: 'Plus Jakarta Sans',
  },
  midnight_gold: {
    id: 'midnight_gold',
    name: 'Midnight Gold',
    style: 'dark',
    isDark: true,
    colors: {
      primary: '#fbbf24',
      secondary: '#fde68a',
      accent: '#f59e0b',
      background: '#0f172a',
      text: '#f8fafc',
      textLight: '#cbd5e1',
    },
    font: 'Plus Jakarta Sans',
  },
};

export const DEFAULT_THEME: Theme = THEMES[DEFAULT_THEME_ID];

export const isValidTheme = (value: unknown): value is Theme => {
  if (typeof value !== 'object' || value === null) return false;
  const candidate = value as Partial<Theme>;
  if (
    typeof candidate.id !== 'string' ||
    typeof candidate.name !== 'string' ||
    typeof candidate.font !== 'string' ||
    typeof candidate.colors !== 'object' ||
    candidate.colors === null
  ) {
    return false;
  }

  const colors = candidate.colors as Partial<Theme['colors']>;
  return (
    typeof colors.primary === 'string' &&
    typeof colors.secondary === 'string' &&
    typeof colors.accent === 'string' &&
    typeof colors.background === 'string' &&
    typeof colors.text === 'string' &&
    typeof colors.textLight === 'string'
  );
};

export const getTheme = (id: unknown): Theme => {
  if (typeof id === 'string' && Object.prototype.hasOwnProperty.call(THEMES, id)) {
    const matched = THEMES[id];
    if (isValidTheme(matched)) {
      return matched;
    }
  }
  return DEFAULT_THEME;
};

export const resolveTheme = (themeOrId: unknown): Theme => {
  if (isValidTheme(themeOrId)) {
    return getTheme(themeOrId.id);
  }
  return getTheme(themeOrId);
};

export const loadSavedTheme = (): Theme => {
  if (typeof window === 'undefined' || !window.localStorage) {
    return DEFAULT_THEME;
  }
  try {
    const raw = window.localStorage.getItem(THEME_STORAGE_KEY);
    if (!raw) return DEFAULT_THEME;
    if (Object.prototype.hasOwnProperty.call(THEMES, raw)) {
      return getTheme(raw);
    }
    const parsed: unknown = JSON.parse(raw);
    if (isValidTheme(parsed)) return getTheme(parsed.id);
    return DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
};

export const saveThemeId = (id: unknown): void => {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    const validTheme = getTheme(id);
    window.localStorage.setItem(THEME_STORAGE_KEY, validTheme.id);
  } catch {
    // ignore
  }
};
