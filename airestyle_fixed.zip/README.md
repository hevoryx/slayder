<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/87a46f1a-c526-41a1-88b6-b2ef08cbcbec

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Kurs ishi rejimi (Course work mode)

Yuqoridagi **Kurs ishi** tugmasi orqali ochiladi.

- Mavzu, fan, hajm (20–40 bet), boblar soni (2–4) va til (O'zbek / English / Русский) tanlanadi.
- AI avval reja tuzadi, so'ng kirish, har bir bo'lim, xulosa va adabiyotlar ro'yxatini alohida yozadi.
- Natijani saytning o'zida tahrirlash, istalgan bo'limni "Qayta yozish" mumkin.
- **Word (.docx)** formatida yuklab olinadi: A4, Times New Roman 14, 1,5 interval, chap 30 mm / o'ng 15 mm / yuqori va past 20 mm, titul varag'i, mundarija, bet raqamlari.
- O'zbek matnida `oʻ`, `gʻ` va tutuq belgisi (`ʼ`) avtomatik to'g'rilanadi.

Eslatma: Word faylni ochganda "maydonlarni yangilash" so'ralsa "Ha" ni bosing (mundarija shu bilan to'ladi). Adabiyotlar ro'yxatini albatta o'zingiz tekshiring.

Yangi fayllar: `components/Coursework*.tsx`, `services/courseworkService.ts`, `utils/docxGenerator.ts`, `utils/courseworkPrompts.ts`, `utils/courseworkTranslations.ts`. `npm install` yangi `docx` paketini o'rnatadi.

## Gemini API kaliti (muhim)

`.env` (yoki hosting "Environment settings") ichiga yozing:

```
AI_PROVIDER=gemini
GEMINI_API_KEY=<sizning kalitingiz>
```

- `AIza...` bilan boshlanadigan kalit — Google AI Studio kaliti.
- `AQ....` bilan boshlanadigan kalit — Vertex AI Express Mode kaliti. Server buni avtomatik aniqlaydi va `vertexai: true` rejimida ishlatadi. Kerak bo'lsa `GEMINI_USE_VERTEX=true|false` bilan majburlash mumkin.
- Auth xatosi (401/403) bo'lsa server ikkinchi rejimni ham bir marta sinab ko'radi.
- Tekshirish: admin sifatida kirib `GET /api/ai/test?provider=gemini` ni oching — kalit ishlayotganini va rejimni ko'rsatadi.

## Yangi: Study Boost (AI)

Menyuda "Study Boost (AI)": matnni konspekt qilish, flashcard yaratish, paraphrase / grammatika / akademik uslubga o'tkazish.
Endpointlar: `/api/study/summarize`, `/api/study/flashcards`, `/api/study/rewrite`, `/api/ai/test`.
