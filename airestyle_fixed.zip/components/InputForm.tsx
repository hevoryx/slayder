import React, { useState } from 'react';
import { ArrowRight, Layers, ListOrdered, Globe, FileText, Presentation } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface InputFormProps {
  onGenerate: (
    topic: string,
    slideCount: number,
    planCount: number,
    language: Language,
    description?: string
  ) => void;
  isProcessing: boolean;
  onLanguageChange: (lang: Language) => void;
  currentLang: Language;
}

export const InputForm: React.FC<InputFormProps> = ({
  onGenerate,
  isProcessing,
  onLanguageChange,
  currentLang,
}) => {
  const [topic, setTopic] = useState('');
  const [description, setDescription] = useState('');
  const [slideCount, setSlideCount] = useState(10);
  const [planCount, setPlanCount] = useState(4);

  const t = translations[currentLang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim() && slideCount > 0) {
      onGenerate(topic.trim(), slideCount, planCount, currentLang, description);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6 md:p-10 bg-white rounded-2xl border border-slate-200 shadow-sm">
      <div className="mb-8">
        <div className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-indigo-50 text-indigo-600 mb-4 border border-indigo-100">
          <Presentation className="w-5 h-5" />
        </div>
        <h1 className="font-display text-2xl md:text-3xl font-bold text-slate-900 tracking-tight mb-2 [text-wrap:balance]">
          {t.headerTitle}
        </h1>
        <p className="text-sm md:text-base text-slate-600 leading-relaxed">
          {t.inputSubtitle}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label
            htmlFor="topic"
            className="block text-sm font-semibold text-slate-800 mb-2"
          >
            {t.inputTopicLabel}
          </label>
          <input
            id="topic"
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t.inputTopicPlaceholder}
            maxLength={300}
            className="w-full px-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none transition-all text-sm md:text-base placeholder:text-slate-400"
            required
            disabled={isProcessing}
          />
        </div>

        <div>
          <label
            htmlFor="description"
            className="flex items-center gap-1.5 text-sm font-semibold text-slate-800 mb-2"
          >
            <FileText className="w-4 h-4 text-slate-500" />
            <span>{t.inputDescLabel}</span>
          </label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder={t.inputDescPlaceholder}
            maxLength={1000}
            rows={3}
            className="w-full px-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none transition-all text-sm md:text-base placeholder:text-slate-400 resize-none"
            disabled={isProcessing}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
          <div>
            <label
              htmlFor="language"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.inputLangLabel}</span>
            </label>
            <select
              id="language"
              value={currentLang}
              onChange={(e) => onLanguageChange(e.target.value as Language)}
              className="w-full px-3 py-2.5 bg-white text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none cursor-pointer text-sm"
              disabled={isProcessing}
            >
              <option value="uz">O'zbek</option>
              <option value="en">English</option>
              <option value="ru">Русский</option>
            </select>
          </div>

          <div>
            <label
              htmlFor="slideCount"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2"
            >
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.inputSlidesLabel}</span>
            </label>
            <select
              id="slideCount"
              value={slideCount}
              onChange={(e) => setSlideCount(Number(e.target.value))}
              className="w-full px-3 py-2.5 bg-white text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none cursor-pointer text-sm tabular-nums"
              disabled={isProcessing}
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={15}>15</option>
              <option value={20}>20</option>
              <option value={25}>25</option>
              <option value={30}>30</option>
            </select>
          </div>

          <div>
            <label
              htmlFor="planCount"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2"
            >
              <ListOrdered className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.inputPlanLabel}</span>
            </label>
            <select
              id="planCount"
              value={planCount}
              onChange={(e) => setPlanCount(Number(e.target.value))}
              className="w-full px-3 py-2.5 bg-white text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none cursor-pointer text-sm tabular-nums"
              disabled={isProcessing}
            >
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={isProcessing || !topic.trim()}
          className={`w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl text-white font-semibold text-sm md:text-base transition-all whitespace-nowrap ${
            isProcessing || !topic.trim()
              ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] cursor-pointer shadow-sm'
          }`}
        >
          <span>{isProcessing ? t.btnGenerating : t.btnGenerate}</span>
          {!isProcessing && <ArrowRight className="w-4 h-4" />}
        </button>
      </form>
    </div>
  );
};
