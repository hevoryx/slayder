import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import type {
  AcademicTask,
  AssistantChat,
  Language,
  PlatformConfig,
  StudyProgress,
  SubscriptionPlan,
  SystemLog,
  UserProfile,
  UserRole,
  WorkspaceItem,
  WorkspaceType,
  WorkspaceVersion,
} from '../../types';

const makeId = (prefix: string): string => {
  const rand =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 16)
      : Math.random().toString(36).slice(2, 14);
  return `${prefix}_${Date.now().toString(36)}_${rand}`.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
};

const clampStr = (val: unknown, max: number, fallback = ''): string => {
  if (typeof val !== 'string') return fallback;
  return val.trim().slice(0, max);
};

/* ------------------------------------------------------------------ */
/* Users & Admin                                                      */
/* ------------------------------------------------------------------ */

export const BOOTSTRAP_ADMIN_EMAIL = 'vickgang87@gmail.com';

export async function syncUserProfile(params: {
  uid: string;
  email: string;
  displayName: string;
  photoUrl?: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const path = `users/${params.uid}`;
  try {
    const ref = doc(db, 'users', params.uid);
    const snap = await getDoc(ref);
    const isBootstrap = params.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL;

    if (snap.exists()) {
      const existing = snap.data() as UserProfile;
      return existing;
    }

    const newProfile: Record<string, unknown> = {
      uid: params.uid,
      email: clampStr(params.email, 254, 'student@university.uz'),
      displayName: clampStr(params.displayName, 120, 'University Student'),
      role: isBootstrap ? 'admin' : 'student',
      plan: isBootstrap ? 'university' : 'free',
      preferredLanguage: params.preferredLanguage,
      university: '',
      faculty: '',
      academicLevel: 'undergraduate',
      aiRequestsUsed: 0,
      aiMonthlyLimit: isBootstrap ? 10000 : 100,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (params.photoUrl) {
      newProfile.photoUrl = clampStr(params.photoUrl, 500);
    }

    await setDoc(ref, newProfile);
    const created = await getDoc(ref);
    return created.data() as UserProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateUserProfile(
  uid: string,
  updates: Partial<Pick<UserProfile, 'displayName' | 'preferredLanguage' | 'university' | 'faculty' | 'academicLevel'>>
): Promise<void> {
  const path = `users/${uid}`;
  try {
    const ref = doc(db, 'users', uid);
    const payload: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (updates.displayName !== undefined) payload.displayName = clampStr(updates.displayName, 120, 'Student');
    if (updates.preferredLanguage !== undefined) payload.preferredLanguage = updates.preferredLanguage;
    if (updates.university !== undefined) payload.university = clampStr(updates.university, 200);
    if (updates.faculty !== undefined) payload.faculty = clampStr(updates.faculty, 200);
    if (updates.academicLevel !== undefined) payload.academicLevel = updates.academicLevel;
    await updateDoc(ref, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function incrementUserAiUsage(uid: string): Promise<void> {
  const path = `users/${uid}`;
  try {
    const ref = doc(db, 'users', uid);
    await updateDoc(ref, {
      aiRequestsUsed: increment(1),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function checkIsAdminMarker(uid: string): Promise<boolean> {
  const path = `admins/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'admins', uid));
    return snap.exists();
  } catch {
    return false;
  }
}

export async function listAllUsersAdmin(): Promise<UserProfile[]> {
  const path = 'users';
  try {
    const snap = await getDocs(query(collection(db, path), limit(100)));
    return snap.docs.map((d) => d.data() as UserProfile);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function adminUpdateUser(
  targetUid: string,
  targetEmail: string,
  adminUid: string,
  updates: { role: UserRole; plan: SubscriptionPlan; aiMonthlyLimit: number }
): Promise<void> {
  const path = `users/${targetUid}`;
  try {
    await updateDoc(doc(db, 'users', targetUid), {
      role: updates.role,
      plan: updates.plan,
      aiMonthlyLimit: Math.max(1, Math.min(1000000, Math.round(updates.aiMonthlyLimit))),
      updatedAt: serverTimestamp(),
    });
    if (updates.role === 'admin') {
      await setDoc(doc(db, 'admins', targetUid), {
        uid: targetUid,
        email: clampStr(targetEmail, 254),
        grantedBy: adminUid,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/* ------------------------------------------------------------------ */
/* Platform Config (Global)                                           */
/* ------------------------------------------------------------------ */

export const DEFAULT_PLATFORM_CONFIG: PlatformConfig = {
  activeModel: 'openai/gpt-oss-20b',
  announcement: '',
  announcementActive: false,
  defaultMonthlyLimit: 100,
  disabledTools: [],
  enabledLanguages: ['uz', 'ru', 'en', 'kaa', 'kk'],
};

export function subscribePlatformConfig(
  onChange: (config: PlatformConfig) => void
): Unsubscribe {
  const path = 'platformConfig/global';
  return onSnapshot(
    doc(db, 'platformConfig', 'global'),
    (snap) => {
      if (snap.exists()) {
        onChange({ ...DEFAULT_PLATFORM_CONFIG, ...(snap.data() as Partial<PlatformConfig>) });
      } else {
        onChange(DEFAULT_PLATFORM_CONFIG);
      }
    },
    (error) => {
      // Non-admins read only when signed in; if rules deny before auth, fall back silently
      console.warn('PlatformConfig listener:', error.message);
      onChange(DEFAULT_PLATFORM_CONFIG);
    }
  );
}

export async function savePlatformConfig(config: Omit<PlatformConfig, 'updatedAt'>): Promise<void> {
  const path = 'platformConfig/global';
  try {
    await setDoc(doc(db, 'platformConfig', 'global'), {
      activeModel: clampStr(config.activeModel, 80, 'gemini-4-hydrogen'),
      announcement: clampStr(config.announcement, 600),
      announcementActive: Boolean(config.announcementActive),
      defaultMonthlyLimit: Math.max(1, Math.min(1000000, Math.round(config.defaultMonthlyLimit))),
      disabledTools: config.disabledTools.slice(0, 30),
      enabledLanguages: config.enabledLanguages.length > 0 ? config.enabledLanguages.slice(0, 15) : ['uz'],
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/* ------------------------------------------------------------------ */
/* System Logs (Analytics & Error Review)                             */
/* ------------------------------------------------------------------ */

export async function recordSystemLog(entry: {
  userId: string;
  userEmail?: string;
  tool: string;
  model: string;
  status: 'ok' | 'error';
  tokens: number;
  errorMessage?: string;
}): Promise<void> {
  const logId = makeId('log');
  const path = `systemLogs/${logId}`;
  try {
    const payload: Record<string, unknown> = {
      userId: entry.userId,
      tool: clampStr(entry.tool, 80, 'ai'),
      model: clampStr(entry.model, 80, 'gemini-4-hydrogen'),
      status: entry.status,
      tokens: Math.max(0, Math.min(2000000, Math.round(entry.tokens || 0))),
      createdAt: serverTimestamp(),
    };
    if (entry.userEmail) payload.userEmail = clampStr(entry.userEmail, 254);
    if (entry.errorMessage) payload.errorMessage = clampStr(entry.errorMessage, 500);
    await setDoc(doc(db, 'systemLogs', logId), payload);
  } catch (error) {
    console.warn('Failed to write system log:', error);
  }
}

export async function listSystemLogs(userId?: string): Promise<SystemLog[]> {
  const path = 'systemLogs';
  try {
    const q = userId
      ? query(collection(db, path), where('userId', '==', userId), orderBy('createdAt', 'desc'), limit(50))
      : query(collection(db, path), orderBy('createdAt', 'desc'), limit(100));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<SystemLog, 'id'>) }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

/* ------------------------------------------------------------------ */
/* Workspaces (Documents, Versions, Folders)                          */
/* ------------------------------------------------------------------ */

export function subscribeWorkspaces(
  userId: string,
  onData: (items: WorkspaceItem[]) => void
): Unsubscribe {
  const path = 'workspaces';
  const q = query(
    collection(db, path),
    where('userId', '==', userId),
    orderBy('updatedAt', 'desc'),
    limit(100)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<WorkspaceItem, 'id'>) })));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveWorkspaceItem(params: {
  id?: string;
  userId: string;
  title: string;
  type: WorkspaceType;
  docSubtype?: string;
  folder?: string;
  language: Language;
  summary?: string;
  content: Record<string, unknown>;
  versionNote?: string;
}): Promise<string> {
  const docId = params.id || makeId('ws');
  const path = `workspaces/${docId}`;
  try {
    const ref = doc(db, 'workspaces', docId);
    const existingSnap = params.id ? await getDoc(ref) : null;

    if (existingSnap && existingSnap.exists()) {
      const prev = existingSnap.data() as WorkspaceItem;
      const nextVersion = (prev.versionCount || 1) + 1;
      await updateDoc(ref, {
        title: clampStr(params.title, 240, 'Untitled'),
        folder: clampStr(params.folder || prev.folder || 'General', 80, 'General'),
        language: params.language,
        summary: clampStr(params.summary || '', 1000),
        content: params.content,
        versionCount: nextVersion,
        updatedAt: serverTimestamp(),
      });
      const verId = makeId('ver');
      await setDoc(doc(db, 'workspaces', docId, 'versions', verId), {
        userId: params.userId,
        versionNumber: nextVersion,
        note: clampStr(params.versionNote || `Updated v${nextVersion}`, 200),
        content: params.content,
        createdAt: serverTimestamp(),
      });
      return docId;
    }

    const docPayload: Record<string, unknown> = {
      userId: params.userId,
      title: clampStr(params.title, 240, 'Untitled'),
      type: params.type,
      folder: clampStr(params.folder || 'General', 80, 'General'),
      language: params.language,
      summary: clampStr(params.summary || '', 1000),
      content: params.content,
      versionCount: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (params.docSubtype) {
      docPayload.docSubtype = clampStr(params.docSubtype, 80);
    }

    await setDoc(ref, docPayload);
    const verId = makeId('ver');
    await setDoc(doc(db, 'workspaces', docId, 'versions', verId), {
      userId: params.userId,
      versionNumber: 1,
      note: clampStr(params.versionNote || 'Initial version', 200),
      content: params.content,
      createdAt: serverTimestamp(),
    });
    return docId;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateWorkspaceMeta(
  docId: string,
  updates: Partial<Pick<WorkspaceItem, 'title' | 'folder' | 'summary'>>
): Promise<void> {
  const path = `workspaces/${docId}`;
  try {
    const payload: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (updates.title !== undefined) payload.title = clampStr(updates.title, 240, 'Untitled');
    if (updates.folder !== undefined) payload.folder = clampStr(updates.folder, 80, 'General');
    if (updates.summary !== undefined) payload.summary = clampStr(updates.summary, 1000);
    await updateDoc(doc(db, 'workspaces', docId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteWorkspaceItem(docId: string): Promise<void> {
  const path = `workspaces/${docId}`;
  try {
    const versionsSnap = await getDocs(collection(db, 'workspaces', docId, 'versions'));
    await Promise.all(versionsSnap.docs.map((v) => deleteDoc(v.ref)));
    await deleteDoc(doc(db, 'workspaces', docId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function listWorkspaceVersions(docId: string, userId: string): Promise<WorkspaceVersion[]> {
  const path = `workspaces/${docId}/versions`;
  try {
    const q = query(
      collection(db, 'workspaces', docId, 'versions'),
      where('userId', '==', userId),
      orderBy('versionNumber', 'desc'),
      limit(25)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<WorkspaceVersion, 'id'>) }));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

/* ------------------------------------------------------------------ */
/* Academic Tasks                                                     */
/* ------------------------------------------------------------------ */

export function subscribeTasks(
  userId: string,
  onData: (tasks: AcademicTask[]) => void
): Unsubscribe {
  const path = 'tasks';
  const q = query(
    collection(db, path),
    where('userId', '==', userId),
    orderBy('dueDate', 'asc'),
    limit(100)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AcademicTask, 'id'>) })));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function createTask(
  userId: string,
  task: Omit<AcademicTask, 'id' | 'userId' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const taskId = makeId('tsk');
  const path = `tasks/${taskId}`;
  try {
    await setDoc(doc(db, 'tasks', taskId), {
      userId,
      title: clampStr(task.title, 200, 'Assignment'),
      subject: clampStr(task.subject || '', 120),
      kind: task.kind,
      priority: task.priority,
      status: task.status,
      dueDate: clampStr(task.dueDate, 32),
      dueTime: clampStr(task.dueTime || '', 16),
      notes: clampStr(task.notes || '', 1000),
      reminder: Boolean(task.reminder),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return taskId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateTask(
  taskId: string,
  updates: Partial<Omit<AcademicTask, 'id' | 'userId' | 'createdAt' | 'updatedAt'>>
): Promise<void> {
  const path = `tasks/${taskId}`;
  try {
    const payload: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (updates.title !== undefined) payload.title = clampStr(updates.title, 200, 'Assignment');
    if (updates.subject !== undefined) payload.subject = clampStr(updates.subject, 120);
    if (updates.kind !== undefined) payload.kind = updates.kind;
    if (updates.priority !== undefined) payload.priority = updates.priority;
    if (updates.status !== undefined) payload.status = updates.status;
    if (updates.dueDate !== undefined) payload.dueDate = clampStr(updates.dueDate, 32);
    if (updates.dueTime !== undefined) payload.dueTime = clampStr(updates.dueTime, 16);
    if (updates.notes !== undefined) payload.notes = clampStr(updates.notes, 1000);
    if (updates.reminder !== undefined) payload.reminder = Boolean(updates.reminder);
    await updateDoc(doc(db, 'tasks', taskId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteTask(taskId: string): Promise<void> {
  const path = `tasks/${taskId}`;
  try {
    await deleteDoc(doc(db, 'tasks', taskId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/* ------------------------------------------------------------------ */
/* Assistant Chats                                                    */
/* ------------------------------------------------------------------ */

export function subscribeChats(
  userId: string,
  onData: (chats: AssistantChat[]) => void
): Unsubscribe {
  const path = 'chats';
  const q = query(
    collection(db, path),
    where('userId', '==', userId),
    orderBy('updatedAt', 'desc'),
    limit(30)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AssistantChat, 'id'>) })));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveChat(chat: Omit<AssistantChat, 'createdAt' | 'updatedAt'> & { isNew?: boolean }): Promise<string> {
  const chatId = chat.id || makeId('chat');
  const path = `chats/${chatId}`;
  try {
    const ref = doc(db, 'chats', chatId);
    const trimmedMessages = chat.messages.slice(-80).map((m) => ({
      id: m.id,
      role: m.role,
      text: m.text.slice(0, 12000),
      mode: m.mode || 'simple',
      ...(m.recommendedTool ? { recommendedTool: m.recommendedTool } : {}),
      ...(m.sources ? { sources: m.sources.slice(0, 12) } : {}),
      createdAt: m.createdAt,
    }));

    if (chat.isNew) {
      await setDoc(ref, {
        userId: chat.userId,
        title: clampStr(chat.title, 200, 'Academic Consultation'),
        language: chat.language,
        rememberContext: Boolean(chat.rememberContext),
        messages: trimmedMessages,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        title: clampStr(chat.title, 200, 'Academic Consultation'),
        language: chat.language,
        rememberContext: Boolean(chat.rememberContext),
        messages: trimmedMessages,
        updatedAt: serverTimestamp(),
      });
    }
    return chatId;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteChat(chatId: string): Promise<void> {
  const path = `chats/${chatId}`;
  try {
    await deleteDoc(doc(db, 'chats', chatId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/* ------------------------------------------------------------------ */
/* Study Progress                                                     */
/* ------------------------------------------------------------------ */

export function subscribeStudyProgress(
  userId: string,
  onData: (items: StudyProgress[]) => void
): Unsubscribe {
  const path = 'studyProgress';
  const q = query(
    collection(db, path),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(50)
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudyProgress, 'id'>) })));
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function recordStudyProgress(
  userId: string,
  entry: Omit<StudyProgress, 'id' | 'userId' | 'createdAt'>
): Promise<string> {
  const progressId = makeId('prog');
  const path = `studyProgress/${progressId}`;
  try {
    await setDoc(doc(db, 'studyProgress', progressId), {
      userId,
      topic: clampStr(entry.topic, 200, 'Exam Practice'),
      subject: clampStr(entry.subject || '', 120),
      mode: entry.mode,
      score: Math.max(0, Math.min(500, entry.score)),
      totalQuestions: Math.max(1, Math.min(500, entry.totalQuestions)),
      percentage: Math.max(0, Math.min(100, Math.round(entry.percentage))),
      weakAreas: (entry.weakAreas || []).slice(0, 20).map((w) => clampStr(w, 120)).filter(Boolean),
      createdAt: serverTimestamp(),
    });
    return progressId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}
