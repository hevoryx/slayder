import type { AcademicDocType, Language, ModuleId, SolverSubject } from '../../types';

export interface AppStrings {
  brandName: string;
  nav: Record<ModuleId, string>;
  groups: {
    workspace: string;
    create: string;
    solve: string;
    utilities: string;
    account: string;
  };
  auth: {
    signInGoogle: string;
    signOut: string;
    signInRequiredTitle: string;
    signInRequiredDesc: string;
    signedInAs: string;
    adminBadge: string;
  };
  common: {
    save: string;
    saving: string;
    saved: string;
    cancel: string;
    delete: string;
    edit: string;
    duplicate: string;
    downloadDocx: string;
    downloadPdf: string;
    downloadPptx: string;
    generate: string;
    generating: string;
    regenerate: string;
    search: string;
    filter: string;
    all: string;
    loading: string;
    empty: string;
    retry: string;
    copy: string;
    copied: string;
    uploadFile: string;
    clear: string;
    close: string;
  };
  dashboard: {
    welcomeTitle: string;
    welcomeSubtitle: string;
    recentProjects: string;
    activeAssignments: string;
    upcomingDeadlines: string;
    examSchedule: string;
    studyProgress: string;
    aiUsage: string;
    quickAccess: string;
    noProjects: string;
    noTasks: string;
  };
  docTypes: Record<AcademicDocType, string>;
  solverSubjects: Record<SolverSubject, string>;
}

const UZ: AppStrings = {
  brandName: 'AI University Assistant',
  nav: {
    dashboard: 'Boshqaruv paneli',
    assistant: 'AI Yordamchi',
    documents: 'Akademik hujjatlar',
    presentations: 'Taqdimot studiyasi',
    solver: 'Matematika va Iqtisodiyot',
    analyzer: 'Hujjat tahlilchisi',
    exams: 'Test va Imtihon tizimi',
    translator: 'Tarjima va Yozuv',
    research: 'Ilmiy tadqiqot',
    planner: 'Vazifalar va Taqvim',
    workspace: 'Mening fayllarim',
    tools: 'Talaba vositalari',
    studyboost: 'Study Boost (AI)',
    profile: 'Profil va Tarif',
    admin: 'Admin boshqaruvi',
  },
  groups: {
    workspace: 'Ish maydoni',
    create: 'Yaratish va Yozish',
    solve: 'Yechish va Tadqiqot',
    utilities: 'Talaba vositalari',
    account: 'Hisob',
  },
  auth: {
    signInGoogle: 'Google orqali kirish',
    signOut: 'Chiqish',
    signInRequiredTitle: 'Akademik hisobingizga kiring',
    signInRequiredDesc:
      'Hujjatlarni saqlash, AI yordamchidan foydalanish, test natijalarini kuzatish va shaxsiy fayllar arxivini boshqarish uchun Google hisobingiz bilan kiring.',
    signedInAs: 'Kirilgan hisob',
    adminBadge: 'Administrator',
  },
  common: {
    save: 'Saqlash',
    saving: 'Saqlanmoqda...',
    saved: 'Saqlandi',
    cancel: 'Bekor qilish',
    delete: 'Oʻchirish',
    edit: 'Tahrirlash',
    duplicate: 'Nusxalash',
    downloadDocx: 'DOCX yuklab olish',
    downloadPdf: 'PDF yuklab olish',
    downloadPptx: 'PPTX yuklab olish',
    generate: 'Yaratish',
    generating: 'Tayyorlanmoqda...',
    regenerate: 'Qayta yaratish',
    search: 'Qidirish',
    filter: 'Saralash',
    all: 'Barchasi',
    loading: 'Yuklanmoqda...',
    empty: 'Maʼlumot topilmadi',
    retry: 'Qayta urinish',
    copy: 'Nusxa olish',
    copied: 'Nusxalandi',
    uploadFile: 'Fayl yuklash',
    clear: 'Tozalash',
    close: 'Yopish',
  },
  dashboard: {
    welcomeTitle: 'Akademik ish maydoniga xush kelibsiz',
    welcomeSubtitle:
      'Oʻzbekiston va Markaziy Osiyo universitet talabalari, magistrantlari va tadqiqotchilari uchun yagona intellektual platforma.',
    recentProjects: 'Soʻnggi loyihalar',
    activeAssignments: 'Faol topshiriqlar',
    upcomingDeadlines: 'Yaqinlashayotgan muddatlar',
    examSchedule: 'Imtihonlar jadvali',
    studyProgress: 'Oʻzlashtirish koʻrsatkichi',
    aiUsage: 'AI foydalanish statistikasi',
    quickAccess: 'Tezkor vositalar',
    noProjects: 'Hali saqlangan hujjatlar yoʻq. Birinchi hujjat yoki taqdimotni yarating.',
    noTasks: 'Faol topshiriqlar yoʻq. Rejalashtiruvchida yangi topshiriq qoʻshing.',
  },
  docTypes: {
    kurs_ishi: 'Kurs ishi',
    diplom_ishi: 'Diplom ishi (BMI)',
    magistr_dissertatsiya: 'Magistrlik dissertatsiyasi',
    referat: 'Referat',
    mustaqil_ish: 'Mustaqil ish',
    amaliy_ish: 'Amaliy ish',
    laboratoriya_ishi: 'Laboratoriya ishi',
    esse: 'Esse',
    ilmiy_maqola: 'Ilmiy maqola',
    hisobot: 'Hisobot',
    taqdimot_matni: 'Taqdimot matni',
    maruza_matni: 'Maʼruza matni',
    seminar_materiallari: 'Seminar materiallari',
    konspekt: 'Konspekt',
    biznes_loyiha: 'Biznes loyiha',
    case_study: 'Case study',
    research_proposal: 'Research proposal',
  },
  solverSubjects: {
    mathematics: 'Matematika',
    statistics: 'Statistika',
    microeconomics: 'Mikroiqtisodiyot',
    macroeconomics: 'Makroiqtisodiyot',
    econometrics: 'Ekonometrika',
    accounting: 'Buxgalteriya hisobi',
    finance: 'Moliya',
    business_math: 'Biznes matematika',
    probability: 'Ehtimollar nazariyasi',
    linear_algebra: 'Chiziqli algebra',
    calculus: 'Matematik analiz',
  },
};

const RU: AppStrings = {
  brandName: 'AI University Assistant',
  nav: {
    dashboard: 'Панель студента',
    assistant: 'AI Ассистент',
    documents: 'Академические работы',
    presentations: 'Студия презентаций',
    solver: 'Математика и Экономика',
    analyzer: 'Анализатор документов',
    exams: 'Тесты и Экзамены',
    translator: 'Перевод и Редактура',
    research: 'Научные исследования',
    planner: 'Задачи и Календарь',
    workspace: 'Мои файлы',
    tools: 'Инструменты студента',
    studyboost: 'Study Boost (AI)',
    profile: 'Профиль и Тариф',
    admin: 'Панель администратора',
  },
  groups: {
    workspace: 'Рабочее пространство',
    create: 'Создание и Текст',
    solve: 'Решения и Наука',
    utilities: 'Утилиты студента',
    account: 'Аккаунт',
  },
  auth: {
    signInGoogle: 'Войти через Google',
    signOut: 'Выйти',
    signInRequiredTitle: 'Войдите в свой академический аккаунт',
    signInRequiredDesc:
      'Войдите через Google для сохранения документов, работы с AI-ассистентом, отслеживания прогресса и управления личным архивом.',
    signedInAs: 'Аккаунт',
    adminBadge: 'Администратор',
  },
  common: {
    save: 'Сохранить',
    saving: 'Сохранение...',
    saved: 'Сохранено',
    cancel: 'Отмена',
    delete: 'Удалить',
    edit: 'Редактировать',
    duplicate: 'Дублировать',
    downloadDocx: 'Скачать DOCX',
    downloadPdf: 'Скачать PDF',
    downloadPptx: 'Скачать PPTX',
    generate: 'Создать',
    generating: 'Генерация...',
    regenerate: 'Пересоздать',
    search: 'Поиск',
    filter: 'Фильтр',
    all: 'Все',
    loading: 'Загрузка...',
    empty: 'Записей пока нет',
    retry: 'Повторить',
    copy: 'Копировать',
    copied: 'Скопировано',
    uploadFile: 'Загрузить файл',
    clear: 'Очистить',
    close: 'Закрыть',
  },
  dashboard: {
    welcomeTitle: 'Добро пожаловать в академическую рабочую среду',
    welcomeSubtitle:
      'Единая интеллектуальная экосистема для студентов бакалавриата, магистратуры, докторантов и исследователей.',
    recentProjects: 'Недавние проекты',
    activeAssignments: 'Активные задания',
    upcomingDeadlines: 'Ближайшие дедлайны',
    examSchedule: 'Расписание экзаменов',
    studyProgress: 'Прогресс обучения',
    aiUsage: 'Статистика использования AI',
    quickAccess: 'Быстрый доступ',
    noProjects: 'Сохранённых проектов пока нет. Создайте документ или презентацию.',
    noTasks: 'Активных задач нет. Добавьте задание в планировщике.',
  },
  docTypes: {
    kurs_ishi: 'Курсовая работа',
    diplom_ishi: 'Дипломная работа (ВКР)',
    magistr_dissertatsiya: 'Магистерская диссертация',
    referat: 'Реферат',
    mustaqil_ish: 'Самостоятельная работа',
    amaliy_ish: 'Практическая работа',
    laboratoriya_ishi: 'Лабораторная работа',
    esse: 'Эссе',
    ilmiy_maqola: 'Научная статья',
    hisobot: 'Отчёт',
    taqdimot_matni: 'Текст презентации',
    maruza_matni: 'Текст лекции',
    seminar_materiallari: 'Материалы семинара',
    konspekt: 'Конспект',
    biznes_loyiha: 'Бизнес-проект',
    case_study: 'Кейс-стади',
    research_proposal: 'Research proposal',
  },
  solverSubjects: {
    mathematics: 'Математика',
    statistics: 'Статистика',
    microeconomics: 'Микроэкономика',
    macroeconomics: 'Макроэкономика',
    econometrics: 'Эконометрика',
    accounting: 'Бухгалтерский учёт',
    finance: 'Финансы',
    business_math: 'Бизнес-математика',
    probability: 'Теория вероятностей',
    linear_algebra: 'Линейная алгебра',
    calculus: 'Математический анализ',
  },
};

const EN: AppStrings = {
  brandName: 'AI University Assistant',
  nav: {
    dashboard: 'Dashboard',
    assistant: 'AI Assistant',
    documents: 'Academic Documents',
    presentations: 'Presentation Studio',
    solver: 'Math & Economics Solver',
    analyzer: 'Document Analyzer',
    exams: 'Test & Exam System',
    translator: 'Translation & Writing',
    research: 'Research Assistant',
    planner: 'Tasks & Calendar',
    workspace: 'My Files',
    tools: 'Student Tools',
    studyboost: 'Study Boost (AI)',
    profile: 'Profile & Plan',
    admin: 'Admin Console',
  },
  groups: {
    workspace: 'Workspace',
    create: 'Create & Write',
    solve: 'Solve & Research',
    utilities: 'Student Utilities',
    account: 'Account',
  },
  auth: {
    signInGoogle: 'Sign in with Google',
    signOut: 'Sign out',
    signInRequiredTitle: 'Sign in to your academic workspace',
    signInRequiredDesc:
      'Sign in with Google to run AI workflows, save documents with version history, track exam progress, and manage your academic calendar.',
    signedInAs: 'Signed in as',
    adminBadge: 'Administrator',
  },
  common: {
    save: 'Save',
    saving: 'Saving...',
    saved: 'Saved',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    duplicate: 'Duplicate',
    downloadDocx: 'Download DOCX',
    downloadPdf: 'Download PDF',
    downloadPptx: 'Download PPTX',
    generate: 'Generate',
    generating: 'Generating...',
    regenerate: 'Regenerate',
    search: 'Search',
    filter: 'Filter',
    all: 'All',
    loading: 'Loading...',
    empty: 'No items found',
    retry: 'Try again',
    copy: 'Copy',
    copied: 'Copied',
    uploadFile: 'Upload File',
    clear: 'Clear',
    close: 'Close',
  },
  dashboard: {
    welcomeTitle: 'Welcome to your academic workspace',
    welcomeSubtitle:
      'Unified AI ecosystem for undergraduate, master’s, PhD students, researchers, and university staff.',
    recentProjects: 'Recent Projects',
    activeAssignments: 'Active Assignments',
    upcomingDeadlines: 'Upcoming Deadlines',
    examSchedule: 'Exam Schedule',
    studyProgress: 'Study Progress',
    aiUsage: 'AI Usage Statistics',
    quickAccess: 'Quick Access',
    noProjects: 'No saved documents yet. Generate your first academic work or slide deck.',
    noTasks: 'No active tasks. Add an assignment or exam date in the planner.',
  },
  docTypes: {
    kurs_ishi: 'Coursework',
    diplom_ishi: 'Graduation Thesis',
    magistr_dissertatsiya: "Master's Dissertation",
    referat: 'Term Paper (Referat)',
    mustaqil_ish: 'Independent Study',
    amaliy_ish: 'Practical Work',
    laboratoriya_ishi: 'Laboratory Report',
    esse: 'Academic Essay',
    ilmiy_maqola: 'Scientific Article',
    hisobot: 'Internship / Practice Report',
    taqdimot_matni: 'Presentation Script',
    maruza_matni: 'Lecture Notes',
    seminar_materiallari: 'Seminar Materials',
    konspekt: 'Study Conspectus',
    biznes_loyiha: 'Business Project',
    case_study: 'Case Study',
    research_proposal: 'Research Proposal',
  },
  solverSubjects: {
    mathematics: 'Mathematics',
    statistics: 'Statistics',
    microeconomics: 'Microeconomics',
    macroeconomics: 'Macroeconomics',
    econometrics: 'Econometrics',
    accounting: 'Accounting',
    finance: 'Finance',
    business_math: 'Business Mathematics',
    probability: 'Probability Theory',
    linear_algebra: 'Linear Algebra',
    calculus: 'Calculus',
  },
};

const KAA: AppStrings = {
  ...UZ,
  nav: {
    dashboard: 'Basqarıw paneli',
    assistant: 'AI Járdemshi',
    documents: 'Akademiyalıq hújjetler',
    presentations: 'Prezentaciya studiyası',
    solver: 'Matematika hám Ekonomika',
    analyzer: 'Hújjet analizatorı',
    exams: 'Test hám Imtixan',
    translator: 'Awdarma hám Jazıw',
    research: 'Ilimiy izertlew',
    planner: 'Wazıypalar hám Kalendar',
    workspace: 'Meniń fayllarım',
    tools: 'Student quralları',
    studyboost: 'Study Boost (AI)',
    profile: 'Profil hám Tarif',
    admin: 'Admin paneli',
  },
  groups: {
    workspace: 'Jumıs maydanı',
    create: 'Jaratıw hám Jazıw',
    solve: 'Sheshiw hám Izertlew',
    utilities: 'Student quralları',
    account: 'Esap',
  },
  auth: {
    signInGoogle: 'Google arqalı kiriw',
    signOut: 'Shıǵıw',
    signInRequiredTitle: 'Akademiyalıq esabıńızǵa kiriń',
    signInRequiredDesc:
      'Hújjetlerdi saqlaw, AI járdemshiden paydalanıw hám jeke fayllar arxivin basqarıw ushın Google esabıńız benen kiriń.',
    signedInAs: 'Kirilgen esap',
    adminBadge: 'Administrator',
  },
  dashboard: {
    welcomeTitle: 'Akademiyalıq jumıs maydanına xosh keldińiz',
    welcomeSubtitle:
      'Universitet studentleri, magistrantlar hám izertlewshiler ushın birden-bir intellektual platforma.',
    recentProjects: 'Sońǵı joybarlar',
    activeAssignments: 'Aktiv tapsırmalar',
    upcomingDeadlines: 'Jaqınlasıp kiyatırǵan múddetler',
    examSchedule: 'Imtixanlar kestesi',
    studyProgress: 'Ózlestiriw kórsetkishi',
    aiUsage: 'AI paydalanıw statistikası',
    quickAccess: 'Tez qurallar',
    noProjects: 'Ele saqlanǵan hújjetler joq.',
    noTasks: 'Aktiv tapsırmalar joq.',
  },
};

const KK: AppStrings = {
  ...RU,
  nav: {
    dashboard: 'Басқару панелі',
    assistant: 'AI Көмекші',
    documents: 'Академиялық құжаттар',
    presentations: 'Презентация студиясы',
    solver: 'Математика және Экономика',
    analyzer: 'Құжат талдаушы',
    exams: 'Тест және Емтихан',
    translator: 'Аударма және Жазу',
    research: 'Ғылыми зерттеу',
    planner: 'Тапсырмалар және Күнтізбе',
    workspace: 'Менің файлдарым',
    tools: 'Студент құралдары',
    studyboost: 'Study Boost (AI)',
    profile: 'Профиль және Тариф',
    admin: 'Әкімші панелі',
  },
  groups: {
    workspace: 'Жұмыс кеңістігі',
    create: 'Құру және Жазу',
    solve: 'Шешу және Зерттеу',
    utilities: 'Студент құралдары',
    account: 'Есептік жазба',
  },
  auth: {
    signInGoogle: 'Google арқылы кіру',
    signOut: 'Шығу',
    signInRequiredTitle: 'Академиялық есептік жазбаңызға кіріңіз',
    signInRequiredDesc:
      'Құжаттарды сақтау, AI көмекшісін пайдалану және оқу үлгерімін бақылау үшін Google арқылы кіріңіз.',
    signedInAs: 'Кірілген аккаунт',
    adminBadge: 'Әкімші',
  },
  dashboard: {
    welcomeTitle: 'Академиялық жұмыс кеңістігіне қош келдіңіз',
    welcomeSubtitle:
      'Университет студенттері, магистранттар және зерттеушілерге арналған бірыңғай зияткерлік платформа.',
    recentProjects: 'Соңғы жобалар',
    activeAssignments: 'Белсенді тапсырмалар',
    upcomingDeadlines: 'Жақын мерзімдер',
    examSchedule: 'Емтихан кестесі',
    studyProgress: 'Оқу үлгерімі',
    aiUsage: 'AI пайдалану статистикасы',
    quickAccess: 'Жылдам қол жеткізу',
    noProjects: 'Сақталған құжаттар жоқ.',
    noTasks: 'Белсенді тапсырмалар жоқ.',
  },
};

export const UI_STRINGS: Record<Language, AppStrings> = {
  uz: UZ,
  ru: RU,
  en: EN,
  kaa: KAA,
  kk: KK,
};

export const LANGUAGE_PROMPT_NAME: Record<Language, string> = {
  uz: 'Uzbek (Latin script, standard literary Uzbek with proper oʻ and gʻ)',
  ru: 'Russian (academic Russian)',
  en: 'English (academic English)',
  kaa: 'Karakalpak (Latin script, Qaraqalpaqsha)',
  kk: 'Kazakh (Cyrillic script, Қазақ тілі)',
};
