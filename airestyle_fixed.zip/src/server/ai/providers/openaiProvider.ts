import OpenAI from 'openai';
import type {
  ResponseCreateParamsNonStreaming,
  ResponseInputContent,
  ResponseOutputItem,
} from 'openai/resources/responses/responses';
import { AiProviderError, normalizeProviderError } from '../aiErrors.ts';
import type {
  AiGenerateRequest,
  AiGenerateResponse,
  AiJsonSchema,
  AiProvider,
  AiSourceReference,
  AiTaskType,
} from '../aiTypes.ts';

export const DEFAULT_OPENAI_MODEL = 'gpt-6.2-sol';
export const SUPPORTED_OPENAI_MODELS = ['gpt-6.2-sol', 'gpt-6.2-astra'] as const;
const DEFAULT_TIMEOUT_MS = 120_000;

function makeNullableSchema(schema: Record<string, unknown>): Record<string, unknown> {
  if (typeof schema.type === 'string' && (schema.type === 'string' || schema.type === 'number' || schema.type === 'integer' || schema.type === 'boolean')) {
    const out: Record<string, unknown> = {
      ...schema,
      type: [schema.type, 'null'],
    };
    if (Array.isArray(schema.enum)) {
      out.enum = [...schema.enum, null];
    }
    return out;
  }
  return { anyOf: [schema, { type: 'null' }] };
}

export function toOpenAiStrictSchema(schema: AiJsonSchema): Record<string, unknown> {
  if (schema.type === 'object') {
    const props = schema.properties ?? {};
    const requiredSet = new Set(schema.required ?? []);
    const convertedProps: Record<string, unknown> = {};
    const allKeys = Object.keys(props);

    for (const key of allKeys) {
      const childStrict = toOpenAiStrictSchema(props[key]);
      convertedProps[key] = requiredSet.has(key) ? childStrict : makeNullableSchema(childStrict);
    }

    return {
      type: 'object',
      ...(schema.description ? { description: schema.description } : {}),
      properties: convertedProps,
      required: allKeys,
      additionalProperties: false,
    };
  }

  if (schema.type === 'array') {
    return {
      type: 'array',
      ...(schema.description ? { description: schema.description } : {}),
      items: schema.items ? toOpenAiStrictSchema(schema.items) : { type: 'string' },
    };
  }

  return {
    type: schema.type,
    ...(schema.description ? { description: schema.description } : {}),
    ...(schema.enum ? { enum: schema.enum } : {}),
  };
}

function buildInputContent(request: AiGenerateRequest): ResponseInputContent[] {
  const content: ResponseInputContent[] = [];
  const parts = request.parts && request.parts.length > 0
    ? request.parts
    : request.prompt
      ? [{ text: request.prompt }]
      : [];

  for (const part of parts) {
    if (typeof part.text === 'string' && part.text.trim()) {
      content.push({ type: 'input_text', text: part.text });
    } else if (part.inlineData?.data && part.inlineData?.mimeType) {
      const { mimeType, data, fileName } = part.inlineData;
      if (mimeType.startsWith('image/')) {
        content.push({
          type: 'input_image',
          image_url: `data:${mimeType};base64,${data}`,
          detail: 'auto',
        });
      } else if (mimeType === 'application/pdf') {
        content.push({
          type: 'input_file',
          filename: (fileName || 'document.pdf').slice(0, 120),
          file_data: `data:application/pdf;base64,${data}`,
        });
      } else {
        content.push({
          type: 'input_text',
          text: `[Attached binary file "${fileName || 'file'}" (${mimeType}) could not be sent inline; rely on extracted text if provided.]`,
        });
      }
    }
  }

  if (content.length === 0) {
    content.push({ type: 'input_text', text: '' });
  }
  return content;
}

function extractOpenAiSources(output: ResponseOutputItem[] | undefined): AiSourceReference[] {
  if (!Array.isArray(output)) return [];
  const seen = new Set<string>();
  const sources: AiSourceReference[] = [];

  const addSource = (uri?: string | null, title?: string | null) => {
    if (!uri || typeof uri !== 'string') return;
    const cleanUri = uri.trim();
    if (!cleanUri || seen.has(cleanUri)) return;
    seen.add(cleanUri);
    sources.push({
      title: (title && title.trim()) || cleanUri,
      uri: cleanUri,
    });
  };

  for (const item of output) {
    if (item.type === 'message' && Array.isArray(item.content)) {
      for (const block of item.content) {
        if (block.type === 'output_text' && Array.isArray(block.annotations)) {
          for (const ann of block.annotations) {
            if (ann.type === 'url_citation') {
              addSource(ann.url, ann.title);
            }
          }
        }
      }
    } else if (item.type === 'web_search_call') {
      const action = (item as unknown as { action?: { sources?: Array<{ url?: string; title?: string }> } }).action;
      if (Array.isArray(action?.sources)) {
        for (const src of action.sources) {
          addSource(src.url, src.title);
        }
      }
    }
  }

  return sources;
}

export class OpenAiProvider implements AiProvider {
  public readonly name = 'openai' as const;

  private getApiKey(): string {
    return process.env.OPENAI_API_KEY?.trim() || '';
  }

  public isConfigured(): boolean {
    return Boolean(this.getApiKey());
  }

  public getDefaultModel(taskType?: AiTaskType): string {
    if (taskType === 'reasoning' && process.env.OPENAI_REASONING_MODEL?.trim()) {
      return process.env.OPENAI_REASONING_MODEL.trim();
    }
    return process.env.OPENAI_MODEL?.trim() || DEFAULT_OPENAI_MODEL;
  }

  private getClient(timeoutMs: number): OpenAI {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new AiProviderError({
        code: 'MISSING_API_KEY',
        status: 503,
        provider: 'openai',
        message: 'OpenAI API key is not configured on the server. Add OPENAI_API_KEY in environment settings.',
        retryable: false,
      });
    }
    return new OpenAI({
      apiKey,
      timeout: timeoutMs,
      maxRetries: 0,
    });
  }

  public async generate(request: AiGenerateRequest): Promise<AiGenerateResponse> {
    const startedAt = Date.now();
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const client = this.getClient(timeoutMs);
    const model = request.modelOverride?.trim() || this.getDefaultModel(request.taskType);
    const inputContent = buildInputContent(request);

    let instructions = request.systemInstruction || '';
    if (request.jsonMode && !request.jsonSchema && !/json/i.test(instructions)) {
      instructions = `${instructions}\nRespond strictly with valid JSON.`.trim();
    }

    const buildParams = (opts: { includeWebSearch: boolean; includeReasoning: boolean }): ResponseCreateParamsNonStreaming => {
      const params: ResponseCreateParamsNonStreaming = {
        model,
        input: [{ role: 'user', content: inputContent }],
      };

      if (instructions) {
        params.instructions = instructions;
      }

      if (opts.includeReasoning && request.reasoningEffort) {
        params.reasoning = { effort: request.reasoningEffort };
      }

      if (opts.includeWebSearch && request.useWebSearch) {
        params.tools = [{ type: 'web_search' }];
        params.include = ['web_search_call.action.sources'];
      }

      if (request.jsonSchema) {
        params.text = {
          format: {
            type: 'json_schema',
            name: request.jsonSchema.name,
            strict: true,
            schema: toOpenAiStrictSchema(request.jsonSchema.schema),
          },
        };
      } else if (request.jsonMode) {
        params.text = { format: { type: 'json_object' } };
      }

      return params;
    };

    let webSearchUsed = Boolean(request.useWebSearch);
    let includeReasoning = Boolean(request.reasoningEffort);

    const runCall = async () => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await client.responses.create(
          buildParams({ includeWebSearch: webSearchUsed, includeReasoning }),
          { signal: controller.signal }
        );
      } finally {
        clearTimeout(timer);
      }
    };

    try {
      let response;
      try {
        response = await runCall();
      } catch (err) {
        const msg = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase();
        const status = (err as { status?: number })?.status;
        if (status === 400 && webSearchUsed && (msg.includes('web_search') || msg.includes('tool'))) {
          webSearchUsed = false;
          response = await runCall();
        } else if (status === 400 && includeReasoning && msg.includes('reasoning')) {
          includeReasoning = false;
          response = await runCall();
        } else {
          throw err;
        }
      }

      const inputTokens = response.usage?.input_tokens ?? 0;
      const outputTokens = response.usage?.output_tokens ?? 0;
      const totalTokens = response.usage?.total_tokens ?? inputTokens + outputTokens;
      const durationMs = Date.now() - startedAt;

      return {
        text: response.output_text || '',
        provider: 'openai',
        model: response.model || model,
        usageStats: {
          provider: 'openai',
          model: response.model || model,
          inputTokens,
          outputTokens,
          totalTokens,
          durationMs,
          status: 'ok',
        },
        sources: extractOpenAiSources(response.output),
        webSearchAvailable: webSearchUsed,
      };
    } catch (err) {
      throw normalizeProviderError(err, 'openai');
    }
  }

  public async generateStream(
    request: AiGenerateRequest,
    onDelta: (delta: string) => void
  ): Promise<AiGenerateResponse> {
    const startedAt = Date.now();
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const client = this.getClient(timeoutMs);
    const model = request.modelOverride?.trim() || this.getDefaultModel(request.taskType);
    const inputContent = buildInputContent(request);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let fullText = '';
    let usedModel = model;
    let inputTokens = 0;
    let outputTokens = 0;
    let totalTokens = 0;

    try {
      const stream = await client.responses.create(
        {
          model,
          input: [{ role: 'user', content: inputContent }],
          ...(request.systemInstruction ? { instructions: request.systemInstruction } : {}),
          ...(request.reasoningEffort ? { reasoning: { effort: request.reasoningEffort } } : {}),
          stream: true,
        },
        { signal: controller.signal }
      );

      for await (const event of stream) {
        if (event.type === 'response.output_text.delta' && typeof event.delta === 'string') {
          fullText += event.delta;
          onDelta(event.delta);
        } else if (event.type === 'response.completed' && event.response) {
          usedModel = event.response.model || usedModel;
          inputTokens = event.response.usage?.input_tokens ?? inputTokens;
          outputTokens = event.response.usage?.output_tokens ?? outputTokens;
          totalTokens = event.response.usage?.total_tokens ?? inputTokens + outputTokens;
        }
      }

      return {
        text: fullText,
        provider: 'openai',
        model: usedModel,
        usageStats: {
          provider: 'openai',
          model: usedModel,
          inputTokens,
          outputTokens,
          totalTokens,
          durationMs: Date.now() - startedAt,
          status: 'ok',
        },
        sources: [],
        webSearchAvailable: false,
      };
    } catch (err) {
      throw normalizeProviderError(err, 'openai');
    } finally {
      clearTimeout(timer);
    }
  }
}
