import { GoogleGenAI, ThinkingLevel, Type, type Schema } from '@google/genai';
import { AiProviderError, normalizeProviderError } from '../aiErrors.ts';
import type {
  AiGenerateRequest,
  AiGenerateResponse,
  AiJsonSchema,
  AiProvider,
  AiSourceReference,
  AiTaskType,
  ReasoningEffortLevel,
} from '../aiTypes.ts';

export const DEFAULT_GEMINI_MODEL = 'gemini-4-hydrogen';
export const FALLBACK_GEMINI_MODEL = 'gemini-3.1-flash-lite';
const getFallbackModel = () => process.env.GEMINI_FALLBACK_MODEL?.trim() || FALLBACK_GEMINI_MODEL;
const DEFAULT_TIMEOUT_MS = 120_000;

function mapSchemaType(t: AiJsonSchema['type']): Type {
  switch (t) {
    case 'object':
      return Type.OBJECT;
    case 'array':
      return Type.ARRAY;
    case 'number':
      return Type.NUMBER;
    case 'integer':
      return Type.INTEGER;
    case 'boolean':
      return Type.BOOLEAN;
    case 'string':
    default:
      return Type.STRING;
  }
}

export function toGeminiSchema(schema: AiJsonSchema): Schema {
  const out: Schema = {
    type: mapSchemaType(schema.type),
  };
  if (schema.description) out.description = schema.description;
  if (schema.enum) out.enum = schema.enum;
  if (schema.required) out.required = schema.required;
  if (schema.items) out.items = toGeminiSchema(schema.items);
  if (schema.properties) {
    const props: Record<string, Schema> = {};
    for (const [k, v] of Object.entries(schema.properties)) {
      props[k] = toGeminiSchema(v);
    }
    out.properties = props;
  }
  return out;
}

function mapThinkingLevel(effort?: ReasoningEffortLevel): ThinkingLevel | undefined {
  switch (effort) {
    case 'low':
      return ThinkingLevel.LOW;
    case 'medium':
      return ThinkingLevel.MEDIUM;
    case 'high':
      return ThinkingLevel.HIGH;
    default:
      return undefined;
  }
}

function extractGroundingSources(response: unknown): AiSourceReference[] {
  const candidates = (
    response as {
      candidates?: Array<{
        groundingMetadata?: {
          groundingChunks?: Array<{ web?: { uri?: string; title?: string } }>;
        };
      }>;
    }
  )?.candidates;
  const chunks = candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (!Array.isArray(chunks)) return [];
  const seen = new Set<string>();
  const out: AiSourceReference[] = [];
  for (const chunk of chunks) {
    const uri = chunk?.web?.uri;
    const title = chunk?.web?.title;
    if (uri && !seen.has(uri)) {
      seen.add(uri);
      out.push({ title: title || uri, uri });
    }
  }
  return out;
}

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number, provider: 'gemini'): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          reject(
            new AiProviderError({
              code: 'TIMEOUT',
              status: 504,
              provider,
              message: 'Gemini request timed out. Please try again with a shorter input or retry shortly.',
              retryable: true,
            })
          );
        }, timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export class GeminiProvider implements AiProvider {
  public readonly name = 'gemini' as const;

  private getApiKey(): string {
    return process.env.GEMINI_API_KEY?.trim() || process.env.API_KEY?.trim() || '';
  }

  /** Safe (secret-free) description of how the key will be used. */
  public describeAuth(): { configured: boolean; mode: 'vertex-express' | 'ai-studio' | 'none'; keyPrefix: string } {
    const key = this.getApiKey();
    if (!key) return { configured: false, mode: 'none', keyPrefix: '' };
    return {
      configured: true,
      mode: this.shouldUseVertex(key) ? 'vertex-express' : 'ai-studio',
      keyPrefix: key.slice(0, 3) + '…',
    };
  }

  public isConfigured(): boolean {
    return Boolean(this.getApiKey());
  }

  public getDefaultModel(_taskType?: AiTaskType): string {
    return process.env.GEMINI_MODEL?.trim() || DEFAULT_GEMINI_MODEL;
  }

  /**
   * Keys starting with "AQ." are Vertex AI Express Mode keys and must be used
   * with `vertexai: true`. Keys starting with "AIza" are AI Studio (Gemini
   * Developer API) keys. GEMINI_USE_VERTEX=true|false forces a mode.
   */
  private shouldUseVertex(apiKey: string): boolean {
    const forced = process.env.GEMINI_USE_VERTEX?.trim().toLowerCase();
    if (forced === 'true' || forced === '1') return true;
    if (forced === 'false' || forced === '0') return false;
    return apiKey.startsWith('AQ.');
  }

  private buildClient(apiKey: string, vertex: boolean): GoogleGenAI {
    if (vertex) {
      return new GoogleGenAI({
        vertexai: true,
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });
  }

  private getClient(forceVertex?: boolean): GoogleGenAI {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new AiProviderError({
        code: 'MISSING_API_KEY',
        status: 503,
        provider: 'gemini',
        message: 'Gemini API key is not configured on the server. Add GEMINI_API_KEY in environment settings.',
        retryable: false,
      });
    }
    const vertex = forceVertex ?? this.shouldUseVertex(apiKey);
    return this.buildClient(apiKey, vertex);
  }

  /**
   * Runs `fn` with the preferred client mode. If Google answers with an auth
   * error (401/403), the other mode (Vertex <-> AI Studio) is tried once, so
   * either key type works without manual configuration.
   */
  private async withAuthFallback<T>(fn: (ai: GoogleGenAI) => Promise<T>): Promise<T> {
    const apiKey = this.getApiKey();
    const preferVertex = this.shouldUseVertex(apiKey);
    const forced = process.env.GEMINI_USE_VERTEX?.trim();
    try {
      return await fn(this.getClient(preferVertex));
    } catch (err) {
      const normalized = normalizeProviderError(err, 'gemini');
      if (normalized.code === 'INVALID_API_KEY' && !forced) {
        return await fn(this.getClient(!preferVertex));
      }
      throw normalized;
    }
  }

  public async generate(request: AiGenerateRequest): Promise<AiGenerateResponse> {
    const startedAt = Date.now();
    this.getClient(); // throws MISSING_API_KEY early if not configured
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const primaryModel = request.modelOverride?.trim() || this.getDefaultModel(request.taskType);

    const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];
    if (request.parts && request.parts.length > 0) {
      for (const p of request.parts) {
        if (typeof p.text === 'string' && p.text.trim()) {
          parts.push({ text: p.text });
        } else if (p.inlineData?.data && p.inlineData?.mimeType) {
          parts.push({
            inlineData: {
              mimeType: p.inlineData.mimeType,
              data: p.inlineData.data,
            },
          });
        }
      }
    } else if (request.prompt) {
      parts.push({ text: request.prompt });
    }

    const thinkingLevel = mapThinkingLevel(request.reasoningEffort);
    const config: Record<string, unknown> = {};
    if (request.systemInstruction) {
      config.systemInstruction = request.systemInstruction;
    }
    if (thinkingLevel) {
      config.thinkingConfig = { thinkingLevel };
    }
    if (request.useWebSearch) {
      config.tools = [{ googleSearch: {} }];
    }
    if (request.jsonSchema) {
      config.responseMimeType = 'application/json';
      config.responseSchema = toGeminiSchema(request.jsonSchema.schema);
    } else if (request.jsonMode) {
      config.responseMimeType = 'application/json';
    }

    const executeForModel = async (model: string) => {
      return this.withAuthFallback((ai) =>
        withTimeout(
          ai.models.generateContent({
            model,
            contents: parts.length === 1 && parts[0].text ? parts[0].text : { parts },
            config,
          }),
          timeoutMs,
          'gemini'
        )
      );
    };

    try {
      let usedModel = primaryModel;
      let response;
      try {
        response = await executeForModel(primaryModel);
      } catch (err) {
        const normalized = normalizeProviderError(err, 'gemini');
        const fallbackModel = primaryModel === DEFAULT_GEMINI_MODEL ? getFallbackModel() : DEFAULT_GEMINI_MODEL;
        if (
          (normalized.code === 'RATE_LIMIT' || normalized.code === 'MODEL_UNAVAILABLE' || normalized.status === 503) &&
          primaryModel !== fallbackModel
        ) {
          usedModel = fallbackModel;
          response = await executeForModel(fallbackModel);
        } else {
          throw normalized;
        }
      }

      const inputTokens = response.usageMetadata?.promptTokenCount || 0;
      const outputTokens = response.usageMetadata?.candidatesTokenCount || 0;
      const totalTokens = response.usageMetadata?.totalTokenCount || inputTokens + outputTokens;

      return {
        text: response.text || '',
        provider: 'gemini',
        model: usedModel,
        usageStats: {
          provider: 'gemini',
          model: usedModel,
          inputTokens,
          outputTokens,
          totalTokens,
          durationMs: Date.now() - startedAt,
          status: 'ok',
        },
        sources: extractGroundingSources(response),
        webSearchAvailable: Boolean(request.useWebSearch),
      };
    } catch (err) {
      throw normalizeProviderError(err, 'gemini');
    }
  }

  public async generateStream(
    request: AiGenerateRequest,
    onDelta: (delta: string) => void
  ): Promise<AiGenerateResponse> {
    const startedAt = Date.now();
    this.getClient(); // throws MISSING_API_KEY early if not configured
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const primaryModel = request.modelOverride?.trim() || this.getDefaultModel(request.taskType);

    const parts: Array<{ text?: string; inlineData?: { mimeType: string; data: string } }> = [];
    if (request.parts && request.parts.length > 0) {
      for (const p of request.parts) {
        if (typeof p.text === 'string' && p.text.trim()) {
          parts.push({ text: p.text });
        } else if (p.inlineData?.data && p.inlineData?.mimeType) {
          parts.push({
            inlineData: {
              mimeType: p.inlineData.mimeType,
              data: p.inlineData.data,
            },
          });
        }
      }
    } else if (request.prompt) {
      parts.push({ text: request.prompt });
    }

    const config: Record<string, unknown> = {};
    if (request.systemInstruction) {
      config.systemInstruction = request.systemInstruction;
    }

    const runStream = async (model: string) => {
      const streamResult = await this.withAuthFallback((ai) =>
        withTimeout(
          ai.models.generateContentStream({
            model,
            contents: parts.length === 1 && parts[0].text ? parts[0].text : { parts },
            config,
          }),
          timeoutMs,
          'gemini'
        )
      );

      let fullText = '';
      let inputTokens = 0;
      let outputTokens = 0;
      let totalTokens = 0;

      for await (const chunk of streamResult) {
        const delta = chunk.text || '';
        if (delta) {
          fullText += delta;
          onDelta(delta);
        }
        if (chunk.usageMetadata) {
          inputTokens = chunk.usageMetadata.promptTokenCount || inputTokens;
          outputTokens = chunk.usageMetadata.candidatesTokenCount || outputTokens;
          totalTokens = chunk.usageMetadata.totalTokenCount || inputTokens + outputTokens;
        }
      }

      return {
        text: fullText,
        provider: 'gemini' as const,
        model,
        usageStats: {
          provider: 'gemini' as const,
          model,
          inputTokens,
          outputTokens,
          totalTokens,
          durationMs: Date.now() - startedAt,
          status: 'ok' as const,
        },
        sources: [],
        webSearchAvailable: false,
      };
    };

    try {
      try {
        return await runStream(primaryModel);
      } catch (err) {
        const normalized = normalizeProviderError(err, 'gemini');
        const fallbackModel = primaryModel === DEFAULT_GEMINI_MODEL ? getFallbackModel() : DEFAULT_GEMINI_MODEL;
        if (
          (normalized.code === 'RATE_LIMIT' || normalized.code === 'MODEL_UNAVAILABLE' || normalized.status === 503) &&
          primaryModel !== fallbackModel
        ) {
          return await runStream(fallbackModel);
        }
        throw normalized;
      }
    } catch (err) {
      throw normalizeProviderError(err, 'gemini');
    }
  }
}
