import crypto from 'node:crypto';
import Groq from 'groq-sdk';
import type {
  ChatCompletionContentPart,
  ChatCompletionCreateParamsNonStreaming,
  ChatCompletionCreateParamsStreaming,
  ChatCompletionMessage,
  ChatCompletionMessageParam,
} from 'groq-sdk/resources/chat/completions';
import { AiProviderError, normalizeProviderError } from '../aiErrors.ts';
import type {
  AiGenerateRequest,
  AiGenerateResponse,
  AiModelCapabilities,
  AiModelInfo,
  AiProvider,
  AiSourceReference,
  AiTaskType,
} from '../aiTypes.ts';
import { toOpenAiStrictSchema } from './openaiProvider.ts';

export const DEFAULT_GROQ_MODEL = 'openai/gpt-oss-20b';
const DEFAULT_TIMEOUT_MS = 120_000;
const MODEL_CACHE_TTL_MS = 5 * 60 * 1000;

export const GROQ_KNOWN_MODELS: readonly string[] = [
  'openai/gpt-oss-20b',
  'openai/gpt-oss-120b',
  'meta-llama/llama-4-scout-17b-16e-instruct',
  'meta-llama/llama-4-maverick-17b-128e-instruct',
  'llama-3.3-70b-versatile',
  'llama-3.1-8b-instant',
  'qwen/qwen3-32b',
  'moonshotai/kimi-k2-instruct',
  'groq/compound',
];

export function getGroqModelCapabilities(modelId: string): AiModelCapabilities {
  const m = modelId.trim().toLowerCase();

  // Audio / TTS / Guard models are not general academic chat models
  if (
    m.includes('whisper') ||
    m.includes('tts') ||
    m.includes('playai') ||
    m.includes('llama-guard') ||
    m.includes('prompt-guard')
  ) {
    return {
      supportsChat: false,
      supportsVision: false,
      supportsBrowserSearch: false,
      supportsBuiltInSearch: false,
      supportsStructuredOutput: false,
      supportsJsonMode: false,
      supportsReasoningEffort: false,
      supportsToolCalling: false,
    };
  }

  // Compound agentic systems have built-in search, no json_schema or browser_search tool param
  if (m.startsWith('groq/compound')) {
    return {
      supportsChat: true,
      supportsVision: false,
      supportsBrowserSearch: false,
      supportsBuiltInSearch: true,
      supportsStructuredOutput: false,
      supportsJsonMode: true,
      supportsReasoningEffort: false,
      supportsToolCalling: false,
    };
  }

  // OpenAI GPT-OSS series on Groq: browser_search, structured outputs, reasoning_effort
  if (m.startsWith('openai/gpt-oss-')) {
    return {
      supportsChat: true,
      supportsVision: false,
      supportsBrowserSearch: true,
      supportsBuiltInSearch: false,
      supportsStructuredOutput: true,
      supportsJsonMode: true,
      supportsReasoningEffort: !m.includes('safeguard'),
      supportsToolCalling: true,
    };
  }

  // Llama 4 Scout / Maverick: native vision + structured outputs
  if (m.includes('llama-4-scout') || m.includes('llama-4-maverick')) {
    return {
      supportsChat: true,
      supportsVision: true,
      supportsBrowserSearch: false,
      supportsBuiltInSearch: false,
      supportsStructuredOutput: true,
      supportsJsonMode: true,
      supportsReasoningEffort: false,
      supportsToolCalling: true,
    };
  }

  // Kimi K2 Instruct: structured outputs + tool calling
  if (m.includes('kimi-k2')) {
    return {
      supportsChat: true,
      supportsVision: false,
      supportsBrowserSearch: false,
      supportsBuiltInSearch: false,
      supportsStructuredOutput: true,
      supportsJsonMode: true,
      supportsReasoningEffort: false,
      supportsToolCalling: true,
    };
  }

  // Qwen3 models: reasoning_effort ('none' | 'default'), json_object mode
  if (m.includes('qwen')) {
    return {
      supportsChat: true,
      supportsVision: false,
      supportsBrowserSearch: false,
      supportsBuiltInSearch: false,
      supportsStructuredOutput: false,
      supportsJsonMode: true,
      supportsReasoningEffort: m.includes('qwen3'),
      supportsToolCalling: true,
    };
  }

  // Generic vision fallback if future vision models appear
  const isVision = m.includes('vision') || m.includes('llava');

  // Default for Llama 3.x & other text chat models on Groq
  return {
    supportsChat: true,
    supportsVision: isVision,
    supportsBrowserSearch: false,
    supportsBuiltInSearch: false,
    supportsStructuredOutput: false,
    supportsJsonMode: true,
    supportsReasoningEffort: false,
    supportsToolCalling: true,
  };
}

function getMaxCompletionTokens(taskType?: AiTaskType): number {
  switch (taskType) {
    case 'document':
    case 'coursework':
    case 'research':
    case 'analysis':
    case 'reasoning':
      return 16384;
    case 'presentation':
    case 'exam':
      return 12288;
    default:
      return 8192;
  }
}

function isSafeHttpUrl(raw: unknown): raw is string {
  if (typeof raw !== 'string') return false;
  try {
    const parsed = new URL(raw.trim());
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function extractGroqSources(message: ChatCompletionMessage | undefined): AiSourceReference[] {
  const executed = message?.executed_tools;
  if (!Array.isArray(executed)) return [];

  const seen = new Set<string>();
  const sources: AiSourceReference[] = [];

  const addSource = (uri?: string | null, title?: string | null) => {
    if (!isSafeHttpUrl(uri)) return;
    const cleanUri = uri.trim();
    if (seen.has(cleanUri)) return;
    seen.add(cleanUri);
    sources.push({
      title: (typeof title === 'string' && title.trim()) || cleanUri,
      uri: cleanUri,
    });
  };

  for (const tool of executed) {
    if (Array.isArray(tool.browser_results)) {
      for (const br of tool.browser_results) {
        addSource(br?.url, br?.title);
      }
    }
    if (Array.isArray(tool.search_results?.results)) {
      for (const sr of tool.search_results.results) {
        addSource(sr?.url, sr?.title);
      }
    }
  }

  return sources;
}

interface ModelCacheEntry {
  keyHash: string;
  fetchedAt: number;
  models: AiModelInfo[];
}

export class GroqProvider implements AiProvider {
  public readonly name = 'groq' as const;
  private modelCache: ModelCacheEntry | null = null;

  private getApiKey(): string {
    return process.env.GROQ_API_KEY?.trim() || '';
  }

  public isConfigured(): boolean {
    return Boolean(this.getApiKey());
  }

  public getDefaultModel(taskType?: AiTaskType): string {
    if (taskType === 'reasoning' && process.env.GROQ_REASONING_MODEL?.trim()) {
      return process.env.GROQ_REASONING_MODEL.trim();
    }
    return process.env.GROQ_MODEL?.trim() || DEFAULT_GROQ_MODEL;
  }

  private getClient(timeoutMs: number): Groq {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new AiProviderError({
        code: 'MISSING_API_KEY',
        status: 503,
        provider: 'groq',
        message: 'Groq API key is not configured on the server. Add GROQ_API_KEY in environment settings.',
        retryable: false,
      });
    }
    const baseURL = process.env.GROQ_BASE_URL?.trim();
    return new Groq({
      apiKey,
      ...(baseURL ? { baseURL } : {}),
      timeout: timeoutMs,
      maxRetries: 0,
    });
  }

  public clearModelCache(): void {
    this.modelCache = null;
  }

  public async listAvailableModels(forceRefresh = false): Promise<AiModelInfo[]> {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new AiProviderError({
        code: 'MISSING_API_KEY',
        status: 503,
        provider: 'groq',
        message: 'Groq API key is not configured on the server. Add GROQ_API_KEY in environment settings.',
        retryable: false,
      });
    }

    const keyHash = crypto.createHash('sha256').update(apiKey).digest('hex').slice(0, 12);
    const now = Date.now();
    if (
      !forceRefresh &&
      this.modelCache &&
      this.modelCache.keyHash === keyHash &&
      now - this.modelCache.fetchedAt < MODEL_CACHE_TTL_MS
    ) {
      return this.modelCache.models;
    }

    const client = this.getClient(15_000);
    return this.fetchModelsWithClient(client, keyHash);
  }

  private async fetchModelsWithClient(client: Groq, keyHash: string): Promise<AiModelInfo[]> {
    try {
      const resp = await client.models.list();
      const items = Array.isArray(resp?.data) ? resp.data : [];
      const models: AiModelInfo[] = items
        .filter((m) => typeof m?.id === 'string' && m.id.trim().length > 0)
        .map((m) => ({
          id: m.id,
          ownedBy: m.owned_by,
          capabilities: getGroqModelCapabilities(m.id),
        }));
      this.modelCache = {
        keyHash,
        fetchedAt: Date.now(),
        models,
      };
      return models;
    } catch (err) {
      throw normalizeProviderError(err, 'groq');
    }
  }

  private async verifyModelAvailable(client: Groq, model: string): Promise<void> {
    if (!client.models || typeof client.models.list !== 'function') {
      return;
    }
    const apiKey = this.getApiKey();
    const keyHash = apiKey ? crypto.createHash('sha256').update(apiKey).digest('hex').slice(0, 12) : 'mock';
    const now = Date.now();
    const models =
      this.modelCache &&
      this.modelCache.keyHash === keyHash &&
      now - this.modelCache.fetchedAt < MODEL_CACHE_TTL_MS
        ? this.modelCache.models
        : await this.fetchModelsWithClient(client, keyHash);

    if (models.length === 0) return;

    const found = models.find((m) => m.id === model);
    if (!found) {
      const chatSuggestions = models
        .filter((m) => m.capabilities.supportsChat)
        .slice(0, 6)
        .map((m) => m.id)
        .join(', ');
      throw new AiProviderError({
        code: 'MODEL_UNAVAILABLE',
        status: 400,
        provider: 'groq',
        message: `Configured Groq model "${model}" is not available for your Groq account.${
          chatSuggestions ? ` Available chat models: ${chatSuggestions}.` : ''
        }`,
        retryable: false,
      });
    }
  }

  private validateAndBuildMessages(
    request: AiGenerateRequest,
    model: string,
    caps: AiModelCapabilities,
    extraSystemNotes: string[]
  ): {
    messages: ChatCompletionMessageParam[];
    hasImages: boolean;
  } {
    if (!caps.supportsChat) {
      throw new AiProviderError({
        code: 'UNSUPPORTED_CAPABILITY',
        status: 422,
        provider: 'groq',
        message: `Groq model "${model}" is not a text/chat generation model (for example, audio-only models cannot answer academic prompts). Update GROQ_MODEL to a chat model such as ${DEFAULT_GROQ_MODEL}.`,
        retryable: false,
      });
    }

    const parts =
      request.parts && request.parts.length > 0
        ? request.parts
        : request.prompt
          ? [{ text: request.prompt }]
          : [];

    const userContentParts: ChatCompletionContentPart[] = [];
    let imageCount = 0;

    for (const part of parts) {
      if (typeof part.text === 'string' && part.text.trim()) {
        userContentParts.push({ type: 'text', text: part.text });
      } else if (part.inlineData?.data && part.inlineData?.mimeType) {
        const { mimeType, data, fileName } = part.inlineData;
        if (mimeType.startsWith('image/')) {
          if (!caps.supportsVision) {
            throw new AiProviderError({
              code: 'UNSUPPORTED_CAPABILITY',
              status: 422,
              provider: 'groq',
              message: `Groq model "${model}" does not support image recognition or visual OCR. Configure GROQ_MODEL=meta-llama/llama-4-scout-17b-16e-instruct for Groq vision support, or enable an explicit fallback provider.`,
              retryable: true,
            });
          }
          imageCount += 1;
          if (imageCount > 5) {
            throw new AiProviderError({
              code: 'UNSUPPORTED_CAPABILITY',
              status: 400,
              provider: 'groq',
              message: 'Groq vision models accept at most 5 images per request. Please attach fewer images.',
              retryable: false,
            });
          }
          userContentParts.push({
            type: 'image_url',
            image_url: {
              url: `data:${mimeType};base64,${data}`,
            },
          });
        } else {
          throw new AiProviderError({
            code: 'UNSUPPORTED_CAPABILITY',
            status: 422,
            provider: 'groq',
            message: `Groq Chat Completions cannot directly parse raw binary file "${
              fileName || mimeType
            }" without extracted text. Upload a DOCX, XLSX, PPTX, TXT, or text-extracted document, or configure an explicit fallback provider for native binary PDF analysis.`,
            retryable: true,
          });
        }
      }
    }

    if (request.useWebSearch && !caps.supportsBrowserSearch && !caps.supportsBuiltInSearch) {
      throw new AiProviderError({
        code: 'UNSUPPORTED_CAPABILITY',
        status: 422,
        provider: 'groq',
        message: `Groq model "${model}" does not support live browser/web search. Use ${DEFAULT_GROQ_MODEL} or openai/gpt-oss-120b for Groq browser search.`,
        retryable: true,
      });
    }

    const systemParts: string[] = [];
    if (request.systemInstruction?.trim()) {
      systemParts.push(request.systemInstruction.trim());
    }
    for (const note of extraSystemNotes) {
      if (note.trim()) systemParts.push(note.trim());
    }

    const messages: ChatCompletionMessageParam[] = [];
    if (systemParts.length > 0) {
      messages.push({ role: 'system', content: systemParts.join('\n\n') });
    }

    if (userContentParts.length === 0) {
      messages.push({ role: 'user', content: '' });
    } else if (imageCount === 0) {
      const combinedText = userContentParts
        .map((p) => (p.type === 'text' ? p.text : ''))
        .filter(Boolean)
        .join('\n\n');
      messages.push({ role: 'user', content: combinedText });
    } else {
      messages.push({ role: 'user', content: userContentParts });
    }

    return {
      messages,
      hasImages: imageCount > 0,
    };
  }

  private buildCompletionParams(opts: {
    request: AiGenerateRequest;
    model: string;
    caps: AiModelCapabilities;
    useJsonSchema: boolean;
    useJsonObject: boolean;
    includeWebSearch: boolean;
    includeReasoning: boolean;
  }): ChatCompletionCreateParamsNonStreaming {
    const { request, model, caps, useJsonSchema, useJsonObject, includeWebSearch, includeReasoning } = opts;

    const extraNotes: string[] = [];
    if (request.jsonSchema && !useJsonSchema) {
      extraNotes.push(
        `Respond strictly with valid JSON matching this JSON Schema (no markdown fences, no extra commentary):\n${JSON.stringify(
          request.jsonSchema.schema
        )}`
      );
    } else if (request.jsonMode && !useJsonSchema && !useJsonObject) {
      extraNotes.push('Respond strictly with a valid JSON object.');
    }

    const { messages } = this.validateAndBuildMessages(request, model, caps, extraNotes);

    const params: ChatCompletionCreateParamsNonStreaming = {
      model,
      messages,
      max_completion_tokens: getMaxCompletionTokens(request.taskType),
    };

    if (includeReasoning && request.reasoningEffort && caps.supportsReasoningEffort) {
      if (model.toLowerCase().includes('qwen3')) {
        params.reasoning_effort = 'default';
      } else {
        params.reasoning_effort = request.reasoningEffort;
      }
    }

    // Groq documents that browser_search is incompatible with structured outputs/response_format
    const hasResponseFormat = useJsonSchema || useJsonObject;
    if (includeWebSearch && !hasResponseFormat && caps.supportsBrowserSearch) {
      params.tools = [{ type: 'browser_search' }];
      params.tool_choice = 'required';
    }

    if (request.jsonSchema && useJsonSchema) {
      params.response_format = {
        type: 'json_schema',
        json_schema: {
          name: request.jsonSchema.name.slice(0, 64),
          strict: true,
          schema: toOpenAiStrictSchema(request.jsonSchema.schema),
        },
      };
    } else if ((request.jsonSchema || request.jsonMode) && useJsonObject) {
      params.response_format = { type: 'json_object' };
    }

    return params;
  }

  public async generate(request: AiGenerateRequest): Promise<AiGenerateResponse> {
    const startedAt = Date.now();
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const client = this.getClient(timeoutMs);
    const model = request.modelOverride?.trim() || this.getDefaultModel(request.taskType);
    const caps = getGroqModelCapabilities(model);

    try {
      await this.verifyModelAvailable(client, model);

      let useJsonSchema = Boolean(request.jsonSchema && caps.supportsStructuredOutput);
      let useJsonObject = Boolean(
        !useJsonSchema && (request.jsonSchema || request.jsonMode) && caps.supportsJsonMode
      );
      let includeWebSearch = Boolean(
        request.useWebSearch &&
          !request.jsonSchema &&
          !request.jsonMode &&
          (caps.supportsBrowserSearch || caps.supportsBuiltInSearch)
      );
      let includeReasoning = Boolean(request.reasoningEffort && caps.supportsReasoningEffort);

      // Run upfront validation so unsupported images/PDFs/web-search fail fast before network call
      this.validateAndBuildMessages(request, model, caps, []);

      const runCall = async () => {
        const params = this.buildCompletionParams({
          request,
          model,
          caps,
          useJsonSchema,
          useJsonObject,
          includeWebSearch,
          includeReasoning,
        });
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        try {
          return await client.chat.completions.create(params, { signal: controller.signal });
        } finally {
          clearTimeout(timer);
        }
      };

      let completion;
      try {
        completion = await runCall();
      } catch (err) {
        const msg = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase();
        const status = (err as { status?: number })?.status;
        if (status === 400 && useJsonSchema && (msg.includes('json_schema') || msg.includes('response_format') || msg.includes('schema'))) {
          useJsonSchema = false;
          useJsonObject = caps.supportsJsonMode;
          completion = await runCall();
        } else if (status === 400 && useJsonObject && msg.includes('response_format')) {
          useJsonObject = false;
          completion = await runCall();
        } else if (status === 400 && includeReasoning && msg.includes('reasoning')) {
          includeReasoning = false;
          completion = await runCall();
        } else if (status === 400 && includeWebSearch && (msg.includes('browser_search') || msg.includes('tool'))) {
          includeWebSearch = false;
          completion = await runCall();
        } else {
          throw err;
        }
      }

      const message = completion.choices?.[0]?.message;
      const text = message?.content || '';
      const inputTokens = completion.usage?.prompt_tokens ?? 0;
      const outputTokens = completion.usage?.completion_tokens ?? 0;
      const totalTokens = completion.usage?.total_tokens ?? inputTokens + outputTokens;
      const durationMs = Date.now() - startedAt;
      const usedModel = completion.model || model;
      const sources = extractGroqSources(message);

      return {
        text,
        provider: 'groq',
        model: usedModel,
        usageStats: {
          provider: 'groq',
          model: usedModel,
          inputTokens,
          outputTokens,
          totalTokens,
          durationMs,
          status: 'ok',
        },
        sources,
        webSearchAvailable: includeWebSearch,
      };
    } catch (err) {
      throw normalizeProviderError(err, 'groq');
    }
  }

  public async generateStream(
    request: AiGenerateRequest,
    onDelta: (delta: string) => void
  ): Promise<AiGenerateResponse> {
    const startedAt = Date.now();
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const client = this.getClient(timeoutMs);
    const model = request.modelOverride?.trim() || this.getDefaultModel(request.taskType);
    const caps = getGroqModelCapabilities(model);

    try {
      await this.verifyModelAvailable(client, model);

      const baseParams = this.buildCompletionParams({
        request,
        model,
        caps,
        useJsonSchema: Boolean(request.jsonSchema && caps.supportsStructuredOutput),
        useJsonObject: Boolean(!caps.supportsStructuredOutput && (request.jsonSchema || request.jsonMode) && caps.supportsJsonMode),
        includeWebSearch: Boolean(request.useWebSearch && !request.jsonSchema && !request.jsonMode),
        includeReasoning: Boolean(request.reasoningEffort && caps.supportsReasoningEffort),
      });

      const streamParams: ChatCompletionCreateParamsStreaming = {
        ...baseParams,
        stream: true,
      };

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      let fullText = '';
      let usedModel = model;
      let inputTokens = 0;
      let outputTokens = 0;
      let totalTokens = 0;

      try {
        const stream = await client.chat.completions.create(streamParams, {
          signal: controller.signal,
        });
        for await (const chunk of stream) {
          if (chunk.model) usedModel = chunk.model;
          const delta = chunk.choices?.[0]?.delta?.content;
          if (typeof delta === 'string' && delta.length > 0) {
            fullText += delta;
            onDelta(delta);
          }
          const chunkUsage = chunk.x_groq?.usage;
          if (chunkUsage) {
            inputTokens = chunkUsage.prompt_tokens ?? inputTokens;
            outputTokens = chunkUsage.completion_tokens ?? outputTokens;
            totalTokens = chunkUsage.total_tokens ?? inputTokens + outputTokens;
          }
        }
      } finally {
        clearTimeout(timer);
      }

      const durationMs = Date.now() - startedAt;
      return {
        text: fullText,
        provider: 'groq',
        model: usedModel,
        usageStats: {
          provider: 'groq',
          model: usedModel,
          inputTokens,
          outputTokens,
          totalTokens,
          durationMs,
          status: 'ok',
        },
        sources: [],
        webSearchAvailable: false,
      };
    } catch (err) {
      throw normalizeProviderError(err, 'groq');
    }
  }
}
