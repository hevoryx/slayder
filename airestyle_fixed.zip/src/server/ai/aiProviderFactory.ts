import { AiProviderError, normalizeProviderError, parseStructuredJson } from './aiErrors.ts';
import type {
  AiGenerateRequest,
  AiGenerateResponse,
  AiHealthStatus,
  AiModelInfo,
  AiProvider,
  AiProviderName,
  AiTaskType,
} from './aiTypes.ts';
import { aiUsageTracker } from './aiUsageTracker.ts';
import { GeminiProvider } from './providers/geminiProvider.ts';
import { GroqProvider } from './providers/groqProvider.ts';
import { OpenAiProvider } from './providers/openaiProvider.ts';

const openaiProvider = new OpenAiProvider();
const geminiProvider = new GeminiProvider();
const groqProvider = new GroqProvider();

const providers: Record<AiProviderName, AiProvider> = {
  openai: openaiProvider,
  gemini: geminiProvider,
  groq: groqProvider,
};

let runtimeProviderOverride: AiProviderName | null = null;
const runtimeModelOverrides: Partial<Record<AiProviderName, string>> = {};
let runtimeFallbackOverride: AiProviderName | null | undefined = undefined;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export function parseProviderEnv(val: string | undefined): AiProviderName | null {
  const normalized = val?.trim().toLowerCase();
  if (normalized === 'openai') return 'openai';
  if (normalized === 'gemini') return 'gemini';
  if (normalized === 'groq') return 'groq';
  return null;
}

export function resolveEnvProviderName(): AiProviderName | null {
  return parseProviderEnv(process.env.AI_PROVIDER);
}

export function resolvePrimaryProviderName(): AiProviderName {
  if (runtimeProviderOverride) {
    return runtimeProviderOverride;
  }
  const explicit = resolveEnvProviderName();
  if (explicit) {
    return explicit;
  }
  if (openaiProvider.isConfigured()) {
    return 'openai';
  }
  if (groqProvider.isConfigured()) {
    return 'groq';
  }
  if (geminiProvider.isConfigured()) {
    return 'gemini';
  }
  return 'openai';
}

export function resolveFallbackProviderName(primary: AiProviderName): AiProviderName | null {
  if (runtimeFallbackOverride !== undefined) {
    if (!runtimeFallbackOverride || runtimeFallbackOverride === primary) return null;
    return providers[runtimeFallbackOverride].isConfigured() ? runtimeFallbackOverride : null;
  }
  const explicit = parseProviderEnv(process.env.AI_FALLBACK_PROVIDER);
  if (!explicit || explicit === primary) {
    return null;
  }
  if (!providers[explicit].isConfigured()) {
    return null;
  }
  return explicit;
}

export function getProvider(name?: AiProviderName): AiProvider {
  return providers[name ?? resolvePrimaryProviderName()];
}

export function getEffectiveModel(providerName: AiProviderName, taskType?: AiTaskType): string {
  return runtimeModelOverrides[providerName] || providers[providerName].getDefaultModel(taskType);
}

export function setRuntimeProviderConfig(params: {
  provider: AiProviderName;
  model?: string;
  fallbackProvider?: AiProviderName | null;
}): AiHealthStatus {
  const target = providers[params.provider];
  if (!target) {
    throw new AiProviderError({
      code: 'SERVER_ERROR',
      status: 400,
      provider: params.provider,
      message: `Unsupported AI provider "${String(params.provider)}".`,
      retryable: false,
    });
  }
  if (!target.isConfigured()) {
    const label = params.provider === 'openai' ? 'OpenAI' : params.provider === 'gemini' ? 'Gemini' : 'Groq';
    throw new AiProviderError({
      code: 'MISSING_API_KEY',
      status: 400,
      provider: params.provider,
      message: `${label} cannot be activated because its server API key is not configured.`,
      retryable: false,
    });
  }

  if (params.model !== undefined) {
    const cleanModel = params.model.trim();
    const isValidFormat = Boolean(cleanModel) && cleanModel.length <= 100 && /^[a-zA-Z0-9._:/-]+$/.test(cleanModel);
    const matchesProviderFamily =
      params.provider === 'gemini'
        ? /^(?:models\/)?(?:gemini-|genie-|lyria-)/i.test(cleanModel)
        : params.provider === 'openai'
          ? /^(?:gpt-|o[1-9]|chatgpt-)/i.test(cleanModel)
          : cleanModel.length >= 3;

    if (!isValidFormat || !matchesProviderFamily) {
      throw new AiProviderError({
        code: 'MODEL_UNAVAILABLE',
        status: 400,
        provider: params.provider,
        message: `Invalid model identifier "${cleanModel || '(empty)'}" for ${params.provider}.`,
        retryable: false,
      });
    }
    runtimeModelOverrides[params.provider] = cleanModel;
  }

  if (params.fallbackProvider !== undefined) {
    if (params.fallbackProvider === null || params.fallbackProvider === params.provider) {
      runtimeFallbackOverride = null;
    } else if (!providers[params.fallbackProvider]?.isConfigured()) {
      throw new AiProviderError({
        code: 'MISSING_API_KEY',
        status: 400,
        provider: params.fallbackProvider,
        message: `Fallback provider "${params.fallbackProvider}" is not configured on the server.`,
        retryable: false,
      });
    } else {
      runtimeFallbackOverride = params.fallbackProvider;
    }
  }

  runtimeProviderOverride = params.provider;
  return getAiHealthStatus();
}

export function resetRuntimeProviderConfig(): void {
  runtimeProviderOverride = null;
  delete runtimeModelOverrides.openai;
  delete runtimeModelOverrides.gemini;
  delete runtimeModelOverrides.groq;
  runtimeFallbackOverride = undefined;
}

export async function listGroqModels(forceRefresh = false): Promise<AiModelInfo[]> {
  return groqProvider.listAvailableModels(forceRefresh);
}

export function getAiHealthStatus(taskType?: AiTaskType): AiHealthStatus {
  const primaryName = resolvePrimaryProviderName();
  const primary = providers[primaryName];
  const fallback = resolveFallbackProviderName(primaryName);
  const openaiConfigured = openaiProvider.isConfigured();
  const geminiConfigured = geminiProvider.isConfigured();
  const groqConfigured = groqProvider.isConfigured();

  return {
    ok: true,
    provider: primaryName,
    envProvider: resolveEnvProviderName(),
    model: getEffectiveModel(primaryName, taskType),
    openaiConfigured,
    geminiConfigured,
    groqConfigured,
    fallbackProvider: fallback,
    hasApiKey: primary.isConfigured(),
  };
}

async function runWithRetry(
  provider: AiProvider,
  request: AiGenerateRequest,
  maxAttempts = 2
): Promise<AiGenerateResponse> {
  let lastError: AiProviderError | undefined;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await provider.generate(request);
    } catch (err) {
      const normalized = normalizeProviderError(err, provider.name);
      lastError = normalized;
      // Do not retry non-transient capability or quota errors within the same provider
      const shouldRetrySameProvider =
        normalized.retryable &&
        attempt < maxAttempts &&
        normalized.code !== 'INSUFFICIENT_QUOTA' &&
        normalized.code !== 'UNSUPPORTED_CAPABILITY';
      if (shouldRetrySameProvider) {
        await sleep(450 * attempt);
        continue;
      }
      throw normalized;
    }
  }
  throw lastError!;
}

function recordOutcome(
  providerName: AiProviderName,
  model: string,
  taskType: AiTaskType,
  durationMs: number,
  response?: AiGenerateResponse,
  error?: AiProviderError
): void {
  if (response) {
    aiUsageTracker.record({
      provider: response.provider,
      model: response.model,
      taskType,
      inputTokens: response.usageStats.inputTokens,
      outputTokens: response.usageStats.outputTokens,
      totalTokens: response.usageStats.totalTokens,
      durationMs: response.usageStats.durationMs ?? durationMs,
      status: 'ok',
    });
  } else if (error) {
    aiUsageTracker.record({
      provider: providerName,
      model,
      taskType,
      inputTokens: 0,
      outputTokens: 0,
      totalTokens: 0,
      durationMs,
      status: 'error',
      errorCode: error.code,
      errorMessage: error.message,
    });
  }
}

export async function executeAiRequest(request: AiGenerateRequest): Promise<AiGenerateResponse> {
  const primaryName = resolvePrimaryProviderName();
  const primary = providers[primaryName];
  const fallbackName = resolveFallbackProviderName(primaryName);
  const taskType = request.taskType ?? 'chat';
  const effectiveModel = request.modelOverride?.trim() || getEffectiveModel(primaryName, taskType);
  const effectiveReq: AiGenerateRequest =
    request.modelOverride?.trim() || !runtimeModelOverrides[primaryName]
      ? request
      : { ...request, modelOverride: runtimeModelOverrides[primaryName] };
  const startedAt = Date.now();

  try {
    const response = await runWithRetry(primary, effectiveReq);
    recordOutcome(primaryName, effectiveModel, taskType, Date.now() - startedAt, response);
    return response;
  } catch (err) {
    const normalized = normalizeProviderError(err, primaryName);
    recordOutcome(primaryName, effectiveModel, taskType, Date.now() - startedAt, undefined, normalized);

    const canUseExplicitFallback =
      Boolean(fallbackName) &&
      (normalized.retryable || normalized.code === 'UNSUPPORTED_CAPABILITY');

    if (fallbackName && canUseExplicitFallback) {
      const fallback = providers[fallbackName];
      const fallbackModel = getEffectiveModel(fallbackName, taskType);
      const fallbackStarted = Date.now();
      // Clear model override if it belonged to the primary provider's naming family
      const fallbackReq: AiGenerateRequest = {
        ...request,
        modelOverride: runtimeModelOverrides[fallbackName],
      };
      try {
        const fbResponse = await runWithRetry(fallback, fallbackReq);
        recordOutcome(fallbackName, fallbackModel, taskType, Date.now() - fallbackStarted, fbResponse);
        return fbResponse;
      } catch (fbErr) {
        const fbNormalized = normalizeProviderError(fbErr, fallbackName);
        recordOutcome(fallbackName, fallbackModel, taskType, Date.now() - fallbackStarted, undefined, fbNormalized);
        throw fbNormalized;
      }
    }
    throw normalized;
  }
}

export async function executeAiStreamRequest(
  request: AiGenerateRequest,
  onDelta: (delta: string) => void
): Promise<AiGenerateResponse> {
  const primaryName = resolvePrimaryProviderName();
  const primary = providers[primaryName];
  const taskType = request.taskType ?? 'chat';
  const effectiveModel = request.modelOverride?.trim() || getEffectiveModel(primaryName, taskType);
  const effectiveReq: AiGenerateRequest =
    request.modelOverride?.trim() || !runtimeModelOverrides[primaryName]
      ? request
      : { ...request, modelOverride: runtimeModelOverrides[primaryName] };
  const startedAt = Date.now();

  try {
    const response = primary.generateStream
      ? await primary.generateStream(effectiveReq, onDelta)
      : await primary.generate(effectiveReq).then((res) => {
          if (res.text) onDelta(res.text);
          return res;
        });
    recordOutcome(primaryName, effectiveModel, taskType, Date.now() - startedAt, response);
    return response;
  } catch (err) {
    const normalized = normalizeProviderError(err, primaryName);
    recordOutcome(primaryName, effectiveModel, taskType, Date.now() - startedAt, undefined, normalized);
    throw normalized;
  }
}

export async function executeStructuredAiRequest<T>(
  request: AiGenerateRequest
): Promise<{ data: T; response: AiGenerateResponse }> {
  const response = await executeAiRequest(request);
  const data = parseStructuredJson<T>(response.text, response.provider);
  return { data, response };
}

export function describeGeminiAuth() {
  return geminiProvider.describeAuth();
}

/** Sends a tiny request to verify the active provider key really works. */
export async function pingProvider(name?: AiProviderName): Promise<{
  ok: boolean;
  provider: AiProviderName;
  model: string;
  latencyMs: number;
  error?: string;
  code?: string;
}> {
  const providerName = name ?? resolvePrimaryProviderName();
  const startedAt = Date.now();
  const model = getEffectiveModel(providerName);
  try {
    await providers[providerName].generate({
      taskType: 'chat',
      prompt: 'Reply with the single word: pong',
      timeoutMs: 20_000,
    });
    return { ok: true, provider: providerName, model, latencyMs: Date.now() - startedAt };
  } catch (err) {
    const e = normalizeProviderError(err, providerName);
    return { ok: false, provider: providerName, model, latencyMs: Date.now() - startedAt, error: e.message, code: e.code };
  }
}
