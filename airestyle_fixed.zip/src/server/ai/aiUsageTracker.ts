import { sanitizeErrorText } from './aiErrors.ts';
import type { AiProviderName, AiTaskType } from './aiTypes.ts';

export interface ProviderUsageAggregate {
  provider: AiProviderName;
  lastModel: string | null;
  totalRequests: number;
  successCount: number;
  errorCount: number;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  totalDurationMs: number;
  avgDurationMs: number;
}

export interface UsageLogEntry {
  provider: AiProviderName;
  model: string;
  taskType: AiTaskType;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  durationMs: number;
  status: 'ok' | 'error';
  errorCode?: string;
  errorMessage?: string;
  timestamp: string;
}

export interface UsageSummarySnapshot {
  providers: Record<AiProviderName, ProviderUsageAggregate>;
  recent: UsageLogEntry[];
}

function emptyAggregate(provider: AiProviderName): ProviderUsageAggregate {
  return {
    provider,
    lastModel: null,
    totalRequests: 0,
    successCount: 0,
    errorCount: 0,
    inputTokens: 0,
    outputTokens: 0,
    totalTokens: 0,
    totalDurationMs: 0,
    avgDurationMs: 0,
  };
}

const MAX_RECENT_ENTRIES = 100;

class AiUsageTracker {
  private aggregates: Record<AiProviderName, ProviderUsageAggregate> = {
    openai: emptyAggregate('openai'),
    gemini: emptyAggregate('gemini'),
    groq: emptyAggregate('groq'),
  };

  private recent: UsageLogEntry[] = [];

  public record(entry: Omit<UsageLogEntry, 'timestamp'>): void {
    const agg = this.aggregates[entry.provider];
    agg.totalRequests += 1;
    agg.lastModel = entry.model || agg.lastModel;
    if (entry.status === 'ok') {
      agg.successCount += 1;
    } else {
      agg.errorCount += 1;
    }
    agg.inputTokens += Math.max(0, entry.inputTokens || 0);
    agg.outputTokens += Math.max(0, entry.outputTokens || 0);
    agg.totalTokens += Math.max(0, entry.totalTokens || 0);
    agg.totalDurationMs += Math.max(0, Math.round(entry.durationMs || 0));
    agg.avgDurationMs =
      agg.totalRequests > 0 ? Math.round(agg.totalDurationMs / agg.totalRequests) : 0;

    const cleanEntry: UsageLogEntry = {
      ...entry,
      durationMs: Math.max(0, Math.round(entry.durationMs || 0)),
      errorMessage: entry.errorMessage ? sanitizeErrorText(entry.errorMessage).slice(0, 300) : undefined,
      timestamp: new Date().toISOString(),
    };
    this.recent.unshift(cleanEntry);
    if (this.recent.length > MAX_RECENT_ENTRIES) {
      this.recent.length = MAX_RECENT_ENTRIES;
    }
  }

  public getSummary(): UsageSummarySnapshot {
    return {
      providers: {
        openai: { ...this.aggregates.openai },
        gemini: { ...this.aggregates.gemini },
        groq: { ...this.aggregates.groq },
      },
      recent: this.recent.map((r) => ({ ...r })),
    };
  }

  public reset(): void {
    this.aggregates = {
      openai: emptyAggregate('openai'),
      gemini: emptyAggregate('gemini'),
      groq: emptyAggregate('groq'),
    };
    this.recent = [];
  }
}

export const aiUsageTracker = new AiUsageTracker();
