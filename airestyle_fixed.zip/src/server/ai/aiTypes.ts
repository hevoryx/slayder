export type AiProviderName = 'openai' | 'gemini' | 'groq';

export type ReasoningEffortLevel = 'low' | 'medium' | 'high';

export type AiTaskType =
  | 'chat'
  | 'document'
  | 'presentation'
  | 'coursework'
  | 'reasoning'
  | 'analysis'
  | 'exam'
  | 'translation'
  | 'research'
  | 'career';

export interface AiUsageStats {
  provider: AiProviderName;
  model: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  durationMs: number;
  status?: 'ok' | 'error';
}

export interface AiSourceReference {
  title: string;
  uri: string;
}

export interface AiInputPart {
  text?: string;
  inlineData?: {
    mimeType: string;
    data: string;
    fileName?: string;
  };
}

export type AiSchemaType = 'object' | 'array' | 'string' | 'number' | 'integer' | 'boolean';

export interface AiJsonSchema {
  type: AiSchemaType;
  description?: string;
  enum?: string[];
  properties?: Record<string, AiJsonSchema>;
  items?: AiJsonSchema;
  required?: string[];
}

export interface AiGenerateRequest {
  taskType?: AiTaskType;
  systemInstruction?: string;
  prompt?: string;
  parts?: AiInputPart[];
  reasoningEffort?: ReasoningEffortLevel;
  modelOverride?: string;
  useWebSearch?: boolean;
  jsonSchema?: {
    name: string;
    schema: AiJsonSchema;
  };
  jsonMode?: boolean;
  timeoutMs?: number;
}

export interface AiGenerateResponse {
  text: string;
  provider: AiProviderName;
  model: string;
  usageStats: AiUsageStats;
  sources: AiSourceReference[];
  webSearchAvailable: boolean;
}

export interface AiModelCapabilities {
  supportsChat: boolean;
  supportsVision: boolean;
  supportsBrowserSearch: boolean;
  supportsBuiltInSearch: boolean;
  supportsStructuredOutput: boolean;
  supportsJsonMode: boolean;
  supportsReasoningEffort: boolean;
  supportsToolCalling: boolean;
}

export interface AiModelInfo {
  id: string;
  ownedBy?: string;
  capabilities: AiModelCapabilities;
}

export interface AiProvider {
  readonly name: AiProviderName;
  isConfigured(): boolean;
  getDefaultModel(taskType?: AiTaskType): string;
  generate(request: AiGenerateRequest): Promise<AiGenerateResponse>;
  generateStream?(
    request: AiGenerateRequest,
    onDelta: (delta: string) => void
  ): Promise<AiGenerateResponse>;
}

export interface AiHealthStatus {
  ok: boolean;
  provider: AiProviderName;
  envProvider?: AiProviderName | null;
  model: string;
  openaiConfigured: boolean;
  geminiConfigured: boolean;
  groqConfigured: boolean;
  fallbackProvider: AiProviderName | null;
  hasApiKey: boolean;
}
