import type { AiProviderName } from './aiTypes.ts';

export type AiErrorCode =
  | 'MISSING_API_KEY'
  | 'INVALID_API_KEY'
  | 'INSUFFICIENT_QUOTA'
  | 'RATE_LIMIT'
  | 'MODEL_UNAVAILABLE'
  | 'UNSUPPORTED_CAPABILITY'
  | 'INVALID_STRUCTURED_OUTPUT'
  | 'TIMEOUT'
  | 'NETWORK_ERROR'
  | 'SERVER_ERROR';

export class AiProviderError extends Error {
  public readonly code: AiErrorCode;
  public readonly status: number;
  public readonly provider: AiProviderName;
  public readonly retryable: boolean;

  constructor(params: {
    code: AiErrorCode;
    status: number;
    provider: AiProviderName;
    message: string;
    retryable?: boolean;
  }) {
    super(params.message);
    this.name = 'AiProviderError';
    this.code = params.code;
    this.status = params.status;
    this.provider = params.provider;
    this.retryable = Boolean(params.retryable);
  }
}

/**
 * Redacts potential API key or Bearer token substrings so secret material is
 * never echoed in error logs or HTTP responses.
 */
export function sanitizeErrorText(raw: string): string {
  return raw
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, 'Bearer [REDACTED]')
    .replace(
      /\b(sk-[A-Za-z0-9_\-]{10,}|gsk_[A-Za-z0-9_\-]{10,}|AIza[A-Za-z0-9_\-]{10,}|AQ\.[A-Za-z0-9._\-]{10,}|key_[A-Za-z0-9_\-]{6,})\b/g,
      '[REDACTED]'
    );
}

const extractHttpStatus = (err: unknown): number | undefined => {
  if (typeof err === 'object' && err !== null) {
    const e = err as { status?: unknown; statusCode?: unknown; code?: unknown };
    if (typeof e.status === 'number') return e.status;
    if (typeof e.statusCode === 'number') return e.statusCode;
    if (typeof e.code === 'number') return e.code;
  }
  return undefined;
};

const extractErrorCode = (err: unknown): string => {
  if (typeof err === 'object' && err !== null) {
    const e = err as { code?: unknown; type?: unknown; name?: unknown; error?: { code?: unknown; type?: unknown } };
    const parts = [e.code, e.type, e.name, e.error?.code, e.error?.type]
      .filter((v): v is string => typeof v === 'string')
      .join(' ');
    return parts.toLowerCase();
  }
  return '';
};

function getProviderMeta(provider: AiProviderName): { label: string; envKeyName: string } {
  switch (provider) {
    case 'openai':
      return { label: 'OpenAI', envKeyName: 'OPENAI_API_KEY' };
    case 'gemini':
      return { label: 'Gemini', envKeyName: 'GEMINI_API_KEY' };
    case 'groq':
      return { label: 'Groq', envKeyName: 'GROQ_API_KEY' };
  }
}

export function normalizeProviderError(err: unknown, provider: AiProviderName): AiProviderError {
  if (err instanceof AiProviderError) {
    return err;
  }

  const { label: providerLabel, envKeyName } = getProviderMeta(provider);
  const status = extractHttpStatus(err);
  const codeText = extractErrorCode(err);
  const rawMessage = sanitizeErrorText(err instanceof Error ? err.message : String(err));
  const lower = `${codeText} ${rawMessage}`.toLowerCase();

  if (lower.includes('missing_api_key')) {
    return new AiProviderError({
      code: 'MISSING_API_KEY',
      status: 503,
      provider,
      message: `${providerLabel} API key is not configured on the server. Add ${envKeyName} in environment settings.`,
      retryable: false,
    });
  }

  if (
    status === 401 ||
    lower.includes('api_key_invalid') ||
    lower.includes('invalid_api_key') ||
    lower.includes('invalid api key') ||
    lower.includes('incorrect api key') ||
    lower.includes('authenticationerror') ||
    (status === 403 && (lower.includes('permission_denied') || lower.includes('invalid') || lower.includes('unauthorized')))
  ) {
    return new AiProviderError({
      code: 'INVALID_API_KEY',
      status: status === 403 ? 403 : 401,
      provider,
      message: `${providerLabel} API key authentication failed. Check ${envKeyName} in server environment settings.`,
      retryable: false,
    });
  }

  if (
    status === 402 ||
    lower.includes('insufficient_quota') ||
    lower.includes('billing') ||
    lower.includes('exceeded your current quota') ||
    lower.includes('credit')
  ) {
    return new AiProviderError({
      code: 'INSUFFICIENT_QUOTA',
      status: 402,
      provider,
      message: `${providerLabel} API quota or credits exhausted. Please check your ${providerLabel} billing and quota.`,
      retryable: true,
    });
  }

  if (
    status === 429 ||
    lower.includes('rate_limit') ||
    lower.includes('rate limit') ||
    lower.includes('resource_exhausted') ||
    lower.includes('too many requests') ||
    lower.includes('tokens per minute') ||
    lower.includes('requests per minute')
  ) {
    return new AiProviderError({
      code: 'RATE_LIMIT',
      status: 429,
      provider,
      message: `${providerLabel} rate limit reached. Please wait briefly and try again.`,
      retryable: true,
    });
  }

  if (
    lower.includes('timeout') ||
    lower.includes('timed out') ||
    lower.includes('aborted') ||
    lower.includes('aborterror') ||
    status === 504 ||
    status === 408
  ) {
    return new AiProviderError({
      code: 'TIMEOUT',
      status: 504,
      provider,
      message: `${providerLabel} request timed out. Please try again with a shorter input or retry shortly.`,
      retryable: true,
    });
  }

  if (
    lower.includes('econnreset') ||
    lower.includes('econnrefused') ||
    lower.includes('enotfound') ||
    lower.includes('fetch failed') ||
    lower.includes('apiconnectionerror') ||
    lower.includes('network')
  ) {
    return new AiProviderError({
      code: 'NETWORK_ERROR',
      status: 502,
      provider,
      message: `Unable to reach ${providerLabel} API due to a network error. Please try again.`,
      retryable: true,
    });
  }

  if (
    lower.includes('unsupported_capability') ||
    lower.includes('does not support image') ||
    lower.includes('image_url is not supported') ||
    lower.includes('multimodal is not supported')
  ) {
    return new AiProviderError({
      code: 'UNSUPPORTED_CAPABILITY',
      status: 422,
      provider,
      message: rawMessage || `Selected ${providerLabel} model does not support this capability.`,
      retryable: true,
    });
  }

  if (
    status === 404 ||
    lower.includes('model_not_found') ||
    lower.includes('model_decommissioned') ||
    lower.includes('decommissioned') ||
    lower.includes('does not exist or you do not have access') ||
    lower.includes('not_found')
  ) {
    return new AiProviderError({
      code: 'MODEL_UNAVAILABLE',
      status: 502,
      provider,
      message: `Requested ${providerLabel} model is unavailable, decommissioned, or unsupported for your account.`,
      retryable: true,
    });
  }

  if (err instanceof SyntaxError) {
    return new AiProviderError({
      code: 'INVALID_STRUCTURED_OUTPUT',
      status: 502,
      provider,
      message: `${providerLabel} returned malformed structured output. Please try again.`,
      retryable: false,
    });
  }

  const safeStatus = status && status >= 400 && status < 600 ? status : 500;
  return new AiProviderError({
    code: 'SERVER_ERROR',
    status: safeStatus,
    provider,
    message: rawMessage || `${providerLabel} AI request failed.`,
    retryable: safeStatus >= 500,
  });
}

export function stripJsonFences(text: string): string {
  const trimmed = text.trim();
  if (trimmed.startsWith('```')) {
    return trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  }
  return trimmed;
}

function stripNullProperties<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => stripNullProperties(item)) as unknown as T;
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== null && v !== undefined) {
        out[k] = stripNullProperties(v);
      }
    }
    return out as T;
  }
  return value;
}

export function parseStructuredJson<T>(text: string, provider: AiProviderName): T {
  const cleaned = stripJsonFences(text || '');
  if (!cleaned) {
    throw new AiProviderError({
      code: 'INVALID_STRUCTURED_OUTPUT',
      status: 502,
      provider,
      message: 'AI provider returned an empty structured response. Please try again.',
      retryable: false,
    });
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(cleaned);
  } catch (err) {
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace > firstBrace) {
      try {
        parsed = JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));
      } catch {
        throw normalizeProviderError(err, provider);
      }
    } else {
      throw normalizeProviderError(err, provider);
    }
  }

  if (parsed === null || typeof parsed !== 'object') {
    throw new AiProviderError({
      code: 'INVALID_STRUCTURED_OUTPUT',
      status: 502,
      provider,
      message: 'AI provider returned a null or non-object structured response. Please try again.',
      retryable: false,
    });
  }

  return stripNullProperties(parsed as T);
}
