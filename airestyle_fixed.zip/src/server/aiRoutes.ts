import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type { Express, NextFunction, Request, Response } from 'express';
import { initializeApp, getApps, getApp } from 'firebase-admin/app';
import { getAuth, type DecodedIdToken } from 'firebase-admin/auth';
import { createPlanPrompt, createRefineSlidePrompt, SYSTEM_INSTRUCTION_PLAN } from '../../utils/prompts.ts';
import { createCourseOutlinePrompt, createCoursePartPrompt, SYSTEM_INSTRUCTION_COURSE } from '../../utils/courseworkPrompts.ts';
import type { Language, Slide } from '../../types.ts';
import { AiProviderError, normalizeProviderError } from './ai/aiErrors.ts';
import {
  executeAiRequest,
  executeAiStreamRequest,
  executeStructuredAiRequest,
  getAiHealthStatus,
  getEffectiveModel,
  listGroqModels,
  parseProviderEnv,
  resolvePrimaryProviderName,
  setRuntimeProviderConfig,
  describeGeminiAuth,
  pingProvider,
} from './ai/aiProviderFactory.ts';
import { aiUsageTracker } from './ai/aiUsageTracker.ts';
import { GROQ_KNOWN_MODELS, getGroqModelCapabilities } from './ai/providers/groqProvider.ts';
import type { AiInputPart, AiJsonSchema, AiProviderName, AiSourceReference, AiUsageStats } from './ai/aiTypes.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const firebaseConfig = JSON.parse(
  fs.readFileSync(path.resolve(__dirname, '../../firebase-applet-config.json'), 'utf-8')
) as { projectId: string };

const adminApp = getApps().length
  ? getApp()
  : initializeApp({ projectId: firebaseConfig.projectId });
const adminAuth = getAuth(adminApp);

const ALLOWED_LANGUAGES = new Set<Language>(['uz', 'ru', 'en', 'kaa', 'kk']);

const LANGUAGE_LABELS: Record<Language, string> = {
  uz: 'Uzbek (Latin script, literary standard with oʻ and gʻ)',
  ru: 'Russian (academic standard)',
  en: 'English (academic standard)',
  kaa: 'Karakalpak (Latin script, Qaraqalpaqsha)',
  kk: 'Kazakh (Cyrillic script, Қазақ тілі)',
};

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
}

const rateBuckets = new Map<string, { count: number; resetAt: number }>();

const rateLimitMiddleware = (req: AuthRequest, res: Response, next: NextFunction) => {
  const key = req.user?.uid || req.ip || 'anon';
  const now = Date.now();
  const bucket = rateBuckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    rateBuckets.set(key, { count: 1, resetAt: now + 60_000 });
    next();
    return;
  }
  if (bucket.count >= 40) {
    res.status(429).json({ error: 'Rate limit exceeded. Please wait a minute before sending more requests.' });
    return;
  }
  bucket.count += 1;
  next();
};

export const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Authentication required. Please sign in with Google.' });
    return;
  }
  const token = header.slice(7).trim();
  if (!token) {
    res.status(401).json({ error: 'Authentication token is empty.' });
    return;
  }
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: 'Session expired or invalid token. Please sign in again.' });
  }
};

const BOOTSTRAP_ADMIN_EMAIL = 'vickgang87@gmail.com';

const getConfiguredAdminEmails = (): Set<string> => {
  const out = new Set<string>([BOOTSTRAP_ADMIN_EMAIL]);
  const extra = process.env.ADMIN_EMAILS;
  if (extra) {
    for (const part of extra.split(',')) {
      const clean = part.trim().toLowerCase();
      if (clean) out.add(clean);
    }
  }
  return out;
};

export const requireAdmin = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const user = req.user;
  if (!user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  const email = typeof user.email === 'string' ? user.email.toLowerCase() : '';
  const verified = user.email_verified === true;
  const hasAdminClaim = user.admin === true || user.role === 'admin';

  if (verified && (hasAdminClaim || (email && getConfiguredAdminEmails().has(email)))) {
    next();
    return;
  }

  // Fallback to Firestore admins/{uid} when Admin SDK IAM is available
  try {
    const { getFirestore } = await import('firebase-admin/firestore');
    const fsDb = getFirestore(adminApp);
    const adminSnap = await fsDb.doc(`admins/${user.uid}`).get();
    if (adminSnap.exists) {
      next();
      return;
    }
  } catch {
    // Starter-tier projects may not expose IAM to firebase-admin/firestore
  }

  res.status(403).json({ error: 'Administrator privileges required to modify AI provider settings.' });
};

const safeLang = (lang: unknown): Language =>
  typeof lang === 'string' && ALLOWED_LANGUAGES.has(lang as Language) ? (lang as Language) : 'uz';

const combineUsageStats = (primary: AiUsageStats, secondary?: AiUsageStats): AiUsageStats => {
  if (!secondary) return primary;
  return {
    provider: primary.provider,
    model: primary.model,
    inputTokens: primary.inputTokens + secondary.inputTokens,
    outputTokens: primary.outputTokens + secondary.outputTokens,
    totalTokens: primary.totalTokens + secondary.totalTokens,
    durationMs: (primary.durationMs || 0) + (secondary.durationMs || 0),
    status: primary.status ?? 'ok',
  };
};

const handleRouteError = (err: unknown, res: Response): void => {
  const normalized =
    err instanceof AiProviderError ? err : normalizeProviderError(err, resolvePrimaryProviderName());
  res.status(normalized.status).json({
    error: normalized.message,
    code: normalized.code,
    provider: normalized.provider,
  });
};

const ALLOWED_THEMES = [
  'minimalist_light',
  'academic_navy',
  'corporate_slate',
  'modern_blue',
  'minimal_dark',
  'nature_green',
  'scientific_cyan',
  'midnight_gold',
];

const ALLOWED_LAYOUTS = [
  'title',
  'split_left',
  'split_right',
  'minimal_typography',
  'timeline_flow',
  'comparison_grid',
  'editorial_spotlight',
];

const slideSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    sectionTag: { type: 'string' },
    title: { type: 'string' },
    content: { type: 'array', items: { type: 'string' } },
    layout: { type: 'string', enum: ALLOWED_LAYOUTS },
    visualMotif: { type: 'string', enum: ['orbital', 'waves', 'nodes', 'peaks', 'grid', 'prism'] },
    visual: {
      type: 'object',
      properties: {
        kind: {
          type: 'string',
          enum: ['stat', 'steps', 'highlights', 'quote', 'timeline', 'comparison', 'chart', 'table'],
        },
        heading: { type: 'string' },
        items: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              label: { type: 'string' },
              value: { type: 'string' },
              numericValue: { type: 'number' },
            },
            required: ['label', 'value'],
          },
        },
        tableHeaders: { type: 'array', items: { type: 'string' } },
        tableRows: { type: 'array', items: { type: 'array', items: { type: 'string' } } },
      },
      required: ['kind', 'heading', 'items'],
    },
    speakerNotes: { type: 'string' },
  },
  required: ['sectionTag', 'title', 'content', 'layout', 'visualMotif', 'visual', 'speakerNotes'],
};

const chatResponseSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    reply: { type: 'string' },
    recommendedTool: {
      type: 'string',
      enum: ['none', 'documents', 'presentations', 'solver', 'analyzer', 'exams', 'translator', 'research', 'planner', 'tools'],
    },
  },
  required: ['reply', 'recommendedTool'],
};

const documentSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    introduction: { type: 'array', items: { type: 'string' } },
    chapters: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          sections: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                paragraphs: { type: 'array', items: { type: 'string' } },
                examples: { type: 'string' },
              },
              required: ['title', 'paragraphs'],
            },
          },
        },
        required: ['title', 'sections'],
      },
    },
    conclusion: { type: 'array', items: { type: 'string' } },
    references: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          citation: { type: 'string' },
          url: { type: 'string' },
          verified: { type: 'boolean' },
        },
        required: ['citation', 'verified'],
      },
    },
    complianceNote: { type: 'string' },
  },
  required: ['introduction', 'chapters', 'conclusion', 'references', 'complianceNote'],
};

const regenerateSectionSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    paragraphs: { type: 'array', items: { type: 'string' } },
    examples: { type: 'string' },
  },
  required: ['paragraphs'],
};

const presentationPlanSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    themeId: { type: 'string', enum: ALLOWED_THEMES },
    slides: { type: 'array', items: slideSchema },
  },
  required: ['themeId', 'slides'],
};

const courseOutlineSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    title: { type: 'string' },
    chapters: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          sections: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                keyPoints: { type: 'array', items: { type: 'string' } },
              },
              required: ['title', 'keyPoints'],
            },
          },
        },
        required: ['title', 'sections'],
      },
    },
  },
  required: ['title', 'chapters'],
};

const courseIntroPartSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    intro: {
      type: 'object',
      properties: {
        relevance: { type: 'string' },
        goal: { type: 'string' },
        tasks: { type: 'array', items: { type: 'string' } },
        object: { type: 'string' },
        subject: { type: 'string' },
        methods: { type: 'string' },
        structure: { type: 'string' },
      },
      required: ['relevance', 'goal', 'tasks', 'object', 'subject', 'methods', 'structure'],
    },
  },
  required: ['intro'],
};

const courseParagraphsPartSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    paragraphs: { type: 'array', items: { type: 'string' } },
  },
  required: ['paragraphs'],
};

const courseReferencesPartSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    items: { type: 'array', items: { type: 'string' } },
  },
  required: ['items'],
};

const solverSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    extractedExpression: { type: 'string' },
    steps: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          stepNumber: { type: 'integer' },
          title: { type: 'string' },
          explanation: { type: 'string' },
          formulaLatex: { type: 'string' },
          intermediateResult: { type: 'string' },
        },
        required: ['stepNumber', 'title', 'explanation', 'formulaLatex', 'intermediateResult'],
      },
    },
    independentVerification: {
      type: 'object',
      properties: {
        verified: { type: 'boolean' },
        method: { type: 'string' },
        auditNote: { type: 'string' },
        detectedErrors: { type: 'array', items: { type: 'string' } },
      },
      required: ['verified', 'method', 'auditNote', 'detectedErrors'],
    },
    finalAnswer: { type: 'string' },
    finalAnswerLatex: { type: 'string' },
    tableData: {
      type: 'object',
      properties: {
        headers: { type: 'array', items: { type: 'string' } },
        rows: { type: 'array', items: { type: 'array', items: { type: 'string' } } },
      },
      required: ['headers', 'rows'],
    },
    graphPoints: {
      type: 'object',
      properties: {
        xLabel: { type: 'string' },
        yLabel: { type: 'string' },
        seriesName: { type: 'string' },
        points: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              x: { type: 'number' },
              y: { type: 'number' },
              label: { type: 'string' },
            },
            required: ['x', 'y'],
          },
        },
      },
      required: ['xLabel', 'yLabel', 'seriesName', 'points'],
    },
    uncertaintyNote: { type: 'string' },
  },
  required: ['extractedExpression', 'steps', 'independentVerification', 'finalAnswer', 'finalAnswerLatex'],
};

const analyzerSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    extractedTextPreview: { type: 'string' },
    structure: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          heading: { type: 'string' },
          summary: { type: 'string' },
        },
        required: ['heading', 'summary'],
      },
    },
    executiveSummary: { type: 'string' },
    keyFindings: { type: 'array', items: { type: 'string' } },
    studyNotes: { type: 'array', items: { type: 'string' } },
    extractedQA: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          answer: { type: 'string' },
          sourceLocation: { type: 'string' },
        },
        required: ['question', 'answer', 'sourceLocation'],
      },
    },
    quizPreview: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          options: { type: 'array', items: { type: 'string' } },
          correctIndex: { type: 'integer' },
          explanation: { type: 'string' },
        },
        required: ['question', 'options', 'correctIndex', 'explanation'],
      },
    },
    sourceBoundaryNotice: { type: 'string' },
  },
  required: [
    'extractedTextPreview',
    'structure',
    'executiveSummary',
    'keyFindings',
    'studyNotes',
    'extractedQA',
    'quizPreview',
    'sourceBoundaryNotice',
  ],
};

const examSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    questions: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          type: { type: 'string', enum: ['mcq', 'true_false', 'open'] },
          question: { type: 'string' },
          options: { type: 'array', items: { type: 'string' } },
          correctAnswer: { type: 'string' },
          explanation: { type: 'string' },
          topicTag: { type: 'string' },
        },
        required: ['id', 'type', 'question', 'correctAnswer', 'explanation', 'topicTag'],
      },
    },
    flashcards: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string' },
          front: { type: 'string' },
          back: { type: 'string' },
          hint: { type: 'string' },
        },
        required: ['id', 'front', 'back'],
      },
    },
    prepPlan: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          day: { type: 'string' },
          focus: { type: 'string' },
          tasks: { type: 'array', items: { type: 'string' } },
        },
        required: ['day', 'focus', 'tasks'],
      },
    },
  },
  required: ['questions', 'flashcards', 'prepPlan'],
};

const translateSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    outputText: { type: 'string' },
    notes: { type: 'array', items: { type: 'string' } },
    detectedSource: { type: 'string' },
  },
  required: ['outputText', 'notes'],
};

const researchSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    researchQuestions: { type: 'array', items: { type: 'string' } },
    hypotheses: { type: 'array', items: { type: 'string' } },
    literatureSynthesis: { type: 'string' },
    studyComparisons: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          studyTitle: { type: 'string' },
          methodology: { type: 'string' },
          keyFindings: { type: 'string' },
          limitations: { type: 'string' },
        },
        required: ['studyTitle', 'methodology', 'keyFindings', 'limitations'],
      },
    },
    unsupportedClaimsAudit: { type: 'array', items: { type: 'string' } },
    verifiedSources: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          url: { type: 'string' },
          snippet: { type: 'string' },
          citations: {
            type: 'object',
            properties: {
              apa: { type: 'string' },
              mla: { type: 'string' },
              chicago: { type: 'string' },
              ieee: { type: 'string' },
            },
            required: ['apa', 'mla', 'chicago', 'ieee'],
          },
        },
        required: ['title', 'url', 'citations'],
      },
    },
    suggestedDirections: { type: 'array', items: { type: 'string' } },
    integrityNotice: { type: 'string' },
  },
  required: [
    'researchQuestions',
    'hypotheses',
    'literatureSynthesis',
    'studyComparisons',
    'unsupportedClaimsAudit',
    'verifiedSources',
    'suggestedDirections',
    'integrityNotice',
  ],
};

const studySummarySchema: AiJsonSchema = {
  type: 'object',
  properties: {
    summary: { type: 'string' },
    keyPoints: { type: 'array', items: { type: 'string' } },
    glossary: {
      type: 'array',
      items: {
        type: 'object',
        properties: { term: { type: 'string' }, meaning: { type: 'string' } },
        required: ['term', 'meaning'],
      },
    },
  },
  required: ['summary', 'keyPoints'],
};

const flashcardsSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    cards: {
      type: 'array',
      items: {
        type: 'object',
        properties: { front: { type: 'string' }, back: { type: 'string' } },
        required: ['front', 'back'],
      },
    },
  },
  required: ['cards'],
};

const rewriteSchema: AiJsonSchema = {
  type: 'object',
  properties: {
    outputText: { type: 'string' },
    changes: { type: 'array', items: { type: 'string' } },
  },
  required: ['outputText'],
};

export function registerAiRoutes(app: Express): void {
  app.get('/api/health', (_req, res) => {
    res.json(getAiHealthStatus());
  });

  app.get('/api/ai/models', requireAuth, async (req: AuthRequest, res: Response) => {
    try {
      const health = getAiHealthStatus();
      const forceRefresh = req.query.refresh === '1';
      let groqModels = GROQ_KNOWN_MODELS.map((id) => ({
        id,
        ownedBy: id.split('/')[0],
        capabilities: getGroqModelCapabilities(id),
      }));
      let groqLiveListed = false;

      if (health.groqConfigured) {
        try {
          const live = await listGroqModels(forceRefresh);
          if (live.length > 0) {
            groqModels = live.map((m) => ({
              id: m.id,
              ownedBy: m.ownedBy || m.id.split('/')[0],
              capabilities: m.capabilities,
            }));
            groqLiveListed = true;
          }
        } catch {
          // Return known capability catalog if transient listing fails
        }
      }

      res.json({
        activeProvider: health.provider,
        activeModel: health.model,
        groqLiveListed,
        providers: {
          openai: {
            configured: health.openaiConfigured,
            models: ['gpt-6.2-sol', 'gpt-6.2-astra'],
          },
          gemini: {
            configured: health.geminiConfigured,
            models: ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'],
          },
          groq: {
            configured: health.groqConfigured,
            models: groqModels,
          },
        },
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.get('/api/ai/usage', requireAuth, (_req: AuthRequest, res: Response) => {
    res.json(aiUsageTracker.getSummary());
  });

  app.get('/api/ai/provider', requireAuth, (_req: AuthRequest, res: Response) => {
    const health = getAiHealthStatus();
    res.json({
      ...health,
      providers: {
        groq: { configured: health.groqConfigured, model: getEffectiveModel('groq') },
        openai: { configured: health.openaiConfigured, model: getEffectiveModel('openai') },
        gemini: { configured: health.geminiConfigured, model: getEffectiveModel('gemini') },
      },
    });
  });

  app.post('/api/ai/provider', requireAuth, requireAdmin, rateLimitMiddleware, (req: AuthRequest, res: Response) => {
    try {
      const { provider, model, fallbackProvider } = req.body ?? {};
      const parsedProvider = parseProviderEnv(typeof provider === 'string' ? provider : undefined);
      if (!parsedProvider) {
        res.status(400).json({ error: 'Provider must be one of: groq, openai, gemini.' });
        return;
      }

      let parsedFallback: AiProviderName | null | undefined = undefined;
      if (fallbackProvider === null || fallbackProvider === '') {
        parsedFallback = null;
      } else if (typeof fallbackProvider === 'string') {
        const fp = parseProviderEnv(fallbackProvider);
        if (!fp) {
          res.status(400).json({ error: 'Fallback provider must be empty or one of: groq, openai, gemini.' });
          return;
        }
        parsedFallback = fp;
      }

      const updated = setRuntimeProviderConfig({
        provider: parsedProvider,
        model: typeof model === 'string' && model.trim() ? model.trim() : undefined,
        fallbackProvider: parsedFallback,
      });

      res.json({
        ...updated,
        providers: {
          groq: { configured: updated.groqConfigured, model: getEffectiveModel('groq') },
          openai: { configured: updated.openaiConfigured, model: getEffectiveModel('openai') },
          gemini: { configured: updated.geminiConfigured, model: getEffectiveModel('gemini') },
        },
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 1. Core AI Assistant                                             */
  /* ---------------------------------------------------------------- */
  app.post('/api/assistant/chat/stream', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { message, history, language, explanationMode, rememberContext, attachments } = req.body ?? {};
      if (typeof message !== 'string' || !message.trim() || message.length > 15000) {
        res.status(400).json({ error: 'Message must be a non-empty string up to 15,000 characters.' });
        return;
      }

      const lang = safeLang(language);
      const mode = explanationMode === 'advanced' ? 'advanced' : 'simple';
      const systemInstruction = `You are AI University Assistant, a rigorous academic mentor for university students, master's/PhD candidates, and researchers.
Respond strictly in ${LANGUAGE_LABELS[lang]}.
Explanation depth: ${
        mode === 'advanced'
          ? 'Advanced academic & technical rigor with formal terminology, derivations, and methodological nuance.'
          : 'Clear, step-by-step accessible explanations suitable for building deep intuition.'
      }
Never fabricate facts, statistics, DOIs, authors, or page numbers.`;

      const parts: AiInputPart[] = [];
      if (rememberContext && Array.isArray(history) && history.length > 0) {
        const recent = history
          .slice(-8)
          .filter(
            (h: unknown): h is { role: string; text: string } =>
              typeof h === 'object' && h !== null && typeof (h as { text?: unknown }).text === 'string'
          )
          .map((h) => `${h.role === 'assistant' ? 'Assistant' : 'Student'}: ${h.text.slice(0, 2000)}`)
          .join('\n\n');
        if (recent) {
          parts.push({ text: `Conversation context (student permitted memory):\n${recent}` });
        }
      }
      if (Array.isArray(attachments)) {
        for (const att of attachments.slice(0, 3)) {
          if (att && typeof att === 'object') {
            if (typeof att.extractedText === 'string' && att.extractedText.trim()) {
              parts.push({
                text: `Uploaded file "${String(att.fileName || 'document').slice(0, 120)}":\n${att.extractedText.slice(0, 40000)}`,
              });
            } else if (typeof att.base64Data === 'string' && typeof att.mimeType === 'string') {
              parts.push({
                inlineData: {
                  mimeType: att.mimeType,
                  data: att.base64Data,
                  fileName: typeof att.fileName === 'string' ? att.fileName : undefined,
                },
              });
            }
          }
        }
      }
      parts.push({ text: `Student request:\n${message.trim()}` });

      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');

      const response = await executeAiStreamRequest(
        {
          taskType: 'chat',
          systemInstruction,
          parts,
          reasoningEffort: 'low',
        },
        (delta) => {
          res.write(`data: ${JSON.stringify({ delta })}\n\n`);
        }
      );

      res.write(
        `data: ${JSON.stringify({
          done: true,
          reply: response.text,
          usageStats: response.usageStats,
        })}\n\n`
      );
      res.end();
    } catch (err) {
      if (res.headersSent) {
        const normalized =
          err instanceof AiProviderError ? err : normalizeProviderError(err, resolvePrimaryProviderName());
        res.write(
          `data: ${JSON.stringify({
            error: normalized.message,
            code: normalized.code,
            provider: normalized.provider,
          })}\n\n`
        );
        res.end();
        return;
      }
      handleRouteError(err, res);
    }
  });
  app.post('/api/assistant/chat', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { message, history, language, explanationMode, rememberContext, attachments } = req.body ?? {};
      if (typeof message !== 'string' || !message.trim() || message.length > 15000) {
        res.status(400).json({ error: 'Message must be a non-empty string up to 15,000 characters.' });
        return;
      }

      const lang = safeLang(language);
      const mode = explanationMode === 'advanced' ? 'advanced' : 'simple';

      const systemInstruction = `You are AI University Assistant, a rigorous academic mentor for university students, master's/PhD candidates, and researchers in Uzbekistan, Central Asia, and globally.
Respond strictly in ${LANGUAGE_LABELS[lang]}.
Explanation depth: ${
        mode === 'advanced'
          ? 'Advanced academic & technical rigor with formal terminology, derivations, and methodological nuance.'
          : 'Clear, step-by-step accessible explanations suitable for building deep intuition.'
      }
HONESTY & ANTI-HALLUCINATION RULES:
- Never fabricate facts, statistics, DOIs, authors, journal names, or page numbers.
- If uncertain or if verification is required, explicitly state your uncertainty.
- When uploaded document text or image/PDF attachments are provided, strictly distinguish what comes directly from the uploaded material versus general academic knowledge.
- Also determine whether another specialized workspace module fits the request (one of: "documents", "presentations", "solver", "analyzer", "exams", "translator", "research", "planner", "tools", or "none").
Return valid JSON matching the schema.`;

      const parts: AiInputPart[] = [];

      if (rememberContext && Array.isArray(history) && history.length > 0) {
        const recent = history
          .slice(-8)
          .filter(
            (h: unknown): h is { role: string; text: string } =>
              typeof h === 'object' && h !== null && typeof (h as { text?: unknown }).text === 'string'
          )
          .map((h) => `${h.role === 'assistant' ? 'Assistant' : 'Student'}: ${h.text.slice(0, 2000)}`)
          .join('\n\n');
        if (recent) {
          parts.push({ text: `Conversation context (student permitted memory):\n${recent}` });
        }
      }

      if (Array.isArray(attachments)) {
        for (const att of attachments.slice(0, 3)) {
          if (att && typeof att === 'object') {
            if (typeof att.extractedText === 'string' && att.extractedText.trim()) {
              parts.push({
                text: `Uploaded file "${String(att.fileName || 'document').slice(0, 120)}":\n${att.extractedText.slice(0, 40000)}`,
              });
            } else if (typeof att.base64Data === 'string' && typeof att.mimeType === 'string') {
              parts.push({
                inlineData: {
                  mimeType: att.mimeType,
                  data: att.base64Data,
                  fileName: typeof att.fileName === 'string' ? att.fileName : undefined,
                },
              });
            }
          }
        }
      }

      parts.push({ text: `Student request:\n${message.trim()}` });

      const { data: parsed, response } = await executeStructuredAiRequest<{
        reply?: string;
        recommendedTool?: string;
      }>({
        taskType: 'chat',
        systemInstruction,
        parts,
        reasoningEffort: 'low',
        jsonSchema: { name: 'assistant_chat_response', schema: chatResponseSchema },
      });

      res.json({
        reply: parsed.reply || response.text || '',
        recommendedTool:
          parsed.recommendedTool && parsed.recommendedTool !== 'none' ? parsed.recommendedTool : undefined,
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 2. Academic Document Generator (17 types, Search-grounded refs)  */
  /* ---------------------------------------------------------------- */
  app.post('/api/documents/generate', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { docType, topic, subject, academicLevel, language, targetPages, standard, additionalInfo } =
        req.body ?? {};
      if (typeof topic !== 'string' || topic.trim().length < 3 || topic.length > 300) {
        res.status(400).json({ error: 'Topic must be between 3 and 300 characters.' });
        return;
      }

      const lang = safeLang(language);
      const pages = Math.max(3, Math.min(80, Math.round(Number(targetPages) || 15)));
      const chapterCount = pages <= 8 ? 2 : pages <= 25 ? 3 : 4;

      // Step 1: Web-search grounded verifiable references (gracefully continues if search unavailable)
      let groundingSources: AiSourceReference[] = [];
      let groundedSummary = '';
      let searchUsage: AiUsageStats | undefined;
      let webSearchAvailable = false;

      try {
        const searchResp = await executeAiRequest({
          taskType: 'document',
          prompt: `Find real, authoritative academic sources, textbooks, peer-reviewed papers, or official institutional publications about: "${topic.trim()}" (subject: ${String(subject || 'General').slice(0, 120)}). List exact titles, authors/organizations if visible, and years without inventing anything.`,
          useWebSearch: true,
          reasoningEffort: 'low',
          timeoutMs: 60_000,
        });
        groundingSources = searchResp.sources;
        groundedSummary = (searchResp.text || '').slice(0, 4000);
        searchUsage = searchResp.usageStats;
        webSearchAvailable = searchResp.webSearchAvailable;
      } catch (err) {
        if (
          err instanceof AiProviderError &&
          (err.code === 'MISSING_API_KEY' || err.code === 'INVALID_API_KEY' || err.code === 'INSUFFICIENT_QUOTA')
        ) {
          throw err;
        }
        groundingSources = [];
      }

      // Step 2: Structured full academic document
      const systemInstruction = `You are a senior university professor and academic writing specialist.
Write strictly in ${LANGUAGE_LABELS[lang]}.
Document type: ${String(docType || 'kurs_ishi')}.
Academic level: ${String(academicLevel || 'undergraduate')}.
Citation standard: ${String(standard || 'uz_dst').toUpperCase()}.
CRITICAL ACADEMIC INTEGRITY RULES:
- Create logically connected chapters (${chapterCount} chapters, 2 sections each) with substantial analytical paragraphs, concrete examples, introduction, and conclusion.
- Include clear relevance, research objectives, tasks, theoretical foundations, practical analysis, and conclusion in the introduction/chapters/conclusion.
- For references: use ONLY verifiable sources from the retrieved search results below or standard foundational works you are certain exist. NEVER invent DOI numbers, fake page numbers, fake years, fake legal acts, or nonexistent authors. Include a clear complianceNote stating that formatting should be checked against the student's specific university/department handbook.`;

      const prompt = `Topic: "${topic.trim()}"
Subject: "${String(subject || '').slice(0, 150)}"
Target length: ~${pages} pages
Additional requirements: "${String(additionalInfo || '').slice(0, 1000)}"
Web search status: ${webSearchAvailable ? 'Online search active' : 'Online search unavailable — mark unverified references clearly for student checking.'}
Retrieved web/scholarly context:\n${groundedSummary || 'No external search snippets retrieved; clearly mark references that require student verification.'}
Retrieved URLs:\n${groundingSources.map((s) => `- ${s.title}: ${s.uri}`).join('\n') || 'None'}

Generate the complete structured academic document as JSON matching the schema.`;

      const { data: parsed, response: docResp } = await executeStructuredAiRequest<{
        introduction?: string[];
        chapters?: Array<{
          title: string;
          sections: Array<{ title: string; paragraphs: string[]; examples?: string }>;
        }>;
        conclusion?: string[];
        references?: Array<{ citation: string; url?: string; verified: boolean }>;
        complianceNote?: string;
      }>({
        taskType: 'document',
        systemInstruction,
        prompt,
        reasoningEffort: 'medium',
        timeoutMs: 150_000,
        jsonSchema: { name: 'academic_document', schema: documentSchema },
      });

      const chapters = (parsed.chapters || []).map((ch, ci) => ({
        id: `ch_${ci + 1}`,
        title: ch.title,
        sections: (ch.sections || []).map((sec, si) => ({
          id: `sec_${ci + 1}_${si + 1}`,
          title: sec.title,
          paragraphs: sec.paragraphs || [],
          examples: sec.examples || '',
        })),
      }));

      const refs = (parsed.references || []).map((r) => ({
        citation: r.citation,
        url: r.url || undefined,
        verified: Boolean(r.verified && r.url && groundingSources.some((g) => g.uri === r.url)),
      }));
      for (const src of groundingSources.slice(0, 4)) {
        if (!refs.some((r) => r.url === src.uri)) {
          refs.push({ citation: src.title, url: src.uri, verified: true });
        }
      }

      res.json({
        document: {
          introduction: parsed.introduction || [],
          chapters,
          conclusion: parsed.conclusion || [],
          references: refs,
          complianceNote: parsed.complianceNote || '',
        },
        usageStats: combineUsageStats(docResp.usageStats, searchUsage),
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.post('/api/documents/regenerate-section', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, docType, sectionTitle, instruction, language, existingParagraphs } = req.body ?? {};
      if (typeof topic !== 'string' || typeof sectionTitle !== 'string') {
        res.status(400).json({ error: 'Topic and section title are required.' });
        return;
      }
      const lang = safeLang(language);

      const { data: parsed, response } = await executeStructuredAiRequest<{
        paragraphs?: string[];
        examples?: string;
      }>({
        taskType: 'document',
        systemInstruction: `Rewrite and strengthen this academic section in ${LANGUAGE_LABELS[lang]}. Never invent fake citations or statistics.`,
        prompt: `Document topic: "${topic.slice(0, 300)}" (${String(docType || 'academic')}).
Section title: "${sectionTitle.slice(0, 200)}".
Existing text:\n${Array.isArray(existingParagraphs) ? existingParagraphs.join('\n\n').slice(0, 4000) : ''}
User instruction: "${String(instruction || 'Expand with deeper academic analysis and a concrete example').slice(0, 500)}".
Write in ${LANGUAGE_LABELS[lang]}.`,
        reasoningEffort: 'low',
        jsonSchema: { name: 'regenerate_section', schema: regenerateSectionSchema },
      });

      res.json({
        paragraphs: parsed.paragraphs || [],
        examples: parsed.examples || '',
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 3. Presentation Generator (7 Styles, Charts, Tables, Notes)      */
  /* ---------------------------------------------------------------- */
  app.post('/api/presentation/plan', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, slideCount, planCount, language, style, additionalInfo } = req.body ?? {};
      if (typeof topic !== 'string' || topic.trim().length < 2 || topic.length > 300) {
        res.status(400).json({ error: 'Topic must be between 2 and 300 characters.' });
        return;
      }
      const parsedSlides = Math.max(3, Math.min(25, Math.round(Number(slideCount) || 8)));
      const parsedPlans = Math.max(2, Math.min(8, Math.round(Number(planCount) || 4)));
      const lang = safeLang(language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';
      const safeInfo = `${style ? `Design style: ${String(style)}. ` : ''}${
        typeof additionalInfo === 'string' ? additionalInfo.trim().slice(0, 900) : ''
      }
Output language must strictly be: ${LANGUAGE_LABELS[lang]}. Include at least one 'chart' visual (with numericValue for bar/chart rendering) and one 'table' visual (with tableHeaders and tableRows) where appropriate for data/comparison.`;

      const { data: parsed, response } = await executeStructuredAiRequest<{
        themeId?: string;
        slides?: Slide[];
      }>({
        taskType: 'presentation',
        systemInstruction: SYSTEM_INSTRUCTION_PLAN(baseLang) + `\nWrite ALL slide text in ${LANGUAGE_LABELS[lang]}.`,
        prompt: createPlanPrompt(topic.trim(), parsedSlides, parsedPlans, baseLang, safeInfo),
        reasoningEffort: 'low',
        jsonSchema: { name: 'presentation_plan', schema: presentationPlanSchema },
      });

      res.json({
        themeId: parsed.themeId || 'academic_navy',
        slides: Array.isArray(parsed.slides) ? parsed.slides : [],
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.post('/api/presentation/refine-slide', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, slide, instruction, language } = req.body ?? {};
      if (typeof topic !== 'string' || !slide || typeof instruction !== 'string') {
        res.status(400).json({ error: 'Topic, slide, and instruction are required.' });
        return;
      }
      const lang = safeLang(language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';

      const { data: refined, response } = await executeStructuredAiRequest<Slide>({
        taskType: 'presentation',
        systemInstruction: SYSTEM_INSTRUCTION_PLAN(baseLang) + `\nOutput strictly in ${LANGUAGE_LABELS[lang]}.`,
        prompt: createRefineSlidePrompt(topic.slice(0, 300), slide as Slide, instruction.slice(0, 400), baseLang),
        reasoningEffort: 'low',
        jsonSchema: { name: 'refined_slide', schema: slideSchema },
      });

      res.json({
        slide: refined,
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* Legacy coursework endpoints preserved cleanly */
  app.post('/api/coursework/outline', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, pages, chapterCount, language, additionalInfo } = req.body ?? {};
      const lang = safeLang(language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';

      const { data: outline, response } = await executeStructuredAiRequest({
        taskType: 'coursework',
        systemInstruction: SYSTEM_INSTRUCTION_COURSE(baseLang) + `\nWrite in ${LANGUAGE_LABELS[lang]}.`,
        prompt: createCourseOutlinePrompt(
          String(topic || ''),
          Number(pages) || 20,
          Number(chapterCount) || 2,
          2,
          baseLang,
          additionalInfo
        ),
        reasoningEffort: 'low',
        jsonSchema: { name: 'course_outline', schema: courseOutlineSchema },
      });

      res.json({ outline, usageStats: response.usageStats });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.post('/api/coursework/part', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const body = req.body ?? {};
      const lang = safeLang(body.language);
      const baseLang: 'uz' | 'en' | 'ru' = lang === 'uz' || lang === 'ru' || lang === 'en' ? lang : 'uz';
      const kind = body.kind === 'intro' || body.kind === 'references' || body.kind === 'conclusion' ? body.kind : 'section';

      const partSchema =
        kind === 'intro'
          ? { name: 'course_intro_part', schema: courseIntroPartSchema }
          : kind === 'references'
            ? { name: 'course_references_part', schema: courseReferencesPartSchema }
            : { name: 'course_paragraphs_part', schema: courseParagraphsPartSchema };

      const { data: parsed, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'coursework',
        systemInstruction: SYSTEM_INSTRUCTION_COURSE(baseLang) + `\nWrite in ${LANGUAGE_LABELS[lang]}.`,
        prompt: createCoursePartPrompt({ ...body, language: baseLang }),
        reasoningEffort: 'low',
        jsonSchema: partSchema,
      });

      res.json({
        ...parsed,
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 4. Mathematics & Economics Solver (OCR + Dual Verification)      */
  /* ---------------------------------------------------------------- */
  app.post('/api/solver/solve', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { subject, problemText, imageBase64, imageMimeType, language } = req.body ?? {};
      if ((!problemText || !String(problemText).trim()) && !imageBase64) {
        res.status(400).json({ error: 'Provide a problem statement or upload an image of a formula/problem.' });
        return;
      }

      const lang = safeLang(language);
      const parts: AiInputPart[] = [];
      if (typeof imageBase64 === 'string' && typeof imageMimeType === 'string') {
        parts.push({ inlineData: { mimeType: imageMimeType, data: imageBase64 } });
      }
      parts.push({
        text: `Subject: ${String(subject || 'mathematics')}.
Language for all explanations: ${LANGUAGE_LABELS[lang]}.
Problem input: ${String(
          problemText || 'Read and extract the mathematical/economic problem from the attached image carefully.'
        ).slice(0, 8000)}

INSTRUCTIONS:
1. Extract the exact mathematical or economic expression cleanly.
2. Solve step by step, explaining every calculation clearly.
3. Provide valid LaTeX strings for formulaLatex and finalAnswerLatex (without surrounding $ signs).
4. Perform an INDEPENDENT verification pass (e.g., substituting solutions back, checking units/equilibrium conditions, checking derivatives/integrals or accounting balances). List any detected errors in the input or ambiguities.
5. NEVER present an unverified calculation as verified! If ambiguous or missing data prevents certainty, set verified=false and explain in uncertaintyNote.
6. When applicable (functions, supply/demand, cashflows, distributions), provide graphPoints and/or tableData.`,
      });

      const { data: solution, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'reasoning',
        systemInstruction: `You are a rigorous mathematics, statistics, finance, econometrics, accounting, and economics problem solver. Explain in ${LANGUAGE_LABELS[lang]}. Perform independent mathematical verification before finalizing.`,
        parts,
        reasoningEffort: 'high',
        timeoutMs: 150_000,
        jsonSchema: { name: 'math_solution', schema: solverSchema },
      });

      res.json({
        solution: { subject: String(subject || 'mathematics'), ...solution },
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 5. AI Document Analyzer (PDF/DOCX/XLSX/PPTX/JPG/PNG + OCR)       */
  /* ---------------------------------------------------------------- */
  app.post('/api/analyzer/analyze', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { fileName, mimeType, extractedText, base64Data, language } = req.body ?? {};
      if (!extractedText && !base64Data) {
        res.status(400).json({ error: 'Uploaded file content is required.' });
        return;
      }
      const lang = safeLang(language);

      const parts: AiInputPart[] = [];
      if (typeof base64Data === 'string' && typeof mimeType === 'string') {
        parts.push({
          inlineData: {
            mimeType,
            data: base64Data,
            fileName: typeof fileName === 'string' ? fileName : undefined,
          },
        });
      }
      if (typeof extractedText === 'string' && extractedText.trim()) {
        parts.push({
          text: `Document text from "${String(fileName || 'file')}":\n${extractedText.slice(0, 60000)}`,
        });
      }
      parts.push({
        text: `Analyze this uploaded document thoroughly in ${LANGUAGE_LABELS[lang]}.
If it is a scanned PDF or image, perform accurate OCR first and provide an extractedTextPreview.
Produce:
1. detected structure (heading + summary)
2. executiveSummary
3. keyFindings
4. studyNotes (concise revision notes derived strictly from the document)
5. extractedQA (questions and answers found or directly supported by the document, citing sourceLocation)
6. quizPreview (5 MCQs grounded strictly in the uploaded document)
7. sourceBoundaryNotice explaining what was directly found in the file vs any general context.`,
      });

      const { data: parsed, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'analysis',
        systemInstruction: `You are an academic document analyzer. Always distinguish facts directly extracted from the uploaded file from external background knowledge. Respond in ${LANGUAGE_LABELS[lang]}.`,
        parts,
        reasoningEffort: 'medium',
        timeoutMs: 150_000,
        jsonSchema: { name: 'analyzed_document', schema: analyzerSchema },
      });

      res.json({
        analysis: {
          fileName: String(fileName || 'document'),
          fileType: String(mimeType || 'unknown'),
          ...parsed,
        },
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.post('/api/analyzer/ask', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { question, documentContext, base64Data, mimeType, language } = req.body ?? {};
      if (typeof question !== 'string' || !question.trim()) {
        res.status(400).json({ error: 'Question is required.' });
        return;
      }
      const lang = safeLang(language);
      const parts: AiInputPart[] = [];
      if (typeof base64Data === 'string' && typeof mimeType === 'string') {
        parts.push({ inlineData: { mimeType, data: base64Data } });
      }
      if (typeof documentContext === 'string' && documentContext.trim()) {
        parts.push({ text: `Uploaded document content:\n${documentContext.slice(0, 50000)}` });
      }
      parts.push({
        text: `Answer this question in ${LANGUAGE_LABELS[lang]}: "${question.trim()}". Explicitly separate [From Uploaded Document] and [External Academic Context]. If not answered in the document, say so clearly.`,
      });

      const response = await executeAiRequest({
        taskType: 'analysis',
        parts,
        reasoningEffort: 'low',
      });

      res.json({
        answer: response.text || '',
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 6. Test & Exam System                                            */
  /* ---------------------------------------------------------------- */
  app.post('/api/exam/generate', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, subject, sourceText, questionCount, language, difficulty } = req.body ?? {};
      if ((!topic || !String(topic).trim()) && (!sourceText || !String(sourceText).trim())) {
        res.status(400).json({ error: 'Provide a topic or upload study material.' });
        return;
      }
      const lang = safeLang(language);
      const count = Math.max(4, Math.min(20, Math.round(Number(questionCount) || 8)));

      const { data: parsed, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'exam',
        systemInstruction: `You are a university examiner. Write clearly in ${LANGUAGE_LABELS[lang]}. Every question must include a clear explanation.`,
        prompt: `Create an exam preparation bundle in ${LANGUAGE_LABELS[lang]}.
Topic: "${String(topic || 'Uploaded Material').slice(0, 200)}"
Subject: "${String(subject || 'General').slice(0, 120)}"
Difficulty: "${String(difficulty || 'university')}"
Question count: ${count} (include a balanced mix of "mcq", "true_false", and "open" questions)
Also create 8 flashcards and a 5-day exam preparation plan.
${sourceText ? `Base questions strictly on this uploaded material:\n${String(sourceText).slice(0, 40000)}` : ''}`,
        reasoningEffort: 'low',
        jsonSchema: { name: 'exam_bundle', schema: examSchema },
      });

      res.json({
        exam: {
          topic: String(topic || 'Study Material'),
          subject: String(subject || ''),
          ...parsed,
        },
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 7. Translation & Writing Tools                                   */
  /* ---------------------------------------------------------------- */
  app.post('/api/translate/process', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { text, sourceLang, targetLang, action, style } = req.body ?? {};
      if (typeof text !== 'string' || !text.trim() || text.length > 30000) {
        res.status(400).json({ error: 'Text must be between 1 and 30,000 characters.' });
        return;
      }
      const src = sourceLang === 'auto' ? 'Auto-detect' : LANGUAGE_LABELS[safeLang(sourceLang)];
      const tgt = LANGUAGE_LABELS[safeLang(targetLang)];

      const { data: parsed, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'translation',
        systemInstruction:
          'You are an expert academic translator and editor fluent in Uzbek, Russian, English, Karakalpak, and Kazakh. Return JSON with outputText, notes (key edits or terminology notes), and detectedSource.',
        prompt: `Action: ${String(action || 'translate')}
Source language: ${src}
Target language: ${tgt}
Tone / Style: ${String(style || 'academic')}
Input text:\n${text}

Preserve original meaning, domain terminology, and paragraph structure.`,
        reasoningEffort: 'low',
        jsonSchema: { name: 'translation_result', schema: translateSchema },
      });

      const outputText =
        typeof parsed?.outputText === 'string' && parsed.outputText.trim()
          ? parsed.outputText
          : response.text.trim();
      if (!outputText) {
        throw new AiProviderError({
          code: 'INVALID_STRUCTURED_OUTPUT',
          status: 502,
          provider: response.provider,
          message: 'Translation response was empty. Please try again.',
          retryable: false,
        });
      }

      res.json({
        outputText,
        notes: Array.isArray(parsed?.notes) ? parsed.notes.filter((n): n is string => typeof n === 'string') : [],
        ...(typeof parsed?.detectedSource === 'string' ? { detectedSource: parsed.detectedSource } : {}),
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 8. AI Research Assistant (Search-Grounded + Real Citations)      */
  /* ---------------------------------------------------------------- */
  app.post('/api/research/explore', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { topic, discipline, language, claimsToAudit } = req.body ?? {};
      if (typeof topic !== 'string' || topic.trim().length < 3 || topic.length > 400) {
        res.status(400).json({ error: 'Research topic must be between 3 and 400 characters.' });
        return;
      }
      const lang = safeLang(language);

      // Step 1: Web search grounding for real academic sources
      let groundingSources: AiSourceReference[] = [];
      let groundedText = '';
      let searchUsage: AiUsageStats | undefined;
      let webSearchAvailable = false;

      try {
        const searchResp = await executeAiRequest({
          taskType: 'research',
          prompt: `Search for real peer-reviewed studies, institutional reports, and academic papers on: "${topic.trim()}" (discipline: ${String(discipline || 'General').slice(0, 100)}). Summarize key real studies found, their methodologies, and limitations.`,
          useWebSearch: true,
          reasoningEffort: 'medium',
          timeoutMs: 90_000,
        });
        groundingSources = searchResp.sources;
        groundedText = (searchResp.text || '').slice(0, 6000);
        searchUsage = searchResp.usageStats;
        webSearchAvailable = searchResp.webSearchAvailable;
      } catch (err) {
        if (
          err instanceof AiProviderError &&
          (err.code === 'MISSING_API_KEY' || err.code === 'INVALID_API_KEY' || err.code === 'INSUFFICIENT_QUOTA')
        ) {
          throw err;
        }
        webSearchAvailable = false;
      }

      // Step 2: Structured synthesis strictly separating verified search sources vs suggested research directions
      const searchNotice = webSearchAvailable
        ? `Retrieved verified URLs:\n${
            groundingSources.map((g, i) => `${i + 1}. ${g.title} — ${g.uri}`).join('\n') || 'None'
          }`
        : 'LIVE WEB SEARCH WAS UNAVAILABLE FOR THIS REQUEST. Set verifiedSources to an empty array [] and clearly explain in integrityNotice that online source verification was unavailable so sources were NOT verified online.';

      const { data: parsed, response: structResp } = await executeStructuredAiRequest<{
        researchQuestions: string[];
        hypotheses: string[];
        literatureSynthesis: string;
        studyComparisons: Array<{
          studyTitle: string;
          methodology: string;
          keyFindings: string;
          limitations: string;
        }>;
        unsupportedClaimsAudit: string[];
        verifiedSources: Array<{
          title: string;
          url: string;
          snippet?: string;
          citations: { apa: string; mla: string; chicago: string; ieee: string };
        }>;
        suggestedDirections: string[];
        integrityNotice: string;
      }>({
        taskType: 'research',
        systemInstruction: `You are a rigorous academic research methodologist. Write in ${LANGUAGE_LABELS[lang]}. NEVER invent publications, DOIs, URLs, or authors. Distinguish verified facts from assumptions.`,
        prompt: `Topic: "${topic.trim()}"
Language: ${LANGUAGE_LABELS[lang]}
Grounded search findings:\n${groundedText || 'No live web search results were returned.'}
${searchNotice}
${claimsToAudit ? `Claims to audit for support:\n${String(claimsToAudit).slice(0, 3000)}` : ''}

Produce JSON matching schema. For verifiedSources, use ONLY sources from the retrieved verified URLs above (never fabricate DOIs, URLs, authors, or citations). Format APA, MLA, Chicago, and IEEE citations accurately from the retrieved title/URL/date (mark unknown authors/years cleanly rather than guessing). Put AI-proposed next avenues in suggestedDirections.`,
        reasoningEffort: 'medium',
        timeoutMs: 120_000,
        jsonSchema: { name: 'research_bundle', schema: researchSchema },
      });

      // Enforce URL integrity: only keep verifiedSources that appeared in actual retrieved sources when search ran
      const allowedUrls = new Set(groundingSources.map((s) => s.uri));
      const safeVerifiedSources = webSearchAvailable
        ? (parsed.verifiedSources || []).filter((s) => s.url && (allowedUrls.size === 0 || allowedUrls.has(s.url)))
        : [];

      const integrityNotice = !webSearchAvailable
        ? `${parsed.integrityNotice ? `${parsed.integrityNotice} ` : ''}(Live web search was unavailable for this request; no sources were verified online.)`
        : parsed.integrityNotice;

      res.json({
        research: {
          topic: topic.trim(),
          ...parsed,
          verifiedSources: safeVerifiedSources,
          integrityNotice,
        },
        usageStats: combineUsageStats(structResp.usageStats, searchUsage),
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* 9. Career, Resume & Admissions Assistant                         */
  /* ---------------------------------------------------------------- */
  app.post('/api/career/assist', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { mode, promptText, targetRoleOrProgram, language } = req.body ?? {};
      if (typeof promptText !== 'string' || !promptText.trim()) {
        res.status(400).json({ error: 'Input details are required.' });
        return;
      }
      const lang = safeLang(language);

      const response = await executeAiRequest({
        taskType: 'career',
        systemInstruction: `You are a university career advisor and international admissions mentor. Respond in ${LANGUAGE_LABELS[lang]}. Provide actionable, honest feedback without fabricating credentials.`,
        prompt: `Career/Admissions mode: ${String(mode || 'resume')}
Target role / university program: ${String(targetRoleOrProgram || 'Not specified').slice(0, 200)}
Language: ${LANGUAGE_LABELS[lang]}
Student background / draft:\n${promptText.slice(0, 10000)}`,
        reasoningEffort: 'low',
      });

      res.json({
        output: response.text || '',
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  /* ---------------------------------------------------------------- */
  /* Diagnostics: verify the configured AI key really works (admin)   */
  /* ---------------------------------------------------------------- */
  app.get('/api/ai/test', requireAuth, requireAdmin, async (req: AuthRequest, res: Response) => {
    const requested = typeof req.query.provider === 'string' ? req.query.provider : undefined;
    const name = requested === 'gemini' || requested === 'openai' || requested === 'groq' ? requested : undefined;
    const result = await pingProvider(name);
    res.status(result.ok ? 200 : 502).json({ ...result, gemini: describeGeminiAuth() });
  });

  /* ---------------------------------------------------------------- */
  /* Study Boost: summarizer, flashcards, rewriter                     */
  /* ---------------------------------------------------------------- */
  app.post('/api/study/summarize', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { text, style, language } = req.body ?? {};
      if (typeof text !== 'string' || !text.trim() || text.length > 40000) {
        res.status(400).json({ error: 'Text must be between 1 and 40,000 characters.' });
        return;
      }
      const lang = safeLang(language);
      const mode = ['short', 'detailed', 'simple'].includes(String(style)) ? String(style) : 'short';
      const { data, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'analysis',
        systemInstruction: `You are an expert study assistant. Respond in ${LANGUAGE_LABELS[lang]}. Never invent facts that are not in the text. Return JSON with summary, keyPoints and glossary.`,
        prompt: `Summary style: ${mode} (short = 3-5 sentences, detailed = structured multi-paragraph, simple = explain like to a first-year student).\nText:\n${text}`,
        reasoningEffort: 'low',
        jsonSchema: { name: 'study_summary', schema: studySummarySchema },
      });
      res.json({
        summary: typeof data.summary === 'string' ? data.summary : '',
        keyPoints: Array.isArray(data.keyPoints) ? data.keyPoints.filter((k): k is string => typeof k === 'string') : [],
        glossary: Array.isArray(data.glossary) ? data.glossary : [],
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.post('/api/study/flashcards', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { text, count, language } = req.body ?? {};
      if (typeof text !== 'string' || !text.trim() || text.length > 40000) {
        res.status(400).json({ error: 'Text must be between 1 and 40,000 characters.' });
        return;
      }
      const lang = safeLang(language);
      const n = Math.min(30, Math.max(3, Number(count) || 10));
      const { data, response } = await executeStructuredAiRequest<{ cards?: Array<{ front?: unknown; back?: unknown }> }>({
        taskType: 'exam',
        systemInstruction: `You create concise study flashcards in ${LANGUAGE_LABELS[lang]}. Each card tests ONE fact or concept. Return JSON {cards:[{front,back}]}.`,
        prompt: `Create exactly ${n} flashcards from this material:\n${text}`,
        reasoningEffort: 'low',
        jsonSchema: { name: 'flashcards', schema: flashcardsSchema },
      });
      const cards = (Array.isArray(data.cards) ? data.cards : [])
        .filter((c) => typeof c?.front === 'string' && typeof c?.back === 'string')
        .slice(0, n);
      res.json({ cards, usageStats: response.usageStats });
    } catch (err) {
      handleRouteError(err, res);
    }
  });

  app.post('/api/study/rewrite', requireAuth, rateLimitMiddleware, async (req: AuthRequest, res: Response) => {
    try {
      const { text, mode, language } = req.body ?? {};
      if (typeof text !== 'string' || !text.trim() || text.length > 20000) {
        res.status(400).json({ error: 'Text must be between 1 and 20,000 characters.' });
        return;
      }
      const lang = safeLang(language);
      const allowed = ['paraphrase', 'grammar', 'academic', 'shorten', 'expand'];
      const action = allowed.includes(String(mode)) ? String(mode) : 'paraphrase';
      const { data, response } = await executeStructuredAiRequest<Record<string, unknown>>({
        taskType: 'translation',
        systemInstruction: `You are an academic writing editor. Write in ${LANGUAGE_LABELS[lang]}. Preserve meaning and facts. Return JSON {outputText, changes[]}.`,
        prompt: `Action: ${action} (paraphrase = reword to reduce similarity, grammar = fix errors only, academic = formal scholarly tone, shorten = ~50% shorter, expand = add detail without new facts).\nText:\n${text}`,
        reasoningEffort: 'low',
        jsonSchema: { name: 'rewrite_result', schema: rewriteSchema },
      });
      const outputText = typeof data.outputText === 'string' && data.outputText.trim() ? data.outputText : response.text.trim();
      res.json({
        outputText,
        changes: Array.isArray(data.changes) ? data.changes.filter((c): c is string => typeof c === 'string') : [],
        usageStats: response.usageStats,
      });
    } catch (err) {
      handleRouteError(err, res);
    }
  });
}
