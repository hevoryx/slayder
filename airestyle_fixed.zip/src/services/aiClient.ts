import { auth } from '../lib/firebase';
import { incrementUserAiUsage, recordSystemLog } from '../lib/firestoreService';

interface CachedHealth {
  provider: string;
  model: string;
  fetchedAt: number;
}

let cachedHealth: CachedHealth | null = null;

export function invalidateAiHealthCache(): void {
  cachedHealth = null;
}

async function getActiveServerMeta(): Promise<{ provider: string; model: string }> {
  const now = Date.now();
  if (cachedHealth && now - cachedHealth.fetchedAt < 60_000) {
    return { provider: cachedHealth.provider, model: cachedHealth.model };
  }
  try {
    const res = await fetch('/api/health');
    if (res.ok) {
      const data = (await res.json()) as { provider?: string; model?: string };
      if (data.provider && data.model) {
        cachedHealth = { provider: data.provider, model: data.model, fetchedAt: now };
        return { provider: data.provider, model: data.model };
      }
    }
  } catch {
    // ignore health lookup error during logging
  }
  return { provider: 'groq', model: 'unknown' };
}

function formatProviderModel(provider?: string, model?: string): string {
  const cleanModel = model?.trim() || 'unknown';
  if (!provider) return cleanModel.slice(0, 80);
  const normProvider = provider.toLowerCase();
  if (cleanModel.startsWith(`${normProvider}/`) && !(normProvider === 'openai' && cleanModel.includes('gpt-oss'))) {
    return cleanModel.slice(0, 80);
  }
  return `${normProvider}/${cleanModel}`.slice(0, 80);
}

export async function callAiApi<T>(
  endpoint: string,
  body: Record<string, unknown>,
  toolName: string
): Promise<T> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Please sign in with Google to use AI features.');
  }

  const token = await user.getIdToken();
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
  });

  const text = await response.text();
  let parsed: unknown = null;
  try {
    parsed = text ? JSON.parse(text) : null;
  } catch {
    parsed = null;
  }

  if (!response.ok) {
    const errObj =
      typeof parsed === 'object' && parsed !== null ? (parsed as { error?: unknown; provider?: unknown }) : null;
    const errMessage =
      errObj && typeof errObj.error === 'string'
        ? errObj.error
        : `Request failed (HTTP ${response.status})`;
    const activeMeta = await getActiveServerMeta();
    const errProvider =
      errObj && typeof errObj.provider === 'string' ? errObj.provider : activeMeta.provider;

    void recordSystemLog({
      userId: user.uid,
      userEmail: user.email || undefined,
      tool: toolName,
      model: formatProviderModel(errProvider, activeMeta.model),
      status: 'error',
      tokens: 0,
      errorMessage: errMessage,
    });
    throw new Error(errMessage);
  }

  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    const activeMeta = await getActiveServerMeta();
    const errMessage = text.trim()
      ? 'Server returned an unexpected non-JSON response. Please try again.'
      : 'Server returned an empty response. Please try again.';
    void recordSystemLog({
      userId: user.uid,
      userEmail: user.email || undefined,
      tool: toolName,
      model: formatProviderModel(activeMeta.provider, activeMeta.model),
      status: 'error',
      tokens: 0,
      errorMessage: errMessage,
    });
    throw new Error(errMessage);
  }

  const result = parsed as T & {
    usageStats?: {
      provider?: string;
      model?: string;
      inputTokens?: number;
      outputTokens?: number;
      totalTokens?: number;
    };
  };

  const provider = result?.usageStats?.provider;
  const model = result?.usageStats?.model;
  const tokens = result?.usageStats?.totalTokens || 0;

  let loggedModel: string;
  if (model) {
    loggedModel = formatProviderModel(provider, model);
  } else {
    const activeMeta = await getActiveServerMeta();
    loggedModel = formatProviderModel(provider || activeMeta.provider, activeMeta.model);
  }

  // Record usage asynchronously without blocking user response
  void incrementUserAiUsage(user.uid).catch(() => {});
  void recordSystemLog({
    userId: user.uid,
    userEmail: user.email || undefined,
    tool: toolName,
    model: loggedModel,
    status: 'ok',
    tokens,
  });

  return result;
}
