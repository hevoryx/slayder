import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Calculator,
  CheckCircle2,
  ImagePlus,
  Save,
  ShieldCheck,
} from 'lucide-react';
import type { MathSolution, SolverSubject, WorkspaceItem } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { MathFormula } from './MathText';
import { saveWorkspaceItem } from '../lib/firestoreService';

const SUBJECTS: SolverSubject[] = [
  'mathematics',
  'statistics',
  'microeconomics',
  'macroeconomics',
  'econometrics',
  'accounting',
  'finance',
  'business_math',
  'probability',
  'linear_algebra',
  'calculus',
];

interface MathEconomicsSolverViewProps {
  loadedWorkspaceItem?: WorkspaceItem | null;
}

export const MathEconomicsSolverView: React.FC<MathEconomicsSolverViewProps> = ({
  loadedWorkspaceItem,
}) => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [subject, setSubject] = useState<SolverSubject>('calculus');
  const [problemText, setProblemText] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string | null>(null);
  const [solution, setSolution] = useState<MathSolution | null>(null);
  const [loading, setLoading] = useState(false);
  const [saveDone, setSaveDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (loadedWorkspaceItem && loadedWorkspaceItem.type === 'math') {
      const saved = loadedWorkspaceItem.content as unknown as MathSolution;
      if (saved && saved.finalAnswer) {
        setSolution(saved);
        if (saved.subject) setSubject(saved.subject);
      }
    }
  }, [loadedWorkspaceItem]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImagePreview(reader.result);
        const [, base64] = reader.result.split(',');
        setImageBase64(base64 || null);
        setImageMimeType(file.type || 'image/png');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSolve = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!problemText.trim() && !imageBase64) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    setLoading(true);
    setError(null);
    setSaveDone(false);

    try {
      const resp = await callAiApi<{ solution: MathSolution }>(
        '/api/solver/solve',
        {
          subject,
          problemText: problemText.trim(),
          imageBase64,
          imageMimeType,
          language,
        },
        'solver'
      );
      if (!resp?.solution || typeof resp.solution !== 'object') {
        throw new Error('Solver returned an empty response. Please try again.');
      }
      setSolution(resp.solution);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to solve problem.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!solution || !firebaseUser) return;
    await saveWorkspaceItem({
      userId: firebaseUser.uid,
      title: solution.extractedExpression.slice(0, 120) || t.solverSubjects[subject],
      type: 'math',
      docSubtype: subject,
      folder: 'Math & Economics',
      language,
      summary: solution.finalAnswer.slice(0, 240),
      content: solution as unknown as Record<string, unknown>,
    });
    setSaveDone(true);
  };

  const renderSvgGraph = (graph: NonNullable<MathSolution['graphPoints']>) => {
    const pts = graph.points;
    if (!pts || pts.length < 2) return null;
    const w = 520;
    const h = 220;
    const pad = 34;
    const xs = pts.map((p) => p.x);
    const ys = pts.map((p) => p.y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs) === minX ? minX + 1 : Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys) === minY ? minY + 1 : Math.max(...ys);

    const sx = (x: number) => pad + ((x - minX) / (maxX - minX)) * (w - pad * 2);
    const sy = (y: number) => h - pad - ((y - minY) / (maxY - minY)) * (h - pad * 2);
    const pathD = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${sx(p.x).toFixed(1)} ${sy(p.y).toFixed(1)}`).join(' ');

    return (
      <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl">
        <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
          {graph.seriesName} ({graph.xLabel} vs {graph.yLabel})
        </p>
        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto max-h-60">
          <line x1={pad} y1={h - pad} x2={w - pad} y2={h - pad} stroke="currentColor" strokeOpacity="0.25" />
          <line x1={pad} y1={pad} x2={pad} y2={h - pad} stroke="currentColor" strokeOpacity="0.25" />
          <path d={pathD} fill="none" stroke="#2563eb" strokeWidth="2.5" />
          {pts.map((p, i) => (
            <circle key={i} cx={sx(p.x)} cy={sy(p.y)} r="3.5" fill="#2563eb" />
          ))}
        </svg>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <form
        onSubmit={handleSolve}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
      >
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            {t.nav.solver}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Formula OCR from images · Step-by-step derivations · Independent verification & error audit · KaTeX & graphs
          </p>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {SUBJECTS.map((sub) => (
            <button
              key={sub}
              type="button"
              onClick={() => setSubject(sub)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer whitespace-nowrap ${
                subject === sub
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
              }`}
            >
              {t.solverSubjects[sub]}
            </button>
          ))}
        </div>

        <textarea
          rows={4}
          value={problemText}
          onChange={(e) => setProblemText(e.target.value)}
          placeholder="Enter equation, optimization problem, NPV/IRR cashflows, regression data, or supply/demand functions..."
          className="w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono text-slate-900 dark:text-slate-100"
        />

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <label className="inline-flex items-center gap-2 px-3.5 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
              <ImagePlus className="w-4 h-4" />
              Upload Formula / Problem Photo
              <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            </label>
            {imagePreview && (
              <div className="flex items-center gap-2">
                <img src={imagePreview} alt="Uploaded problem" className="h-10 w-10 object-cover rounded border" />
                <button
                  type="button"
                  onClick={() => {
                    setImagePreview(null);
                    setImageBase64(null);
                    setImageMimeType(null);
                  }}
                  className="text-xs text-red-600 hover:underline cursor-pointer"
                >
                  {t.common.clear}
                </button>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer inline-flex items-center gap-2 whitespace-nowrap"
          >
            <Calculator className="w-4 h-4" />
            {loading ? t.common.generating : 'Solve & Verify'}
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </form>

      {solution && (
        <div className="space-y-4">
          {/* Verification & Final Answer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Final Answer (Verified)
                </span>
                <button
                  type="button"
                  onClick={() => void handleSave()}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                >
                  {saveDone ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Save className="w-3.5 h-3.5" />}
                  {saveDone ? t.common.saved : t.common.save}
                </button>
              </div>
              <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                Expression: {solution.extractedExpression}
              </p>
              <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg">
                <MathFormula latex={solution.finalAnswerLatex} displayMode />
                <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 mt-2">
                  {solution.finalAnswer}
                </p>
              </div>
            </div>

            <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
              <div className="flex items-center gap-2">
                {solution.independentVerification.verified ? (
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                )}
                <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
                  {solution.independentVerification.verified
                    ? 'Independent Verification Passed'
                    : 'Verification Warning — Review Needed'}
                </h3>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                <strong>Method:</strong> {solution.independentVerification.method}
              </p>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                {solution.independentVerification.auditNote}
              </p>
              {solution.independentVerification.detectedErrors.length > 0 && (
                <ul className="text-xs text-amber-700 dark:text-amber-300 list-disc pl-4 space-y-1">
                  {solution.independentVerification.detectedErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              )}
              {solution.uncertaintyNote && (
                <p className="text-xs text-amber-700 dark:text-amber-300">{solution.uncertaintyNote}</p>
              )}
            </div>
          </div>

          {/* Step-by-step derivation */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
              Step-by-Step Derivation
            </h3>
            <div className="space-y-3">
              {solution.steps.map((step) => (
                <div
                  key={step.stepNumber}
                  className="p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-lg space-y-2"
                >
                  <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    {step.stepNumber}. {step.title}
                  </p>
                  <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                    {step.explanation}
                  </p>
                  {step.formulaLatex && (
                    <div className="p-2.5 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-700">
                      <MathFormula latex={step.formulaLatex} displayMode />
                    </div>
                  )}
                  <p className="text-xs font-mono text-slate-600 dark:text-slate-400">
                    Result: {step.intermediateResult}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Optional Table & Graph */}
          {(solution.tableData || solution.graphPoints) && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {solution.tableData && solution.tableData.headers.length > 0 && (
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 overflow-x-auto">
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-3">
                    Computed Data Table
                  </h4>
                  <table className="w-full text-xs font-mono tabular-nums">
                    <thead>
                      <tr>
                        {solution.tableData.headers.map((h, i) => (
                          <th key={i} className="text-left py-2 pr-3 border-b border-slate-200 dark:border-slate-700">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {solution.tableData.rows.map((row, ri) => (
                        <tr key={ri}>
                          {row.map((cell, ci) => (
                            <td key={ci} className="py-2 pr-3 border-b border-slate-100 dark:border-slate-800">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {solution.graphPoints && renderSvgGraph(solution.graphPoints)}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
