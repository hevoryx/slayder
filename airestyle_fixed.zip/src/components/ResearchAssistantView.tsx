import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  Save,
  ShieldAlert,
} from 'lucide-react';
import type { ResearchBundle, WorkspaceItem } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { saveWorkspaceItem } from '../lib/firestoreService';

interface ResearchAssistantViewProps {
  loadedWorkspaceItem?: WorkspaceItem | null;
}

export const ResearchAssistantView: React.FC<ResearchAssistantViewProps> = ({
  loadedWorkspaceItem,
}) => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [topic, setTopic] = useState('');
  const [discipline, setDiscipline] = useState('');
  const [claimsToAudit, setClaimsToAudit] = useState('');
  const [citationStyle, setCitationStyle] = useState<'apa' | 'mla' | 'chicago' | 'ieee'>('apa');
  const [research, setResearch] = useState<ResearchBundle | null>(null);
  const [loading, setLoading] = useState(false);
  const [saveDone, setSaveDone] = useState(false);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (loadedWorkspaceItem && loadedWorkspaceItem.type === 'research') {
      const saved = loadedWorkspaceItem.content as unknown as ResearchBundle;
      if (saved && saved.topic) {
        setResearch(saved);
        setTopic(saved.topic);
      }
    }
  }, [loadedWorkspaceItem]);

  const handleExplore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setLoading(true);
    setError(null);
    setSaveDone(false);

    try {
      const resp = await callAiApi<{ research: ResearchBundle }>(
        '/api/research/explore',
        {
          topic: topic.trim(),
          discipline: discipline.trim(),
          claimsToAudit: claimsToAudit.trim(),
          language,
        },
        'research'
      );
      if (!resp?.research || typeof resp.research !== 'object') {
        throw new Error('Research service returned an empty response. Please try again.');
      }
      setResearch(resp.research);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Research lookup failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!research || !firebaseUser) return;
    await saveWorkspaceItem({
      userId: firebaseUser.uid,
      title: `Research: ${research.topic}`,
      type: 'research',
      folder: 'Research',
      language,
      summary: research.literatureSynthesis.slice(0, 260),
      content: research as unknown as Record<string, unknown>,
    });
    setSaveDone(true);
  };

  const copyCitation = async (text: string, idx: number) => {
    await navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 1500);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <form
        onSubmit={handleExplore}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
      >
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            {t.nav.research}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Search-grounded real sources · APA / MLA / Chicago / IEEE citations · Research questions, hypotheses & claim audit
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            required
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Research topic or thesis problem..."
            className="md:col-span-2 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
          />
          <input
            type="text"
            value={discipline}
            onChange={(e) => setDiscipline(e.target.value)}
            placeholder="Discipline (e.g., Economics, Computer Science)"
            className="px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
          />
        </div>

        <textarea
          rows={2}
          value={claimsToAudit}
          onChange={(e) => setClaimsToAudit(e.target.value)}
          placeholder="Optional: paste draft claims or hypotheses to audit for unsupported statements..."
          className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
        />

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer inline-flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            {loading ? t.common.generating : 'Search & Synthesize'}
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </form>

      {research && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <h3 className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                {research.topic}
              </h3>
              <button
                type="button"
                onClick={() => void handleSave()}
                className="px-3.5 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                {saveDone ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Save className="w-4 h-4" />}
                {saveDone ? t.common.saved : t.common.save}
              </button>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-600 dark:text-slate-400">
              {research.integrityNotice}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">
                  Research Questions
                </h4>
                <ul className="list-disc pl-4 space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  {research.researchQuestions.map((q, i) => (
                    <li key={i}>{q}</li>
                  ))}
                </ul>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">
                  Testable Hypotheses
                </h4>
                <ul className="list-disc pl-4 space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  {research.hypotheses.map((h, i) => (
                    <li key={i}>{h}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">
                Literature Review Synthesis
              </h4>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                {research.literatureSynthesis}
              </p>
            </div>

            {research.studyComparisons.length > 0 && (
              <div className="overflow-x-auto">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">
                  Comparative Study Matrix
                </h4>
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-700 text-left">
                      <th className="py-2 pr-3">Study / Source</th>
                      <th className="py-2 pr-3">Methodology</th>
                      <th className="py-2 pr-3">Key Findings</th>
                      <th className="py-2">Limitations</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {research.studyComparisons.map((row, idx) => (
                      <tr key={idx}>
                        <td className="py-2.5 pr-3 font-medium">{row.studyTitle}</td>
                        <td className="py-2.5 pr-3 text-slate-600 dark:text-slate-400">{row.methodology}</td>
                        <td className="py-2.5 pr-3 text-slate-600 dark:text-slate-400">{row.keyFindings}</td>
                        <td className="py-2.5 text-slate-600 dark:text-slate-400">{row.limitations}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {research.unsupportedClaimsAudit.length > 0 && (
              <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl space-y-1.5">
                <h4 className="text-xs font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  Unsupported Claims & Verification Audit
                </h4>
                <ul className="list-disc pl-4 text-xs text-amber-800 dark:text-amber-300 space-y-1">
                  {research.unsupportedClaimsAudit.map((c, i) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Verified Sources vs Suggested Directions */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                  Verified Search-Retrieved Sources & Citations
                </h4>
                <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  {(['apa', 'mla', 'chicago', 'ieee'] as const).map((fmt) => (
                    <button
                      key={fmt}
                      type="button"
                      onClick={() => setCitationStyle(fmt)}
                      className={`px-2.5 py-1 text-xs font-medium rounded-md uppercase cursor-pointer ${
                        citationStyle === fmt
                          ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {fmt}
                    </button>
                  ))}
                </div>
              </div>

              {research.verifiedSources.length === 0 ? (
                <p className="text-xs text-slate-500">No external search links returned for this query.</p>
              ) : (
                <div className="space-y-2.5">
                  {research.verifiedSources.map((src, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-lg space-y-1.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <a
                          href={src.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                        >
                          {src.title}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                        <button
                          type="button"
                          onClick={() => void copyCitation(src.citations[citationStyle], idx)}
                          className="text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 inline-flex items-center gap-1 cursor-pointer"
                        >
                          {copiedIdx === idx ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          {citationStyle.toUpperCase()}
                        </button>
                      </div>
                      <p className="text-xs font-mono text-slate-700 dark:text-slate-300">
                        {src.citations[citationStyle]}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 mb-2">
                Suggested Next Research Directions (AI-Proposed — Not Citations)
              </h4>
              <ul className="list-disc pl-4 space-y-1 text-xs text-slate-600 dark:text-slate-400">
                {research.suggestedDirections.map((d, i) => (
                  <li key={i}>{d}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
