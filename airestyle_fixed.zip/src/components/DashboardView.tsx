import React from 'react';
import {
  ArrowRight,
  BookOpen,
  Calculator,
  Calendar,
  FileSearch,
  FileText,
  FolderOpen,
  GraduationCap,
  Languages,
  Megaphone,
  Presentation,
  Sparkles,
  Wrench,
} from 'lucide-react';
import type {
  AcademicTask,
  ModuleId,
  StudyProgress,
  WorkspaceItem,
} from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';

interface DashboardViewProps {
  onNavigate: (module: ModuleId) => void;
  workspaces: WorkspaceItem[];
  tasks: AcademicTask[];
  studyProgress: StudyProgress[];
  onOpenWorkspaceItem: (item: WorkspaceItem) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  workspaces,
  tasks,
  studyProgress,
  onOpenWorkspaceItem,
}) => {
  const { firebaseUser, profile, platformConfig, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const activeTasks = tasks.filter((item) => item.status !== 'completed');
  const upcomingExams = activeTasks.filter((item) => item.kind === 'exam');
  const avgScore =
    studyProgress.length > 0
      ? Math.round(studyProgress.reduce((acc, s) => acc + s.percentage, 0) / studyProgress.length)
      : 0;

  const quickModules: { id: ModuleId; icon: React.FC<{ className?: string }>; desc: string }[] = [
    { id: 'assistant', icon: Sparkles, desc: 'Step-by-step tutoring & document Q&A' },
    { id: 'documents', icon: FileText, desc: '17 academic templates with DOCX & PDF' },
    { id: 'presentations', icon: Presentation, desc: 'Outlines, charts, tables & PPTX export' },
    { id: 'solver', icon: Calculator, desc: 'OCR formulas, verification & graphs' },
    { id: 'analyzer', icon: FileSearch, desc: 'PDF, DOCX, XLSX, PPTX & image analysis' },
    { id: 'exams', icon: GraduationCap, desc: 'Practice tests, flashcards & prep plans' },
    { id: 'translator', icon: Languages, desc: 'UZ / RU / EN / KAA / KK academic polish' },
    { id: 'research', icon: BookOpen, desc: 'Search-grounded sources & citations' },
    { id: 'tools', icon: Wrench, desc: 'GPA, PDF tools, CV builder & calculators' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {platformConfig.announcementActive && platformConfig.announcement && (
        <div className="bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 rounded-xl px-4 py-3 flex items-start gap-3">
          <Megaphone className="w-4 h-4 text-sky-700 dark:text-sky-400 mt-0.5 shrink-0" />
          <p className="text-sm text-sky-900 dark:text-sky-100">{platformConfig.announcement}</p>
        </div>
      )}

      {/* Hero Welcome Banner */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden items-stretch">
        <div className="lg:col-span-7 p-6 md:p-8 flex flex-col justify-between gap-6">
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              {profile?.university || 'Uzbekistan & Central Asia'} ·{' '}
              {profile?.academicLevel ? profile.academicLevel.toUpperCase() : 'UNIVERSITY PLATFORM'}
            </p>
            <h1 className="font-display text-2xl md:text-3xl font-bold text-slate-900 dark:text-slate-100 tracking-tight leading-tight text-balance">
              {firebaseUser && profile
                ? `${profile.displayName} — ${t.dashboard.welcomeTitle}`
                : t.dashboard.welcomeTitle}
            </h1>
            <p className="mt-3 text-sm md:text-base text-slate-600 dark:text-slate-400 max-w-2xl leading-relaxed">
              {t.dashboard.welcomeSubtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {firebaseUser ? (
              <>
                <button
                  type="button"
                  onClick={() => onNavigate('assistant')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity cursor-pointer whitespace-nowrap shrink-0"
                >
                  {t.nav.assistant}
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('documents')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {t.nav.documents}
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => void signInWithGoogle()}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {t.auth.signInGoogle}
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        <div className="lg:col-span-5 min-h-[220px] relative bg-slate-100 dark:bg-slate-800">
          <img
            src="/src/assets/images/academic_library_hero_1795370099796.jpg"
            alt="Modern university library reading room"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent flex items-end p-5">
            <p className="text-xs text-white/90 font-medium">
              UZ · RU · EN · KAA · KK
            </p>
          </div>
        </div>
      </section>

      {/* 4-column KPI Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">{t.dashboard.recentProjects}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
            {workspaces.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">{t.dashboard.activeAssignments}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
            {activeTasks.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">{t.dashboard.studyProgress}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
            {avgScore}%
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">{t.dashboard.aiUsage}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
            {profile ? `${profile.aiRequestsUsed} / ${profile.aiMonthlyLimit}` : '0 / 100'}
          </p>
        </div>
      </section>

      {/* Quick Access Grid */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            {t.dashboard.quickAccess}
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickModules.map((mod) => {
            const Icon = mod.icon;
            const disabled = platformConfig.disabledTools.includes(mod.id);
            return (
              <button
                key={mod.id}
                type="button"
                disabled={disabled}
                onClick={() => onNavigate(mod.id)}
                className="text-left bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 hover:border-blue-500 dark:hover:border-blue-500 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="flex items-center justify-between gap-3 mb-2">
                  <span className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {t.nav[mod.id]}
                  </span>
                  <Icon className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {disabled ? 'Temporarily paused by administrator' : mod.desc}
                </p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Recent Projects & Deadlines */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {t.dashboard.recentProjects}
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('workspace')}
              className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer whitespace-nowrap"
            >
              {t.nav.workspace}
            </button>
          </div>
          {workspaces.length === 0 ? (
            <div className="py-8 text-center">
              <FolderOpen className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-sm text-slate-500 dark:text-slate-400">{t.dashboard.noProjects}</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {workspaces.slice(0, 5).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onOpenWorkspaceItem(item)}
                  className="w-full py-3 flex items-center justify-between gap-4 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 px-2 rounded-lg transition-colors cursor-pointer"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                      {item.title}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {item.type} · {item.folder} · v{item.versionCount}
                    </p>
                  </div>
                  <span className="text-xs font-mono text-slate-500 dark:text-slate-400 shrink-0">
                    {item.language.toUpperCase()}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {t.dashboard.upcomingDeadlines} & {t.dashboard.examSchedule}
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('planner')}
              className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline cursor-pointer whitespace-nowrap"
            >
              {t.nav.planner}
            </button>
          </div>
          {activeTasks.length === 0 ? (
            <div className="py-8 text-center">
              <Calendar className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-sm text-slate-500 dark:text-slate-400">{t.dashboard.noTasks}</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeTasks.slice(0, 5).map((task) => (
                <div key={task.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                      {task.title}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {task.subject || task.kind} · {task.priority}
                    </p>
                  </div>
                  <span className="text-xs font-mono text-slate-700 dark:text-slate-300 tabular-nums shrink-0">
                    {task.dueDate}
                  </span>
                </div>
              ))}
              {upcomingExams.length > 0 && (
                <div className="pt-3 text-xs text-slate-500 dark:text-slate-400">
                  Upcoming exams scheduled: <span className="font-mono font-semibold">{upcomingExams.length}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
