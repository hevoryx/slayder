import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  GraduationCap,
  Layers,
  Shuffle,
  XCircle,
} from 'lucide-react';
import type { ExamBundle, ExamMode, StudyProgress } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { parseUploadedFile } from '../utils/fileParsers';
import { recordStudyProgress } from '../lib/firestoreService';

interface ExamSystemViewProps {
  studyProgress: StudyProgress[];
}

export const ExamSystemView: React.FC<ExamSystemViewProps> = ({ studyProgress }) => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [topic, setTopic] = useState('');
  const [subject, setSubject] = useState('');
  const [questionCount, setQuestionCount] = useState(8);
  const [timeLimitMinutes, setTimeLimitMinutes] = useState(10);
  const [mode, setMode] = useState<ExamMode>('learning');
  const [sourceText, setSourceText] = useState('');
  const [randomize, setRandomize] = useState(true);

  const [bundle, setBundle] = useState<ExamBundle | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [activeTab, setActiveTab] = useState<'quiz' | 'flashcards' | 'plan'>('quiz');
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!bundle || submitted || mode !== 'practice' || secondsLeft <= 0) return;
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [bundle, submitted, mode, secondsLeft]);

  const handleMaterialUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const parsed = await parseUploadedFile(file);
      if (parsed.extractedText) {
        setSourceText(parsed.extractedText);
        if (!topic) setTopic(file.name.replace(/\.[^/.]+$/, ''));
      } else {
        setError('For exam generation from files, upload DOCX, XLSX, PPTX, or TXT.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'File load failed.');
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() && !sourceText.trim()) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    setLoading(true);
    setError(null);
    setSubmitted(false);
    setAnswers({});

    try {
      const resp = await callAiApi<{ exam: ExamBundle }>(
        '/api/exam/generate',
        {
          topic: topic.trim(),
          subject: subject.trim(),
          sourceText: sourceText.trim(),
          questionCount,
          language,
        },
        'exams'
      );

      if (!resp?.exam || !Array.isArray(resp.exam.questions)) {
        throw new Error('Exam generator returned an invalid response. Please try again.');
      }
      let qs = [...resp.exam.questions];
      if (randomize) {
        qs = qs.sort(() => Math.random() - 0.5);
      }
      setBundle({
        ...resp.exam,
        questions: qs,
        flashcards: Array.isArray(resp.exam.flashcards) ? resp.exam.flashcards : [],
        prepPlan: Array.isArray(resp.exam.prepPlan) ? resp.exam.prepPlan : [],
      });
      setSecondsLeft(timeLimitMinutes * 60);
      setActiveTab('quiz');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not generate exam.');
    } finally {
      setLoading(false);
    }
  };

  const evaluateScore = () => {
    if (!bundle) return { score: 0, total: 0, pct: 0, weak: [] as string[] };
    let correct = 0;
    const weakSet = new Set<string>();
    bundle.questions.forEach((q) => {
      const userAns = (answers[q.id] || '').trim().toLowerCase();
      const target = q.correctAnswer.trim().toLowerCase();
      const ok =
        q.type === 'open'
          ? userAns.length > 8 && (userAns.includes(target.slice(0, 12)) || target.split(' ').some((w) => w.length > 4 && userAns.includes(w)))
          : userAns === target;
      if (ok) {
        correct += 1;
      } else {
        weakSet.add(q.topicTag);
      }
    });
    const total = bundle.questions.length || 1;
    return {
      score: correct,
      total,
      pct: Math.round((correct / total) * 100),
      weak: Array.from(weakSet),
    };
  };

  const handleSubmitExam = async () => {
    if (!bundle) return;
    setSubmitted(true);
    if (firebaseUser) {
      const res = evaluateScore();
      await recordStudyProgress(firebaseUser.uid, {
        topic: bundle.topic,
        subject: bundle.subject,
        mode,
        score: res.score,
        totalQuestions: res.total,
        percentage: res.pct,
        weakAreas: res.weak,
      });
    }
  };

  const scoreInfo = evaluateScore();
  const mm = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
  const ss = String(secondsLeft % 60).padStart(2, '0');

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <form
        onSubmit={handleGenerate}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
              {t.nav.exams}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              MCQ, True/False & Open-ended tests · Timed Practice Mode & Instant Learning Mode · Flashcards & Prep Plans
            </p>
          </div>
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
            {(['learning', 'practice'] as ExamMode[]).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer whitespace-nowrap ${
                  mode === m
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {m === 'learning' ? 'Learning Mode' : 'Timed Practice Mode'}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Exam topic (e.g., Makroiqtisodiyot: IS-LM modeli)"
            className="md:col-span-5 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
          />
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Subject"
            className="md:col-span-3 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
          />
          <input
            type="number"
            min={4}
            max={20}
            value={questionCount}
            onChange={(e) => setQuestionCount(Number(e.target.value))}
            className="md:col-span-2 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono"
            title="Questions"
          />
          <input
            type="number"
            min={2}
            max={90}
            value={timeLimitMinutes}
            onChange={(e) => setTimeLimitMinutes(Number(e.target.value))}
            className="md:col-span-2 px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono"
            title="Minutes"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
              Upload Lecture / Material (DOCX/XLSX/PPTX/TXT)
              <input
                type="file"
                accept=".docx,.xlsx,.xls,.pptx,.txt,.md"
                onChange={handleMaterialUpload}
                className="hidden"
              />
            </label>
            <label className="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={randomize}
                onChange={(e) => setRandomize(e.target.checked)}
              />
              <Shuffle className="w-3.5 h-3.5" />
              Randomize
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer inline-flex items-center gap-2"
          >
            <GraduationCap className="w-4 h-4" />
            {loading ? t.common.generating : 'Generate Exam & Flashcards'}
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
            {error}
          </div>
        )}
      </form>

      {bundle && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              {(
                [
                  ['quiz', `Questions (${bundle.questions.length})`],
                  ['flashcards', `Flashcards (${bundle.flashcards.length})`],
                  ['plan', 'Prep Plan'],
                ] as const
              ).map(([tab, label]) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setActiveTab(tab)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                    activeTab === tab
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {mode === 'practice' && !submitted && (
              <div className="inline-flex items-center gap-1.5 text-sm font-mono font-semibold text-slate-800 dark:text-slate-200">
                <Clock className="w-4 h-4 text-amber-600" />
                {mm}:{ss}
              </div>
            )}
          </div>

          {activeTab === 'quiz' && (
            <div className="space-y-4">
              {submitted && (
                <div className="p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      Score: <span className="font-mono">{scoreInfo.score} / {scoreInfo.total} ({scoreInfo.pct}%)</span>
                    </p>
                    {scoreInfo.weak.length > 0 && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Review areas: {scoreInfo.weak.join(', ')}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {bundle.questions.map((q, idx) => {
                const chosen = answers[q.id] || '';
                const showFeedback = submitted || (mode === 'learning' && Boolean(chosen));
                const isCorrect =
                  chosen.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();

                return (
                  <div
                    key={q.id}
                    className="p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {idx + 1}. {q.question}
                      </p>
                      <span className="text-xs font-mono text-slate-500 shrink-0">{q.type}</span>
                    </div>

                    {q.type === 'open' ? (
                      <textarea
                        rows={2}
                        disabled={submitted}
                        value={chosen}
                        onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })}
                        placeholder="Write your answer..."
                        className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-sm"
                      />
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {(q.options && q.options.length > 0 ? q.options : ['True', 'False']).map((opt) => (
                          <button
                            key={opt}
                            type="button"
                            disabled={submitted}
                            onClick={() => setAnswers({ ...answers, [q.id]: opt })}
                            className={`text-left px-3 py-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                              chosen === opt
                                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900'
                                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    )}

                    {showFeedback && (
                      <div className="pt-2 border-t border-slate-200 dark:border-slate-700 text-xs space-y-1">
                        <p className="font-semibold flex items-center gap-1.5">
                          {q.type !== 'open' &&
                            (isCorrect ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <XCircle className="w-4 h-4 text-red-600" />
                            ))}
                          Expected Answer: {q.correctAnswer}
                        </p>
                        <p className="text-slate-600 dark:text-slate-400">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                );
              })}

              {!submitted && (
                <button
                  type="button"
                  onClick={() => void handleSubmitExam()}
                  className="px-5 py-2.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-sm font-semibold cursor-pointer"
                >
                  Submit & Save Score
                </button>
              )}
            </div>
          )}

          {activeTab === 'flashcards' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {bundle.flashcards.map((card) => {
                const flipped = Boolean(flippedCards[card.id]);
                return (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() =>
                      setFlippedCards((prev) => ({ ...prev, [card.id]: !prev[card.id] }))
                    }
                    className="text-left p-5 min-h-[150px] bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl flex flex-col justify-between cursor-pointer hover:border-blue-500 transition-colors"
                  >
                    <span className="text-[11px] font-mono text-slate-500">
                      {flipped ? 'Answer' : 'Prompt'} · Click to flip
                    </span>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 my-2">
                      {flipped ? card.back : card.front}
                    </p>
                    <Layers className="w-3.5 h-3.5 text-slate-400 self-end" />
                  </button>
                );
              })}
            </div>
          )}

          {activeTab === 'plan' && (
            <div className="space-y-3">
              {bundle.prepPlan.map((step, i) => (
                <div key={i} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                  <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {step.day}: {step.focus}
                  </p>
                  <ul className="mt-1.5 list-disc pl-5 text-xs text-slate-600 dark:text-slate-400 space-y-1">
                    {step.tasks.map((tsk, ti) => (
                      <li key={ti}>{tsk}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Study Progress History */}
      {studyProgress.length > 0 && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
          <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 mb-3">
            Recorded Study Progress
          </h3>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {studyProgress.slice(0, 8).map((p) => (
              <div key={p.id} className="py-2.5 flex items-center justify-between gap-4">
                <div>
                  <span className="font-semibold text-slate-900 dark:text-slate-100">{p.topic}</span>
                  <span className="text-slate-500 ml-2">({p.mode})</span>
                </div>
                <span className="font-mono font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
                  {p.score}/{p.totalQuestions} · {p.percentage}%
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
