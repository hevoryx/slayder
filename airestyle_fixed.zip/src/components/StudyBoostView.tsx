import React, { useState } from 'react';
import { Check, Copy, Layers, PenLine, ScrollText } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { callAiApi } from '../services/aiClient';

type Tab = 'summarize' | 'flashcards' | 'rewrite';

interface SummaryResult {
  summary: string;
  keyPoints: string[];
  glossary: { term: string; meaning: string }[];
}
interface Card {
  front: string;
  back: string;
}
interface RewriteResult {
  outputText: string;
  changes: string[];
}

const TABS: { id: Tab; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'summarize', label: 'Konspekt / Summary', icon: ScrollText },
  { id: 'flashcards', label: 'Flashcards', icon: Layers },
  { id: 'rewrite', label: 'Rewrite / Paraphrase', icon: PenLine },
];

const btn =
  'px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 disabled:opacity-50 cursor-pointer';
const box =
  'w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-sm text-slate-900 dark:text-slate-100';

export const StudyBoostView: React.FC = () => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const [tab, setTab] = useState<Tab>('summarize');
  const [text, setText] = useState('');
  const [style, setStyle] = useState('short');
  const [count, setCount] = useState(10);
  const [mode, setMode] = useState('paraphrase');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<SummaryResult | null>(null);
  const [cards, setCards] = useState<Card[]>([]);
  const [flipped, setFlipped] = useState<Record<number, boolean>>({});
  const [rewrite, setRewrite] = useState<RewriteResult | null>(null);
  const [copied, setCopied] = useState(false);

  const run = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setError(null);
    try {
      if (tab === 'summarize') {
        setSummary(await callAiApi<SummaryResult>('/api/study/summarize', { text, style, language }, 'study_summarize'));
      } else if (tab === 'flashcards') {
        const r = await callAiApi<{ cards: Card[] }>('/api/study/flashcards', { text, count, language }, 'study_flashcards');
        setCards(r.cards);
        setFlipped({});
      } else {
        setRewrite(await callAiApi<RewriteResult>('/api/study/rewrite', { text, mode, language }, 'study_rewrite'));
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unexpected error');
    } finally {
      setLoading(false);
    }
  };

  const copy = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable */
    }
  };

  if (!firebaseUser) {
    return (
      <div className="p-8 text-center">
        <button type="button" onClick={() => void signInWithGoogle()} className={btn}>
          Sign in with Google
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div className="flex gap-2 flex-wrap">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm cursor-pointer ${
              tab === id
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={9}
        placeholder="Matnni shu yerga qo'ying…"
        className={box}
      />

      <div className="flex items-center gap-3 flex-wrap">
        {tab === 'summarize' && (
          <select value={style} onChange={(e) => setStyle(e.target.value)} className={box + ' !w-auto'}>
            <option value="short">Short</option>
            <option value="detailed">Detailed</option>
            <option value="simple">Simple (ELI-student)</option>
          </select>
        )}
        {tab === 'flashcards' && (
          <label className="text-sm flex items-center gap-2 text-slate-700 dark:text-slate-200">
            Cards
            <input
              type="number"
              min={3}
              max={30}
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              className={box + ' !w-20'}
            />
          </label>
        )}
        {tab === 'rewrite' && (
          <select value={mode} onChange={(e) => setMode(e.target.value)} className={box + ' !w-auto'}>
            <option value="paraphrase">Paraphrase</option>
            <option value="grammar">Fix grammar</option>
            <option value="academic">Academic tone</option>
            <option value="shorten">Shorten</option>
            <option value="expand">Expand</option>
          </select>
        )}
        <button type="button" onClick={() => void run()} disabled={loading || !text.trim()} className={btn}>
          {loading ? 'Generating…' : 'Generate'}
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-300 bg-red-50 dark:bg-red-950/40 dark:border-red-800 p-3 text-sm text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {tab === 'summarize' && summary && (
        <div className="space-y-3 rounded-lg border border-slate-200 dark:border-slate-700 p-4 text-sm text-slate-800 dark:text-slate-100">
          <p className="whitespace-pre-wrap">{summary.summary}</p>
          {summary.keyPoints.length > 0 && (
            <ul className="list-disc pl-5 space-y-1">
              {summary.keyPoints.map((k, i) => (
                <li key={i}>{k}</li>
              ))}
            </ul>
          )}
          {summary.glossary.length > 0 && (
            <dl className="grid gap-1">
              {summary.glossary.map((g, i) => (
                <div key={i}>
                  <dt className="inline font-semibold">{g.term}: </dt>
                  <dd className="inline">{g.meaning}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>
      )}

      {tab === 'flashcards' && cards.length > 0 && (
        <div className="grid sm:grid-cols-2 gap-3">
          {cards.map((c, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setFlipped((f) => ({ ...f, [i]: !f[i] }))}
              className="text-left min-h-28 rounded-lg border border-slate-200 dark:border-slate-700 p-4 text-sm bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 cursor-pointer"
            >
              <span className="block text-xs uppercase text-slate-500 mb-1">{flipped[i] ? 'Answer' : 'Question'}</span>
              {flipped[i] ? c.back : c.front}
            </button>
          ))}
        </div>
      )}

      {tab === 'rewrite' && rewrite && (
        <div className="space-y-3 rounded-lg border border-slate-200 dark:border-slate-700 p-4 text-sm text-slate-800 dark:text-slate-100">
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => void copy(rewrite.outputText)}
              className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 cursor-pointer"
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <p className="whitespace-pre-wrap">{rewrite.outputText}</p>
          {rewrite.changes.length > 0 && (
            <ul className="list-disc pl-5 text-xs text-slate-500 dark:text-slate-400 space-y-1">
              {rewrite.changes.map((c, i) => (
                <li key={i}>{c}</li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};
