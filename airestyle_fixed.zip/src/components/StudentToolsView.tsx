import React, { useMemo, useState } from 'react';
import {
  Briefcase,
  Calculator,
  Check,
  Copy,
  Download,
  FilePlus2,
  Image as ImageIcon,
  Plus,
  Save,
  Scissors,
  Trash2,
} from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import { jsPDF } from 'jspdf';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { parseUploadedFile } from '../utils/fileParsers';
import { saveWorkspaceItem } from '../lib/firestoreService';

type ToolCategory = 'calculators' | 'pdf_data' | 'career';
type CalculatorTool =
  | 'gpa'
  | 'scholarship'
  | 'attendance'
  | 'grade'
  | 'budget'
  | 'currency'
  | 'units'
  | 'citation'
  | 'bibliography'
  | 'wordcount';

type PdfDataTool = 'pdf_merge' | 'pdf_split' | 'ocr' | 'table_gen';
type CareerTool = 'resume' | 'internship' | 'job' | 'interview' | 'admissions';

const DEFAULT_FX_RATES_PER_USD: Record<string, number> = {
  USD: 1,
  UZS: 12850,
  EUR: 0.92,
  RUB: 92.5,
  KZT: 495,
};

const parsePageSelection = (expr: string, totalPages: number): number[] => {
  const indices = new Set<number>();
  const parts = expr.split(',').map((s) => s.trim()).filter(Boolean);
  for (const part of parts) {
    if (part.includes('-')) {
      const [aStr, bStr] = part.split('-');
      const a = Math.max(1, parseInt(aStr, 10));
      const b = Math.min(totalPages, parseInt(bStr, 10));
      if (!Number.isNaN(a) && !Number.isNaN(b) && a <= b) {
        for (let p = a; p <= b; p++) indices.add(p - 1);
      }
    } else {
      const p = parseInt(part, 10);
      if (!Number.isNaN(p) && p >= 1 && p <= totalPages) indices.add(p - 1);
    }
  }
  return Array.from(indices).sort((a, b) => a - b);
};

export const StudentToolsView: React.FC = () => {
  const { firebaseUser, profile, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [category, setCategory] = useState<ToolCategory>('calculators');
  const [calcTool, setCalcTool] = useState<CalculatorTool>('gpa');
  const [pdfTool, setPdfTool] = useState<PdfDataTool>('pdf_merge');
  const [careerTool, setCareerTool] = useState<CareerTool>('resume');

  // 1. GPA Calculator state
  const [gpaScale, setGpaScale] = useState<'4.0' | '5.0'>('4.0');
  const [courses, setCourses] = useState([
    { name: 'Macroeconomics', credits: 4, score: 88 },
    { name: 'Econometrics', credits: 4, score: 92 },
    { name: 'Academic Writing', credits: 3, score: 81 },
  ]);

  // 2. Scholarship calculator
  const [schGpa, setSchGpa] = useState(4.4);
  const [schScale, setSchScale] = useState<'5.0' | '4.0'>('5.0');
  const [schAttendance, setSchAttendance] = useState(96);
  const [schResearchPoints, setSchResearchPoints] = useState(12);

  // 3. Attendance calculator
  const [attTotal, setAttTotal] = useState(32);
  const [attPresent, setAttPresent] = useState(27);
  const [attRequired, setAttRequired] = useState(80);
  const [attRemaining, setAttRemaining] = useState(10);

  // 4. Weighted grade calculator
  const [gradeItems, setGradeItems] = useState([
    { name: 'Midterm Exam', weight: 30, score: 84 },
    { name: 'Quizzes & Homework', weight: 20, score: 90 },
    { name: 'Course Project', weight: 20, score: 88 },
  ]);
  const [targetFinalGrade, setTargetFinalGrade] = useState(86);

  // 5. Budget planner
  const [budgetIncome, setBudgetIncome] = useState({ stipend: 517880, family: 1500000, partTime: 1200000 });
  const [budgetExpenses, setBudgetExpenses] = useState({
    rent: 800000,
    food: 950000,
    transport: 180000,
    study: 250000,
    internet: 100000,
  });

  // 6. Currency converter
  const [fxAmount, setFxAmount] = useState(100);
  const [fxFrom, setFxFrom] = useState('USD');
  const [fxTo, setFxTo] = useState('UZS');
  const [fxRates, setFxRates] = useState<Record<string, number>>(DEFAULT_FX_RATES_PER_USD);

  // 7. Unit converter
  const [unitCat, setUnitCat] = useState<'length' | 'mass' | 'temp' | 'data' | 'speed'>('length');
  const [unitVal, setUnitVal] = useState(1);
  const [unitFrom, setUnitFrom] = useState('km');
  const [unitTo, setUnitTo] = useState('m');

  // 8 & 9. Citation & Bibliography generator
  const [citStyle, setCitStyle] = useState<'apa' | 'mla' | 'chicago' | 'ieee' | 'gost'>('apa');
  const [citAuthor, setCitAuthor] = useState('Karimov, A.');
  const [citYear, setCitYear] = useState('2024');
  const [citTitle, setCitTitle] = useState('Digital Transformation in Central Asian Higher Education');
  const [citPublisher, setCitPublisher] = useState('Tashkent University Press');
  const [citUrl, setCitUrl] = useState('');
  const [bibliography, setBibliography] = useState<string[]>([]);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // 10. Word & character counter
  const [wordText, setWordText] = useState('');

  // 11. PDF Merger
  const [mergeFiles, setMergeFiles] = useState<{ name: string; pages: number; buffer: ArrayBuffer }[]>([]);
  const [pdfStatus, setPdfStatus] = useState<string | null>(null);

  // 12. PDF Splitter
  const [splitFile, setSplitFile] = useState<{ name: string; pages: number; buffer: ArrayBuffer } | null>(null);
  const [splitRange, setSplitRange] = useState('1-2');

  // 13. Image-to-Text OCR
  const [ocrImageName, setOcrImageName] = useState<string | null>(null);
  const [ocrOutput, setOcrOutput] = useState('');
  const [ocrLoading, setOcrLoading] = useState(false);

  // 14. Table Generator
  const [tableCols, setTableCols] = useState(['Indicator', '2024', '2025']);
  const [tableRows, setTableRows] = useState([
    ['GDP Growth (%)', '6.0%', '6.2%'],
    ['Inflation (%)', '9.8%', '8.5%'],
  ]);
  const [tableFormat, setTableFormat] = useState<'markdown' | 'csv' | 'html' | 'latex'>('markdown');

  // 15-19. Resume & Career Tools
  const [cvName, setCvName] = useState(profile?.displayName || '');
  const [cvContact, setCvContact] = useState(profile?.email || '');
  const [cvEducation, setCvEducation] = useState(profile?.university ? `${profile.university} — ${profile.faculty || ''}` : '');
  const [cvSkills, setCvSkills] = useState('Python, Econometrics, SPSS, Academic Writing, Uzbek/Russian/English');
  const [cvExperience, setCvExperience] = useState('');
  const [careerTarget, setCareerTarget] = useState('');
  const [careerInput, setCareerInput] = useState('');
  const [careerOutput, setCareerOutput] = useState('');
  const [careerLoading, setCareerLoading] = useState(false);
  const [cvSaved, setCvSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const copyText = (txt: string, key: string) => {
    navigator.clipboard.writeText(txt);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  // GPA calculation
  const gpaResult = useMemo(() => {
    let totalCreds = 0;
    let totalPoints = 0;
    courses.forEach((c) => {
      const cr = Math.max(0, Number(c.credits) || 0);
      const sc = Math.max(0, Math.min(100, Number(c.score) || 0));
      totalCreds += cr;
      if (gpaScale === '4.0') {
        const pt = sc >= 90 ? 4.0 : sc >= 85 ? 3.7 : sc >= 80 ? 3.3 : sc >= 75 ? 3.0 : sc >= 70 ? 2.7 : sc >= 65 ? 2.3 : sc >= 60 ? 2.0 : 0;
        totalPoints += pt * cr;
      } else {
        const pt = sc >= 86 ? 5.0 : sc >= 71 ? 4.0 : sc >= 56 ? 3.0 : 2.0;
        totalPoints += pt * cr;
      }
    });
    return {
      gpa: totalCreds > 0 ? (totalPoints / totalCreds).toFixed(2) : '0.00',
      credits: totalCreds,
    };
  }, [courses, gpaScale]);

  // Formatted Citation
  const formattedCitation = useMemo(() => {
    const a = citAuthor.trim() || 'Author';
    const y = citYear.trim() || 'n.d.';
    const ti = citTitle.trim() || 'Untitled';
    const p = citPublisher.trim() || 'Publisher';
    const u = citUrl.trim() ? ` ${citUrl.trim()}` : '';
    switch (citStyle) {
      case 'apa':
        return `${a} (${y}). ${ti}. ${p}.${u}`;
      case 'mla':
        return `${a} "${ti}." ${p}, ${y}.${u}`;
      case 'chicago':
        return `${a} ${ti}. ${p}, ${y}.${u}`;
      case 'ieee':
        return `${a}, "${ti}," ${p}, ${y}.${u}`;
      case 'gost':
        return `${a} ${ti}. – ${p}, ${y}.${u}`;
    }
  }, [citStyle, citAuthor, citYear, citTitle, citPublisher, citUrl]);

  // Unit conversion helper
  const unitOptions: Record<string, string[]> = {
    length: ['m', 'km', 'cm', 'mm', 'mi', 'ft'],
    mass: ['kg', 'g', 'mg', 'lb', 'oz'],
    temp: ['C', 'F', 'K'],
    data: ['B', 'KB', 'MB', 'GB', 'TB'],
    speed: ['m/s', 'km/h', 'mph'],
  };

  const convertedUnitValue = useMemo(() => {
    const v = Number(unitVal) || 0;
    if (unitCat === 'length') {
      const toM: Record<string, number> = { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, ft: 0.3048 };
      return ((v * (toM[unitFrom] || 1)) / (toM[unitTo] || 1)).toFixed(4);
    }
    if (unitCat === 'mass') {
      const toG: Record<string, number> = { g: 1, kg: 1000, mg: 0.001, lb: 453.592, oz: 28.3495 };
      return ((v * (toG[unitFrom] || 1)) / (toG[unitTo] || 1)).toFixed(4);
    }
    if (unitCat === 'temp') {
      const c = unitFrom === 'C' ? v : unitFrom === 'F' ? ((v - 32) * 5) / 9 : v - 273.15;
      const out = unitTo === 'C' ? c : unitTo === 'F' ? (c * 9) / 5 + 32 : c + 273.15;
      return out.toFixed(2);
    }
    if (unitCat === 'data') {
      const toB: Record<string, number> = { B: 1, KB: 1024, MB: 1024 ** 2, GB: 1024 ** 3, TB: 1024 ** 4 };
      return ((v * (toB[unitFrom] || 1)) / (toB[unitTo] || 1)).toFixed(4);
    }
    const toMs: Record<string, number> = { 'm/s': 1, 'km/h': 1 / 3.6, mph: 0.44704 };
    return ((v * (toMs[unitFrom] || 1)) / (toMs[unitTo] || 1)).toFixed(4);
  }, [unitCat, unitVal, unitFrom, unitTo]);

  // Table code output
  const tableExportCode = useMemo(() => {
    if (tableFormat === 'markdown') {
      const head = `| ${tableCols.join(' | ')} |`;
      const sep = `| ${tableCols.map(() => '---').join(' | ')} |`;
      const body = tableRows.map((r) => `| ${r.join(' | ')} |`).join('\n');
      return `${head}\n${sep}\n${body}`;
    }
    if (tableFormat === 'csv') {
      const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
      return [tableCols.map(esc).join(','), ...tableRows.map((r) => r.map(esc).join(','))].join('\n');
    }
    if (tableFormat === 'html') {
      return `<table>\n  <thead>\n    <tr>${tableCols.map((c) => `<th>${c}</th>`).join('')}</tr>\n  </thead>\n  <tbody>\n${tableRows
        .map((r) => `    <tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`)
        .join('\n')}\n  </tbody>\n</table>`;
    }
    return `\\begin{tabular}{${tableCols.map(() => 'l').join(' | ')}}\n\\hline\n${tableCols.join(' & ')} \\\\\n\\hline\n${tableRows
      .map((r) => `${r.join(' & ')} \\\\`)
      .join('\n')}\n\\hline\n\\end{tabular}`;
  }, [tableCols, tableRows, tableFormat]);

  // PDF Handlers
  const handleAddMergeFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = Array.from(e.target.files ?? []);
    setPdfStatus(null);
    setError(null);
    try {
      const added: { name: string; pages: number; buffer: ArrayBuffer }[] = [];
      for (const f of files) {
        const buf = await f.arrayBuffer();
        const doc = await PDFDocument.load(buf);
        added.push({ name: f.name, pages: doc.getPageCount(), buffer: buf });
      }
      setMergeFiles((prev) => [...prev, ...added]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read PDF file.');
    }
    e.target.value = '';
  };

  const handleMergeDownload = async () => {
    if (mergeFiles.length < 2) return;
    setError(null);
    try {
      const merged = await PDFDocument.create();
      for (const item of mergeFiles) {
        const src = await PDFDocument.load(item.buffer);
        const copied = await merged.copyPages(src, src.getPageIndices());
        copied.forEach((p) => merged.addPage(p));
      }
      const bytes = await merged.save();
      const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'merged_document.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      setPdfStatus(`Merged ${mergeFiles.length} PDFs (${merged.getPageCount()} pages total).`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to merge PDFs.');
    }
  };

  const handleLoadSplitPdf = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setError(null);
    setPdfStatus(null);
    try {
      const buf = await f.arrayBuffer();
      const doc = await PDFDocument.load(buf);
      setSplitFile({ name: f.name, pages: doc.getPageCount(), buffer: buf });
      setSplitRange(`1-${Math.min(2, doc.getPageCount())}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load PDF.');
    }
    e.target.value = '';
  };

  const handleSplitDownload = async () => {
    if (!splitFile) return;
    setError(null);
    try {
      const indices = parsePageSelection(splitRange, splitFile.pages);
      if (indices.length === 0) {
        setError(`Enter valid page numbers between 1 and ${splitFile.pages} (e.g., 1-3, 5).`);
        return;
      }
      const src = await PDFDocument.load(splitFile.buffer);
      const out = await PDFDocument.create();
      const copied = await out.copyPages(src, indices);
      copied.forEach((p) => out.addPage(p));
      const bytes = await out.save();
      const blob = new Blob([new Uint8Array(bytes)], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `split_${splitFile.name}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1500);
      setPdfStatus(`Extracted ${indices.length} page(s).`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to split PDF.');
    }
  };

  const handleOcrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    setOcrLoading(true);
    setError(null);
    setOcrOutput('');
    try {
      const parsed = await parseUploadedFile(file);
      setOcrImageName(file.name);
      const resp = await callAiApi<{ analysis: { extractedTextPreview: string } }>(
        '/api/analyzer/analyze',
        {
          fileName: parsed.fileName,
          mimeType: parsed.mimeType,
          extractedText: parsed.extractedText,
          base64Data: parsed.base64Data,
          language,
        },
        'ocr'
      );
      if (!resp?.analysis || typeof resp.analysis !== 'object') {
        throw new Error('OCR service returned an empty response. Please try again.');
      }
      setOcrOutput(resp.analysis?.extractedTextPreview || 'No readable text detected.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'OCR failed.');
    } finally {
      setOcrLoading(false);
    }
  };

  const handleCareerAssist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    const payloadText =
      careerTool === 'resume'
        ? `Name: ${cvName}\nContact: ${cvContact}\nEducation: ${cvEducation}\nSkills: ${cvSkills}\nExperience:\n${cvExperience}`
        : careerInput;
    if (!payloadText.trim()) return;

    setCareerLoading(true);
    setError(null);
    try {
      const resp = await callAiApi<{ output: string }>(
        '/api/career/assist',
        {
          mode: careerTool,
          promptText: payloadText,
          targetRoleOrProgram: careerTarget,
          language,
        },
        `career_${careerTool}`
      );
      if (typeof resp?.output !== 'string') {
        throw new Error('Career assistant returned an empty response. Please try again.');
      }
      setCareerOutput(resp.output);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Career assistant request failed.');
    } finally {
      setCareerLoading(false);
    }
  };

  const downloadResumePdf = () => {
    const pdf = new jsPDF({ unit: 'mm', format: 'a4' });
    let y = 20;
    const write = (txt: string, size = 11, bold = false) => {
      pdf.setFont('helvetica', bold ? 'bold' : 'normal');
      pdf.setFontSize(size);
      const lines = pdf.splitTextToSize(txt, 170) as string[];
      for (const l of lines) {
        if (y > 275) {
          pdf.addPage();
          y = 20;
        }
        pdf.text(l, 20, y);
        y += size * 0.48 + 1.5;
      }
      y += 3;
    };
    write(cvName || 'Student Resume', 18, true);
    if (cvContact) write(cvContact, 10);
    write('EDUCATION', 12, true);
    write(cvEducation || 'University Student', 10.5);
    write('SKILLS & LANGUAGES', 12, true);
    write(cvSkills, 10.5);
    write('EXPERIENCE & PROJECTS', 12, true);
    write(cvExperience || careerOutput || 'Academic projects and coursework', 10.5);
    pdf.save(`${(cvName || 'resume').replace(/\s+/g, '_')}.pdf`);
  };

  const handleSaveResume = async () => {
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    await saveWorkspaceItem({
      userId: firebaseUser.uid,
      title: `CV — ${cvName || 'Student'}`,
      type: 'resume',
      folder: 'Career & Admissions',
      language,
      summary: cvEducation,
      content: { cvName, cvContact, cvEducation, cvSkills, cvExperience, careerOutput },
    });
    setCvSaved(true);
    setTimeout(() => setCvSaved(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Category Switcher */}
      <div className="flex flex-wrap items-center gap-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-2">
        {[
          { id: 'calculators' as ToolCategory, label: 'Academic & Math Calculators (10)', icon: Calculator },
          { id: 'pdf_data' as ToolCategory, label: 'PDF, OCR & Table Studio (4)', icon: FilePlus2 },
          { id: 'career' as ToolCategory, label: 'CV, Career & Admissions (5)', icon: Briefcase },
        ].map((cat) => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategory(cat.id)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0 ${
                category === cat.id
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              {cat.label}
            </button>
          );
        })}
      </div>

      {error && (
        <div className="bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {/* CATEGORY 1: CALCULATORS */}
      {category === 'calculators' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-1">
            {[
              ['gpa', 'GPA Calculator'],
              ['scholarship', 'Scholarship Eligibility'],
              ['attendance', 'Attendance Calculator'],
              ['grade', 'Weighted Grade Calculator'],
              ['budget', 'Student Budget Planner'],
              ['currency', 'Currency Converter'],
              ['units', 'Unit Converter'],
              ['citation', 'Citation Generator'],
              ['bibliography', 'Bibliography Builder'],
              ['wordcount', 'Word & Character Counter'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setCalcTool(id as CalculatorTool)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium cursor-pointer ${
                  calcTool === id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="lg:col-span-9 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
            {calcTool === 'gpa' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                    GPA Calculator
                  </h2>
                  <select
                    value={gpaScale}
                    onChange={(e) => setGpaScale(e.target.value as '4.0' | '5.0')}
                    className="px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="4.0">4.0 Credit Scale</option>
                    <option value="5.0">5.0 CIS / Uzbekistan Scale</option>
                  </select>
                </div>
                <div className="space-y-2">
                  {courses.map((c, i) => (
                    <div key={i} className="grid grid-cols-12 gap-2 items-center">
                      <input
                        value={c.name}
                        onChange={(e) => setCourses(courses.map((x, idx) => (idx === i ? { ...x, name: e.target.value } : x)))}
                        placeholder="Course name"
                        className="col-span-6 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                      <input
                        type="number"
                        min={1}
                        max={12}
                        value={c.credits}
                        onChange={(e) => setCourses(courses.map((x, idx) => (idx === i ? { ...x, credits: Number(e.target.value) } : x)))}
                        className="col-span-2 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                      />
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={c.score}
                        onChange={(e) => setCourses(courses.map((x, idx) => (idx === i ? { ...x, score: Number(e.target.value) } : x)))}
                        className="col-span-3 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                      />
                      <button
                        type="button"
                        onClick={() => setCourses(courses.filter((_, idx) => idx !== i))}
                        className="col-span-1 text-slate-400 hover:text-red-600 cursor-pointer flex justify-center"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={() => setCourses([...courses, { name: `Course ${courses.length + 1}`, credits: 3, score: 85 }])}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Course
                  </button>
                  <div className="text-right">
                    <p className="text-xs text-slate-500">Total Credits: {gpaResult.credits}</p>
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                      GPA {gpaResult.gpa} / {gpaScale}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {calcTool === 'scholarship' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Scholarship Eligibility Calculator
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Scale</label>
                    <select
                      value={schScale}
                      onChange={(e) => setSchScale(e.target.value as '5.0' | '4.0')}
                      className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                    >
                      <option value="5.0">5.0 Scale (Uzbekistan National)</option>
                      <option value="4.0">4.0 Credit Scale</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Current GPA</label>
                    <input
                      type="number"
                      step="0.1"
                      value={schGpa}
                      onChange={(e) => setSchGpa(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Attendance (%)</label>
                    <input
                      type="number"
                      value={schAttendance}
                      onChange={(e) => setSchAttendance(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Research / Extracurricular Points</label>
                    <input
                      type="number"
                      value={schResearchPoints}
                      onChange={(e) => setSchResearchPoints(Number(e.target.value))}
                      className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                    />
                  </div>
                </div>
                {(() => {
                  const norm5 = schScale === '5.0' ? schGpa : (schGpa / 4) * 5;
                  const tier =
                    norm5 >= 4.7 && schAttendance >= 90 && schResearchPoints >= 15
                      ? 'Presidential / Rector Excellence Tier Candidate'
                      : norm5 >= 4.5 && schAttendance >= 85
                      ? 'Increased Academic Stipend (5.0 / High Distinction Tier)'
                      : norm5 >= 3.5 && schAttendance >= 75
                      ? 'Standard Academic Stipend Eligible'
                      : 'Below Standard Stipend Threshold — Improve GPA or Attendance';
                  return (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{tier}</p>
                      <p className="text-xs text-slate-500 mt-1">
                        Normalized 5.0 equivalent: {norm5.toFixed(2)}. Exact stipend quotas vary by university charter and faculty committee review.
                      </p>
                    </div>
                  );
                })()}
              </div>
            )}

            {calcTool === 'attendance' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Attendance Calculator
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Classes Held</label>
                    <input type="number" min={1} value={attTotal} onChange={(e) => setAttTotal(Number(e.target.value))} className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums" />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Attended</label>
                    <input type="number" min={0} value={attPresent} onChange={(e) => setAttPresent(Number(e.target.value))} className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums" />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Required %</label>
                    <input type="number" min={1} max={100} value={attRequired} onChange={(e) => setAttRequired(Number(e.target.value))} className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums" />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Remaining Classes</label>
                    <input type="number" min={0} value={attRemaining} onChange={(e) => setAttRemaining(Number(e.target.value))} className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums" />
                  </div>
                </div>
                {(() => {
                  const pct = attTotal > 0 ? (attPresent / attTotal) * 100 : 0;
                  const finalTotal = attTotal + attRemaining;
                  const minNeededTotal = Math.ceil((attRequired / 100) * finalTotal);
                  const mustAttend = Math.max(0, minNeededTotal - attPresent);
                  const canMiss = Math.max(0, attRemaining - mustAttend);
                  return (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1">
                      <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                        Current Attendance: {pct.toFixed(1)}%
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        {mustAttend > attRemaining
                          ? `Even attending all ${attRemaining} remaining classes reaches ${(((attPresent + attRemaining) / finalTotal) * 100).toFixed(1)}%.`
                          : `You must attend at least ${mustAttend} of the remaining ${attRemaining} classes (you can miss up to ${canMiss}).`}
                      </p>
                    </div>
                  );
                })()}
              </div>
            )}

            {calcTool === 'grade' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Weighted Grade & Final Exam Target Calculator
                </h2>
                {gradeItems.map((g, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                    <input
                      value={g.name}
                      onChange={(e) => setGradeItems(gradeItems.map((x, i) => (i === idx ? { ...x, name: e.target.value } : x)))}
                      className="col-span-6 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                    />
                    <input
                      type="number"
                      value={g.weight}
                      onChange={(e) => setGradeItems(gradeItems.map((x, i) => (i === idx ? { ...x, weight: Number(e.target.value) } : x)))}
                      placeholder="Weight %"
                      className="col-span-2 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                    />
                    <input
                      type="number"
                      value={g.score}
                      onChange={(e) => setGradeItems(gradeItems.map((x, i) => (i === idx ? { ...x, score: Number(e.target.value) } : x)))}
                      placeholder="Score %"
                      className="col-span-3 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                    />
                    <button type="button" onClick={() => setGradeItems(gradeItems.filter((_, i) => i !== idx))} className="col-span-1 text-slate-400 hover:text-red-600 cursor-pointer flex justify-center">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <button
                    type="button"
                    onClick={() => setGradeItems([...gradeItems, { name: 'Assessment', weight: 10, score: 85 }])}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Component
                  </button>
                  <div className="flex items-center gap-2 text-xs">
                    <span>Target Course Score (%):</span>
                    <input
                      type="number"
                      value={targetFinalGrade}
                      onChange={(e) => setTargetFinalGrade(Number(e.target.value))}
                      className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                    />
                  </div>
                </div>
                {(() => {
                  const usedWeight = gradeItems.reduce((a, b) => a + b.weight, 0);
                  const earned = gradeItems.reduce((a, b) => a + (b.weight / 100) * b.score, 0);
                  const remWeight = Math.max(0, 100 - usedWeight);
                  const neededFinal = remWeight > 0 ? ((targetFinalGrade - earned) / (remWeight / 100)).toFixed(1) : null;
                  return (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                      <p className="text-sm font-semibold tabular-nums">
                        Earned so far: {earned.toFixed(1)} / {usedWeight}% weight
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        {remWeight > 0
                          ? `Remaining weight: ${remWeight}%. You need ${neededFinal}% on the remaining assessment to reach ${targetFinalGrade}%.`
                          : `100% weight accounted for. Final course average: ${earned.toFixed(1)}%.`}
                      </p>
                    </div>
                  );
                })()}
              </div>
            )}

            {calcTool === 'budget' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Student Monthly Budget Planner (UZS)
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">Monthly Income</p>
                    {Object.entries(budgetIncome).map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between gap-2">
                        <span className="text-xs capitalize">{k}</span>
                        <input
                          type="number"
                          value={v}
                          onChange={(e) => setBudgetIncome({ ...budgetIncome, [k]: Number(e.target.value) })}
                          className="w-36 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums text-right"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-red-600 dark:text-red-400">Monthly Expenses</p>
                    {Object.entries(budgetExpenses).map(([k, v]) => (
                      <div key={k} className="flex items-center justify-between gap-2">
                        <span className="text-xs capitalize">{k}</span>
                        <input
                          type="number"
                          value={v}
                          onChange={(e) => setBudgetExpenses({ ...budgetExpenses, [k]: Number(e.target.value) })}
                          className="w-36 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums text-right"
                        />
                      </div>
                    ))}
                  </div>
                </div>
                {(() => {
                  const inc = (Object.values(budgetIncome) as number[]).reduce((a, b) => a + b, 0);
                  const exp = (Object.values(budgetExpenses) as number[]).reduce((a, b) => a + b, 0);
                  const net = inc - exp;
                  return (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-wrap justify-between gap-4">
                      <div>
                        <p className="text-xs text-slate-500">Total Income</p>
                        <p className="text-base font-bold tabular-nums">{inc.toLocaleString()} UZS</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Total Expenses</p>
                        <p className="text-base font-bold tabular-nums">{exp.toLocaleString()} UZS</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-500">Monthly Net Balance</p>
                        <p className={`text-base font-bold tabular-nums ${net >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                          {net.toLocaleString()} UZS
                        </p>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {calcTool === 'currency' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Currency Converter (UZS / USD / EUR / RUB / KZT)
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input
                    type="number"
                    value={fxAmount}
                    onChange={(e) => setFxAmount(Number(e.target.value))}
                    className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                  />
                  <select
                    value={fxFrom}
                    onChange={(e) => setFxFrom(e.target.value)}
                    className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    {Object.keys(fxRates).map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <select
                    value={fxTo}
                    onChange={(e) => setFxTo(e.target.value)}
                    className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    {Object.keys(fxRates).map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                    {((fxAmount / (fxRates[fxFrom] || 1)) * (fxRates[fxTo] || 1)).toLocaleString(undefined, { maximumFractionDigits: 2 })} {fxTo}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Reference rates relative to 1 USD (editable below if checking current Central Bank rates):
                  </p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                    {Object.entries(fxRates).filter(([k]) => k !== 'USD').map(([cur, rate]) => (
                      <label key={cur} className="text-[11px] flex items-center justify-between gap-1 bg-white dark:bg-slate-900 px-2 py-1 rounded border border-slate-200 dark:border-slate-700">
                        <span>{cur}</span>
                        <input
                          type="number"
                          step="0.01"
                          value={rate}
                          onChange={(e) => setFxRates({ ...fxRates, [cur]: Number(e.target.value) || 1 })}
                          className="w-20 text-right bg-transparent outline-none tabular-nums"
                        />
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {calcTool === 'units' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Scientific Unit Converter
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <select
                    value={unitCat}
                    onChange={(e) => {
                      const next = e.target.value as typeof unitCat;
                      setUnitCat(next);
                      setUnitFrom(unitOptions[next][0]);
                      setUnitTo(unitOptions[next][1]);
                    }}
                    className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="length">Length</option>
                    <option value="mass">Mass</option>
                    <option value="temp">Temperature</option>
                    <option value="data">Data Storage</option>
                    <option value="speed">Speed</option>
                  </select>
                  <input
                    type="number"
                    value={unitVal}
                    onChange={(e) => setUnitVal(Number(e.target.value))}
                    className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
                  />
                  <select value={unitFrom} onChange={(e) => setUnitFrom(e.target.value)} className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg">
                    {unitOptions[unitCat].map((u) => <option key={u} value={u}>{u}</option>)}
                  </select>
                  <select value={unitTo} onChange={(e) => setUnitTo(e.target.value)} className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg">
                    {unitOptions[unitCat].map((u) => <option key={u} value={u}>{u}</option>)}
                  </select>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-2xl font-bold tabular-nums text-blue-600 dark:text-blue-400">
                  {convertedUnitValue} {unitTo}
                </div>
              </div>
            )}

            {(calcTool === 'citation' || calcTool === 'bibliography') && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  {calcTool === 'citation' ? 'Academic Citation Generator' : 'Bibliography List Builder'}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select
                    value={citStyle}
                    onChange={(e) => setCitStyle(e.target.value as typeof citStyle)}
                    className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                  >
                    <option value="apa">APA 7th Edition</option>
                    <option value="mla">MLA 9th Edition</option>
                    <option value="chicago">Chicago Style</option>
                    <option value="ieee">IEEE Style</option>
                    <option value="gost">GOST / UZ DST</option>
                  </select>
                  <input value={citYear} onChange={(e) => setCitYear(e.target.value)} placeholder="Year (e.g., 2024)" className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                  <input value={citAuthor} onChange={(e) => setCitAuthor(e.target.value)} placeholder="Author(s)" className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                  <input value={citPublisher} onChange={(e) => setCitPublisher(e.target.value)} placeholder="Journal / Publisher" className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                  <input value={citTitle} onChange={(e) => setCitTitle(e.target.value)} placeholder="Work Title" className="sm:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                  <input value={citUrl} onChange={(e) => setCitUrl(e.target.value)} placeholder="DOI or URL (optional)" className="sm:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3">
                  <p className="text-sm text-slate-800 dark:text-slate-100">{formattedCitation}</p>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => copyText(formattedCitation, 'cit')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg cursor-pointer"
                    >
                      {copiedKey === 'cit' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedKey === 'cit' ? t.common.copied : t.common.copy}
                    </button>
                    <button
                      type="button"
                      onClick={() => setBibliography((prev) => Array.from(new Set([...prev, formattedCitation])).sort())}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add to Bibliography
                    </button>
                  </div>
                </div>

                {bibliography.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-slate-500">Bibliography ({bibliography.length})</p>
                      <button
                        type="button"
                        onClick={() => copyText(bibliography.map((b, i) => `${i + 1}. ${b}`).join('\n'), 'bib')}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                      >
                        {copiedKey === 'bib' ? t.common.copied : 'Copy All'}
                      </button>
                    </div>
                    <ol className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 list-decimal pl-5">
                      {bibliography.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ol>
                  </div>
                )}
              </div>
            )}

            {calcTool === 'wordcount' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Word, Character & Page Counter
                </h2>
                <textarea
                  rows={8}
                  value={wordText}
                  onChange={(e) => setWordText(e.target.value)}
                  placeholder="Paste your essay, abstract, or coursework draft here..."
                  className="w-full p-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
                />
                {(() => {
                  const words = wordText.trim() ? wordText.trim().split(/\s+/).length : 0;
                  const chars = wordText.length;
                  const charsNoSpace = wordText.replace(/\s/g, '').length;
                  const sentences = wordText.trim() ? wordText.split(/[.!?]+/).filter((s) => s.trim()).length : 0;
                  const pages = (words / 275).toFixed(1);
                  return (
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                      {[
                        ['Words', words],
                        ['Characters', chars],
                        ['No Spaces', charsNoSpace],
                        ['Sentences', sentences],
                        ['~A4 Pages', pages],
                      ].map(([lbl, val]) => (
                        <div key={String(lbl)} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
                          <p className="text-[11px] text-slate-500">{lbl}</p>
                          <p className="text-lg font-bold tabular-nums text-slate-900 dark:text-slate-100">{val}</p>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* CATEGORY 2: PDF, OCR & TABLE STUDIO */}
      {category === 'pdf_data' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-1">
            {[
              ['pdf_merge', 'PDF Merger'],
              ['pdf_split', 'PDF Splitter'],
              ['ocr', 'Image-to-Text (OCR)'],
              ['table_gen', 'Table Generator'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setPdfTool(id as PdfDataTool)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium cursor-pointer ${
                  pdfTool === id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="lg:col-span-9 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
            {pdfTool === 'pdf_merge' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Real PDF Merger (Client-side pdf-lib)
                </h2>
                <label className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold cursor-pointer">
                  <FilePlus2 className="w-4 h-4" />
                  Select PDF Files
                  <input type="file" accept=".pdf,application/pdf" multiple className="hidden" onChange={handleAddMergeFiles} />
                </label>
                {mergeFiles.length > 0 && (
                  <div className="space-y-2">
                    {mergeFiles.map((mf, i) => (
                      <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 text-xs">
                        <span>{i + 1}. {mf.name} ({mf.pages} pages)</span>
                        <button type="button" onClick={() => setMergeFiles(mergeFiles.filter((_, idx) => idx !== i))} className="text-red-500 cursor-pointer">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      disabled={mergeFiles.length < 2}
                      onClick={() => void handleMergeDownload()}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold disabled:opacity-50 cursor-pointer"
                    >
                      <Download className="w-4 h-4" /> Merge & Download PDF
                    </button>
                  </div>
                )}
                {pdfStatus && <p className="text-xs text-emerald-600 dark:text-emerald-400">{pdfStatus}</p>}
              </div>
            )}

            {pdfTool === 'pdf_split' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Real PDF Splitter
                </h2>
                <label className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold cursor-pointer">
                  <Scissors className="w-4 h-4" />
                  Choose PDF
                  <input type="file" accept=".pdf,application/pdf" className="hidden" onChange={handleLoadSplitPdf} />
                </label>
                {splitFile && (
                  <div className="space-y-3">
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      Loaded: <span className="font-semibold">{splitFile.name}</span> ({splitFile.pages} pages total)
                    </p>
                    <div className="flex flex-wrap items-center gap-3">
                      <input
                        value={splitRange}
                        onChange={(e) => setSplitRange(e.target.value)}
                        placeholder="e.g., 1-3, 5"
                        className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={() => void handleSplitDownload()}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        <Download className="w-4 h-4" /> Extract Pages as PDF
                      </button>
                    </div>
                  </div>
                )}
                {pdfStatus && <p className="text-xs text-emerald-600 dark:text-emerald-400">{pdfStatus}</p>}
              </div>
            )}

            {pdfTool === 'ocr' && (
              <div className="space-y-4">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  Image-to-Text Converter (OCR)
                </h2>
                <label className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold cursor-pointer">
                  <ImageIcon className="w-4 h-4" />
                  {ocrLoading ? 'Running OCR...' : 'Upload Image (JPG / PNG)'}
                  <input type="file" accept="image/*" className="hidden" onChange={handleOcrUpload} />
                </label>
                {ocrImageName && <p className="text-xs text-slate-500">File: {ocrImageName}</p>}
                {ocrOutput && (
                  <div className="space-y-2">
                    <textarea
                      rows={8}
                      readOnly
                      value={ocrOutput}
                      className="w-full p-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => copyText(ocrOutput, 'ocr')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      {copiedKey === 'ocr' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedKey === 'ocr' ? t.common.copied : t.common.copy}
                    </button>
                  </div>
                )}
              </div>
            )}

            {pdfTool === 'table_gen' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                    Interactive Table Generator
                  </h2>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setTableCols([...tableCols, `Col ${tableCols.length + 1}`]);
                        setTableRows(tableRows.map((r) => [...r, '']));
                      }}
                      className="px-2.5 py-1 text-xs border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                    >
                      + Column
                    </button>
                    <button
                      type="button"
                      onClick={() => setTableRows([...tableRows, tableCols.map(() => '')])}
                      className="px-2.5 py-1 text-xs border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                    >
                      + Row
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-xs">
                    <thead>
                      <tr>
                        {tableCols.map((col, ci) => (
                          <th key={ci} className="p-1 border border-slate-200 dark:border-slate-700">
                            <input
                              value={col}
                              onChange={(e) => setTableCols(tableCols.map((c, idx) => (idx === ci ? e.target.value : c)))}
                              className="w-full px-2 py-1 font-semibold bg-slate-50 dark:bg-slate-800 rounded outline-none"
                            />
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {tableRows.map((row, ri) => (
                        <tr key={ri}>
                          {row.map((cell, ci) => (
                            <td key={ci} className="p-1 border border-slate-200 dark:border-slate-700">
                              <input
                                value={cell}
                                onChange={(e) =>
                                  setTableRows(
                                    tableRows.map((r, rIdx) =>
                                      rIdx === ri ? r.map((v, cIdx) => (cIdx === ci ? e.target.value : v)) : r
                                    )
                                  )
                                }
                                className="w-full px-2 py-1 bg-transparent outline-none"
                              />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {(['markdown', 'csv', 'html', 'latex'] as const).map((fmt) => (
                      <button
                        key={fmt}
                        type="button"
                        onClick={() => setTableFormat(fmt)}
                        className={`px-2.5 py-1 text-xs rounded-md uppercase font-mono cursor-pointer ${
                          tableFormat === fmt ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900' : 'bg-slate-100 dark:bg-slate-800'
                        }`}
                      >
                        {fmt}
                      </button>
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => copyText(tableExportCode, 'tbl')}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs bg-blue-600 text-white rounded-lg cursor-pointer"
                  >
                    {copiedKey === 'tbl' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'tbl' ? t.common.copied : t.common.copy}
                  </button>
                </div>
                <pre className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono overflow-x-auto">
                  {tableExportCode}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CATEGORY 3: RESUME, CAREER & ADMISSIONS */}
      {category === 'career' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-1">
            {[
              ['resume', 'Resume & CV Builder'],
              ['internship', 'Internship Application'],
              ['job', 'Job Application'],
              ['interview', 'Interview Preparation'],
              ['admissions', 'University Admissions'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  setCareerTool(id as CareerTool);
                  setCareerOutput('');
                }}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium cursor-pointer ${
                  careerTool === id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <form
            onSubmit={handleCareerAssist}
            className="lg:col-span-9 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 capitalize">
                {careerTool === 'resume' ? 'Resume & CV Builder' : `${careerTool} Assistant`}
              </h2>
              {careerTool === 'resume' && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={downloadResumePdf}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> {t.common.downloadPdf}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleSaveResume()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-emerald-600 text-white rounded-lg cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" /> {cvSaved ? t.common.saved : t.common.save}
                  </button>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                {careerTool === 'admissions' ? 'Target University & Degree Program' : 'Target Role / Company'}
              </label>
              <input
                value={careerTarget}
                onChange={(e) => setCareerTarget(e.target.value)}
                placeholder={careerTool === 'admissions' ? 'e.g., MSc Data Science — Central European / TU Munich' : 'e.g., Junior Financial Analyst'}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>

            {careerTool === 'resume' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input value={cvName} onChange={(e) => setCvName(e.target.value)} placeholder="Full Name" className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                <input value={cvContact} onChange={(e) => setCvContact(e.target.value)} placeholder="Email · Phone · City" className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                <input value={cvEducation} onChange={(e) => setCvEducation(e.target.value)} placeholder="University, Major, GPA, Expected Graduation" className="sm:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                <input value={cvSkills} onChange={(e) => setCvSkills(e.target.value)} placeholder="Technical Skills & Languages" className="sm:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg" />
                <textarea
                  rows={4}
                  value={cvExperience}
                  onChange={(e) => setCvExperience(e.target.value)}
                  placeholder="Internships, research projects, leadership, achievements..."
                  className="sm:col-span-2 p-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
            ) : (
              <textarea
                rows={5}
                value={careerInput}
                onChange={(e) => setCareerInput(e.target.value)}
                placeholder="Describe your background, GPA, projects, skills, or paste the prompt/job description..."
                className="w-full p-3 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            )}

            <button
              type="submit"
              disabled={careerLoading}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer"
            >
              {careerLoading ? t.common.generating : careerTool === 'resume' ? 'Polish & Strengthen CV with AI' : t.common.generate}
            </button>

            {careerOutput && (
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex justify-end">
                  <button type="button" onClick={() => copyText(careerOutput, 'car')} className="text-xs text-blue-600 dark:text-blue-400 hover:underline cursor-pointer">
                    {copiedKey === 'car' ? t.common.copied : t.common.copy}
                  </button>
                </div>
                <div className="text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">
                  {careerOutput}
                </div>
              </div>
            )}
          </form>
        </div>
      )}
    </div>
  );
};
