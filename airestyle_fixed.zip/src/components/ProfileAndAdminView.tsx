import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  Cpu,
  LogOut,
  RefreshCw,
  Save,
  ShieldCheck,
  Users,
} from 'lucide-react';
import {
  SUPPORTED_LANGUAGES,
  type AcademicLevel,
  type Language,
  type ModuleId,
  type SubscriptionPlan,
  type SystemLog,
  type UserProfile,
  type UserRole,
} from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { invalidateAiHealthCache } from '../services/aiClient';
import {
  adminUpdateUser,
  listAllUsersAdmin,
  listSystemLogs,
  savePlatformConfig,
  updateUserProfile,
} from '../lib/firestoreService';

function splitProviderModel(rawModel: string): { provider: string; model: string } {
  const val = (rawModel || 'unknown').trim();
  const lower = val.toLowerCase();

  if (lower.startsWith('groq/')) {
    return { provider: 'GROQ', model: val.slice(5) || 'unknown' };
  }
  if (lower.startsWith('gemini/')) {
    return { provider: 'GEMINI', model: val.slice(7) || 'unknown' };
  }
  if (lower.startsWith('openai/') && !lower.includes('gpt-oss')) {
    return { provider: 'OPENAI', model: val.slice(7) || 'unknown' };
  }
  if (
    lower.includes('gpt-oss') ||
    lower.startsWith('llama-') ||
    lower.startsWith('meta-llama/') ||
    lower.startsWith('qwen/') ||
    lower.startsWith('moonshotai/')
  ) {
    return { provider: 'GROQ', model: val };
  }
  if (lower.startsWith('gpt-') || lower.startsWith('o1') || lower.startsWith('o3') || lower.startsWith('o4')) {
    return { provider: 'OPENAI', model: val };
  }
  if (lower.startsWith('gemini')) {
    return { provider: 'GEMINI', model: val };
  }
  return { provider: 'AI', model: val };
}

export const ProfileView: React.FC = () => {
  const { firebaseUser, profile, isAdmin, language, setLanguage, logout, refreshProfile, signInWithGoogle } =
    useAuth();
  const t = UI_STRINGS[language];

  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [university, setUniversity] = useState(profile?.university || '');
  const [faculty, setFaculty] = useState(profile?.faculty || '');
  const [academicLevel, setAcademicLevel] = useState<AcademicLevel>(profile?.academicLevel || 'undergraduate');
  const [preferredLanguage, setPreferredLanguage] = useState<Language>(profile?.preferredLanguage || language);
  const [myLogs, setMyLogs] = useState<SystemLog[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName || '');
      setUniversity(profile.university || '');
      setFaculty(profile.faculty || '');
      setAcademicLevel(profile.academicLevel || 'undergraduate');
      setPreferredLanguage(profile.preferredLanguage || language);
    }
  }, [profile, language]);

  useEffect(() => {
    if (firebaseUser) {
      listSystemLogs(firebaseUser.uid)
        .then(setMyLogs)
        .catch(() => setMyLogs([]));
    }
  }, [firebaseUser]);

  if (!firebaseUser || !profile) {
    return (
      <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4">
        <h2 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
          {t.auth.signInRequiredTitle}
        </h2>
        <p className="text-sm text-slate-600 dark:text-slate-400">{t.auth.signInRequiredDesc}</p>
        <button
          type="button"
          onClick={() => void signInWithGoogle()}
          className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 cursor-pointer"
        >
          {t.auth.signInGoogle}
        </button>
      </div>
    );
  }

  const usagePct = Math.min(100, Math.round((profile.aiRequestsUsed / Math.max(1, profile.aiMonthlyLimit)) * 100));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      await updateUserProfile(profile.uid, {
        displayName,
        university,
        faculty,
        academicLevel,
        preferredLanguage,
      });
      setLanguage(preferredLanguage);
      await refreshProfile();
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Account Summary & Quota */}
      <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex items-center gap-3">
          {profile.photoUrl ? (
            <img src={profile.photoUrl} alt={profile.displayName} className="w-12 h-12 rounded-full object-cover" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
              {profile.displayName.slice(0, 1).toUpperCase()}
            </div>
          )}
          <div className="min-w-0">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-slate-100 truncate">
              {profile.displayName}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{profile.email}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
            <p className="text-slate-500">Role</p>
            <p className="mt-1 font-semibold uppercase text-slate-900 dark:text-slate-100">
              {isAdmin ? 'Admin' : profile.role}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
            <p className="text-slate-500">Subscription Plan</p>
            <p className="mt-1 font-semibold uppercase text-blue-600 dark:text-blue-400">{profile.plan}</p>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 dark:text-slate-400">Monthly AI Usage</span>
            <span className="font-mono font-semibold tabular-nums">
              {profile.aiRequestsUsed} / {profile.aiMonthlyLimit}
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div className="h-full bg-blue-600 transition-all" style={{ width: `${usagePct}%` }} />
          </div>
        </div>

        <button
          type="button"
          onClick={() => void logout()}
          className="w-full inline-flex items-center justify-center gap-2 py-2.5 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          {t.auth.signOut}
        </button>
      </div>

      {/* Edit Profile + Personal Log */}
      <div className="lg:col-span-7 space-y-6">
        <form
          onSubmit={handleSave}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Academic Profile Settings
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">Display Name</label>
              <input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Academic Level</label>
              <select
                value={academicLevel}
                onChange={(e) => setAcademicLevel(e.target.value as AcademicLevel)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="undergraduate">Undergraduate (Bakalavr)</option>
                <option value="masters">Master's (Magistratura)</option>
                <option value="phd">PhD / Doctoral</option>
                <option value="researcher">Researcher</option>
                <option value="faculty">Faculty / Instructor</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">University</label>
              <input
                value={university}
                onChange={(e) => setUniversity(e.target.value)}
                placeholder="e.g., National University of Uzbekistan"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">Faculty / Department</label>
              <input
                value={faculty}
                onChange={(e) => setFaculty(e.target.value)}
                placeholder="e.g., Economics & Applied Mathematics"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs text-slate-500 mb-1">Preferred Language</label>
              <select
                value={preferredLanguage}
                onChange={(e) => setPreferredLanguage(e.target.value as Language)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.nativeName} ({l.label})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {error && <p className="text-xs text-red-600">{error}</p>}

          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 cursor-pointer"
          >
            {saved ? <CheckCircle2 className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            {saving ? t.common.saving : saved ? t.common.saved : t.common.save}
          </button>
        </form>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Recent AI Activity
          </h3>
          {myLogs.length === 0 ? (
            <p className="text-xs text-slate-500">No AI requests recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-60 overflow-y-auto">
              {myLogs.slice(0, 12).map((log) => (
                <div key={log.id} className="py-2 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{log.tool}</span>
                    {(() => {
                      const pm = splitProviderModel(log.model);
                      return (
                        <span className="text-slate-400 ml-2 font-mono">
                          [{pm.provider}] {pm.model}
                        </span>
                      );
                    })()}
                  </div>
                  <div className="flex items-center gap-3 tabular-nums">
                    <span className="text-slate-500">{log.tokens} tok</span>
                    <span className={log.status === 'ok' ? 'text-emerald-600' : 'text-red-500'}>
                      {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

/* ================================================================== */
/* Admin Console                                                      */
/* ================================================================== */

const TOGGLEABLE_TOOLS: { id: ModuleId; label: string }[] = [
  { id: 'assistant', label: 'Core AI Assistant' },
  { id: 'documents', label: 'Academic Documents' },
  { id: 'presentations', label: 'Presentations' },
  { id: 'solver', label: 'Math & Economics Solver' },
  { id: 'analyzer', label: 'Document Analyzer' },
  { id: 'exams', label: 'Exam System' },
  { id: 'translator', label: 'Translator & Writing' },
  { id: 'research', label: 'Research Assistant' },
  { id: 'tools', label: 'Student Utilities' },
  { id: 'studyboost', label: 'Study Boost (AI)' },
];

export const AdminView: React.FC = () => {
  const { firebaseUser, isAdmin, platformConfig } = useAuth();

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [userEdits, setUserEdits] = useState<
    Record<string, { role: UserRole; plan: SubscriptionPlan; aiMonthlyLimit: number }>
  >({});

  // Config draft state
  const [activeModel, setActiveModel] = useState(platformConfig.activeModel);
  const [defaultLimit, setDefaultLimit] = useState(platformConfig.defaultMonthlyLimit);
  const [announcement, setAnnouncement] = useState(platformConfig.announcement);
  const [announcementActive, setAnnouncementActive] = useState(platformConfig.announcementActive);
  const [disabledTools, setDisabledTools] = useState<string[]>(platformConfig.disabledTools);
  const [enabledLanguages, setEnabledLanguages] = useState<string[]>(platformConfig.enabledLanguages);
  const [showErrorsOnly, setShowErrorsOnly] = useState(false);
  const [savingConfig, setSavingConfig] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [serverHealth, setServerHealth] = useState<{
    provider: 'openai' | 'gemini' | 'groq';
    envProvider?: 'openai' | 'gemini' | 'groq' | null;
    model: string;
    openaiConfigured: boolean;
    geminiConfigured: boolean;
    groqConfigured: boolean;
    fallbackProvider: 'openai' | 'gemini' | 'groq' | null;
    providers?: Record<'groq' | 'openai' | 'gemini', { configured: boolean; model: string }>;
  } | null>(null);
  const [selectedProvider, setSelectedProvider] = useState<'groq' | 'openai' | 'gemini'>('groq');
  const [selectedProviderModel, setSelectedProviderModel] = useState<string>('openai/gpt-oss-20b');
  const [selectedFallback, setSelectedFallback] = useState<string>('');
  const [switchingProvider, setSwitchingProvider] = useState(false);
  const [refreshingAi, setRefreshingAi] = useState(false);
  const [liveGroqModels, setLiveGroqModels] = useState<string[]>([
    'openai/gpt-oss-20b',
    'openai/gpt-oss-120b',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'meta-llama/llama-4-maverick-17b-128e-instruct',
    'llama-3.3-70b-versatile',
    'llama-3.1-8b-instant',
    'qwen/qwen3-32b',
    'moonshotai/kimi-k2-instruct',
  ]);
  const [providerUsage, setProviderUsage] = useState<
    Record<
      'openai' | 'gemini' | 'groq',
      {
        lastModel: string | null;
        totalRequests: number;
        successCount: number;
        errorCount: number;
        inputTokens: number;
        outputTokens: number;
        totalTokens: number;
        avgDurationMs: number;
      }
    > | null
  >(null);

  const loadAiProviderState = useCallback(async () => {
    setRefreshingAi(true);
    try {
      const healthRes = await fetch('/api/health');
      if (healthRes.ok) {
        const healthData = await healthRes.json().catch(() => null);
        if (healthData && typeof healthData.provider === 'string') {
          setServerHealth(healthData);
          setSelectedProvider(healthData.provider);
          setSelectedProviderModel(healthData.model || '');
          setSelectedFallback(healthData.fallbackProvider || '');
        }
      }

      if (firebaseUser) {
        const token = await firebaseUser.getIdToken();
        const [providerRes, modelsRes, usageRes] = await Promise.all([
          fetch('/api/ai/provider', { headers: { Authorization: `Bearer ${token}` } }),
          fetch('/api/ai/models', { headers: { Authorization: `Bearer ${token}` } }),
          fetch('/api/ai/usage', { headers: { Authorization: `Bearer ${token}` } }),
        ]);

        if (providerRes.ok) {
          const pData = await providerRes.json().catch(() => null);
          if (pData && typeof pData.provider === 'string') {
            setServerHealth(pData);
            setSelectedProvider(pData.provider);
            setSelectedProviderModel(pData.model || '');
            setSelectedFallback(pData.fallbackProvider || '');
          }
        }
        if (modelsRes.ok) {
          const modelsData = await modelsRes.json().catch(() => null);
          if (modelsData?.providers?.groq?.models && Array.isArray(modelsData.providers.groq.models)) {
            const chatIds = modelsData.providers.groq.models
              .filter((m: { capabilities?: { supportsChat?: boolean } }) => m?.capabilities?.supportsChat !== false)
              .map((m: { id?: string }) => m?.id)
              .filter((id: unknown): id is string => typeof id === 'string' && id.length > 0);
            if (chatIds.length > 0) {
              setLiveGroqModels(chatIds);
            }
          }
        }
        if (usageRes.ok) {
          const usageData = await usageRes.json().catch(() => null);
          if (usageData?.providers) {
            setProviderUsage(usageData.providers);
          }
        }
      }
    } catch {
      // ignore transient refresh failure
    } finally {
      setRefreshingAi(false);
    }
  }, [firebaseUser]);

  useEffect(() => {
    setActiveModel(platformConfig.activeModel);
    setDefaultLimit(platformConfig.defaultMonthlyLimit);
    setAnnouncement(platformConfig.announcement);
    setAnnouncementActive(platformConfig.announcementActive);
    setDisabledTools(platformConfig.disabledTools);
    setEnabledLanguages(platformConfig.enabledLanguages);
  }, [platformConfig]);

  useEffect(() => {
    if (!isAdmin) {
      setLoading(false);
      return;
    }
    setLoading(true);
    Promise.all([listAllUsersAdmin(), listSystemLogs()])
      .then(([uList, lList]) => {
        setUsers(uList);
        setLogs(lList);
        const map: Record<string, { role: UserRole; plan: SubscriptionPlan; aiMonthlyLimit: number }> = {};
        uList.forEach((u) => {
          map[u.uid] = { role: u.role, plan: u.plan, aiMonthlyLimit: u.aiMonthlyLimit };
        });
        setUserEdits(map);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load admin data.'))
      .finally(() => setLoading(false));

    void loadAiProviderState();
  }, [isAdmin, loadAiProviderState]);

  if (!isAdmin) {
    return (
      <div className="max-w-lg mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-3">
        <ShieldCheck className="w-9 h-9 text-red-500 mx-auto" />
        <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
          Administrator Access Required
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Only authorized platform administrators can view user management, model settings, and system logs.
        </p>
      </div>
    );
  }

  const handleSaveUser = async (target: UserProfile) => {
    if (!firebaseUser) return;
    const draft = userEdits[target.uid];
    if (!draft) return;
    setError(null);
    try {
      await adminUpdateUser(target.uid, target.email, firebaseUser.uid, draft);
      setStatusMsg(`Updated ${target.email}`);
      setTimeout(() => setStatusMsg(null), 2000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user.');
    }
  };

  const handleSavePlatform = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    setError(null);
    try {
      await savePlatformConfig({
        activeModel,
        announcement,
        announcementActive,
        defaultMonthlyLimit: defaultLimit,
        disabledTools,
        enabledLanguages,
      });
      setStatusMsg('Platform configuration saved.');
      setTimeout(() => setStatusMsg(null), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save platform settings.');
    } finally {
      setSavingConfig(false);
    }
  };

  const toggleDisabledTool = (toolId: string) => {
    setDisabledTools((prev) => (prev.includes(toolId) ? prev.filter((x) => x !== toolId) : [...prev, toolId]));
  };

  const toggleEnabledLang = (code: string) => {
    setEnabledLanguages((prev) => {
      if (prev.includes(code)) {
        return prev.length > 1 ? prev.filter((x) => x !== code) : prev;
      }
      return [...prev, code];
    });
  };

  const handleSelectProviderTab = (prov: 'groq' | 'openai' | 'gemini') => {
    setSelectedProvider(prov);
    const defaultForProv =
      serverHealth?.providers?.[prov]?.model ||
      (prov === 'groq' ? liveGroqModels[0] || 'openai/gpt-oss-20b' : prov === 'openai' ? 'gpt-6.2-sol' : 'gemini-4-hydrogen');
    setSelectedProviderModel(defaultForProv);
    if (selectedFallback === prov) {
      setSelectedFallback('');
    }
  };

  const handleApplyProviderSwitch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setSwitchingProvider(true);
    setError(null);
    try {
      const token = await firebaseUser.getIdToken();
      const res = await fetch('/api/ai/provider', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          provider: selectedProvider,
          model: selectedProviderModel.trim() || undefined,
          fallbackProvider: selectedFallback || null,
        }),
      });
      const payload = await res.json().catch(() => null);
      if (!res.ok) {
        throw new Error(typeof payload?.error === 'string' ? payload.error : `Failed to switch provider (HTTP ${res.status}).`);
      }
      if (!payload || typeof payload.provider !== 'string') {
        throw new Error('Server returned an unexpected response while switching AI provider.');
      }
      invalidateAiHealthCache();
      setServerHealth(payload);
      setSelectedProvider(payload.provider);
      setSelectedProviderModel(payload.model || '');
      setSelectedFallback(payload.fallbackProvider || '');
      setStatusMsg(`Active AI_PROVIDER switched to ${String(payload.provider).toUpperCase()} (${payload.model}).`);
      setTimeout(() => setStatusMsg(null), 3000);
      await loadAiProviderState();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to switch AI provider.');
    } finally {
      setSwitchingProvider(false);
    }
  };

  const totalTokens = logs.reduce((acc, l) => acc + (l.tokens || 0), 0);
  const errorLogs = logs.filter((l) => l.status === 'error');
  const visibleLogs = showErrorsOnly ? errorLogs : logs;

  const providerMetaList: {
    key: 'groq' | 'openai' | 'gemini';
    label: string;
    configured: boolean;
    models: string[];
  }[] = [
    {
      key: 'groq',
      label: 'Groq',
      configured: Boolean(serverHealth?.groqConfigured),
      models: liveGroqModels,
    },
    {
      key: 'openai',
      label: 'OpenAI',
      configured: Boolean(serverHealth?.openaiConfigured),
      models: ['gpt-6.2-sol', 'gpt-6.2-astra'],
    },
    {
      key: 'gemini',
      label: 'Google Gemini',
      configured: Boolean(serverHealth?.geminiConfigured),
      models: ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'],
    },
  ];

  const activeProviderModels =
    providerMetaList.find((p) => p.key === selectedProvider)?.models || [];

  const logBreakdown = (['groq', 'openai', 'gemini'] as const).map((prov) => {
    const label = prov.toUpperCase();
    const matching = logs.filter((l) => splitProviderModel(l.model).provider === label);
    const serverStat = providerUsage?.[prov];
    return {
      key: prov,
      label,
      configured:
        prov === 'groq'
          ? Boolean(serverHealth?.groqConfigured)
          : prov === 'openai'
            ? Boolean(serverHealth?.openaiConfigured)
            : Boolean(serverHealth?.geminiConfigured),
      logRequests: matching.length,
      logTokens: matching.reduce((sum, l) => sum + (l.tokens || 0), 0),
      logErrors: matching.filter((l) => l.status === 'error').length,
      serverStat,
    };
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Analytics Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> Registered Users</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{users.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 flex items-center gap-1.5"><Activity className="w-3.5 h-3.5" /> Logged AI Requests</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{logs.length}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500">Total Tokens</p>
          <p className="mt-1 text-2xl font-bold tabular-nums">{totalTokens.toLocaleString()}</p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs text-slate-500 flex items-center gap-1.5"><AlertCircle className="w-3.5 h-3.5" /> System Errors</p>
          <p className="mt-1 text-2xl font-bold text-red-600 tabular-nums">{errorLogs.length}</p>
        </div>
      </div>

      {statusMsg && (
        <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-xl px-4 py-3 text-xs text-emerald-700 dark:text-emerald-300">
          {statusMsg}
        </div>
      )}
      {error && (
        <div className="bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl px-4 py-3 text-xs text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {/* AI Provider Settings */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-1">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-600" />
              AI Provider Settings
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Current <span className="font-mono font-semibold">AI_PROVIDER</span>:{' '}
              <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                {serverHealth ? serverHealth.provider.toUpperCase() : 'LOADING...'}
              </span>
              {serverHealth && (
                <>
                  {' · '}Model: <span className="font-mono">{serverHealth.model}</span>
                  {' · '}Env Default:{' '}
                  <span className="font-mono">
                    {serverHealth.envProvider ? serverHealth.envProvider.toUpperCase() : 'AUTO'}
                  </span>
                  {' · '}Fallback:{' '}
                  <span className="font-mono">
                    {serverHealth.fallbackProvider ? serverHealth.fallbackProvider.toUpperCase() : 'NONE'}
                  </span>
                </>
              )}
            </p>
          </div>
          <button
            type="button"
            onClick={() => void loadAiProviderState()}
            disabled={refreshingAi}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshingAi ? 'animate-spin' : ''}`} />
            Refresh Status & Usage
          </button>
        </div>

        <form onSubmit={handleApplyProviderSwitch} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {providerMetaList.map((p) => {
              const isSelected = selectedProvider === p.key;
              const isLive = serverHealth?.provider === p.key;
              return (
                <button
                  key={p.key}
                  type="button"
                  disabled={!p.configured}
                  onClick={() => handleSelectProviderTab(p.key)}
                  className={`text-left p-4 rounded-xl border transition-colors ${
                    !p.configured
                      ? 'opacity-60 cursor-not-allowed bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                      : isSelected
                        ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/30 cursor-pointer'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm text-slate-900 dark:text-slate-100">{p.label}</span>
                    <span
                      className={`text-[11px] font-mono font-semibold ${
                        p.configured ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {p.configured ? (isLive ? 'ACTIVE' : 'CONFIGURED') : 'NO API KEY'}
                    </span>
                  </div>
                  <p className="mt-1 text-xs font-mono text-slate-500 truncate">
                    Model: {serverHealth?.providers?.[p.key]?.model || p.models[0]}
                  </p>
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Model for {selectedProvider.toUpperCase()}
              </label>
              <select
                value={activeProviderModels.includes(selectedProviderModel) ? selectedProviderModel : '__custom__'}
                onChange={(e) => {
                  if (e.target.value !== '__custom__') {
                    setSelectedProviderModel(e.target.value);
                  }
                }}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                {activeProviderModels.map((mId) => (
                  <option key={mId} value={mId}>
                    {mId}
                  </option>
                ))}
                {!activeProviderModels.includes(selectedProviderModel) && selectedProviderModel && (
                  <option value="__custom__">{selectedProviderModel} (custom)</option>
                )}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">Explicit Fallback Provider</label>
              <select
                value={selectedFallback}
                onChange={(e) => setSelectedFallback(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
              >
                <option value="">None (No silent fallback)</option>
                {providerMetaList
                  .filter((p) => p.key !== selectedProvider && p.configured)
                  .map((p) => (
                    <option key={p.key} value={p.key}>
                      {p.label}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <button
                type="submit"
                disabled={switchingProvider || !providerMetaList.find((p) => p.key === selectedProvider)?.configured}
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                {switchingProvider ? 'Switching...' : `Switch Active Provider to ${selectedProvider.toUpperCase()}`}
              </button>
            </div>
          </div>
        </form>

        {/* Usage Statistics Per Provider */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Usage Statistics Per Provider (Unmixed)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {logBreakdown.map((item) => (
              <div
                key={item.key}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-mono text-blue-600 dark:text-blue-400">
                    {item.label}
                  </span>
                  <span
                    className={`text-[11px] font-semibold ${
                      serverHealth?.provider === item.key
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : item.configured
                          ? 'text-slate-500'
                          : 'text-slate-400'
                    }`}
                  >
                    {serverHealth?.provider === item.key ? 'ACTIVE' : item.configured ? 'READY' : 'UNCONFIGURED'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs tabular-nums">
                  <div>
                    <p className="text-slate-500">Session / Logged Req</p>
                    <p className="font-semibold">
                      {item.serverStat?.totalRequests ?? 0} / {item.logRequests}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-500">Success / Errors</p>
                    <p className="font-semibold">
                      <span className="text-emerald-600">{item.serverStat?.successCount ?? 0}</span>
                      {' / '}
                      <span className="text-red-500">{(item.serverStat?.errorCount ?? 0) + item.logErrors}</span>
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-500">In / Out Tokens</p>
                    <p className="font-mono">
                      {(item.serverStat?.inputTokens ?? 0).toLocaleString()} / {(item.serverStat?.outputTokens ?? 0).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-500">Total Tok / Avg Latency</p>
                    <p className="font-mono">
                      {((item.serverStat?.totalTokens ?? 0) || item.logTokens).toLocaleString()} / {item.serverStat?.avgDurationMs ?? 0}ms
                    </p>
                  </div>
                </div>
                {item.serverStat?.lastModel && (
                  <p className="text-[11px] font-mono text-slate-500 truncate">
                    Last model: {item.serverStat.lastModel}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Platform Config */}
      <form
        onSubmit={handleSavePlatform}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-5"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            AI Models, Languages, Tools & Announcements
          </h2>
          <button
            type="submit"
            disabled={savingConfig}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            {savingConfig ? 'Saving...' : 'Save Configuration'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Active AI Model</label>
            <select
              value={activeModel}
              onChange={(e) => setActiveModel(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <optgroup label="Groq Models">
                {liveGroqModels.map((mId) => (
                  <option key={mId} value={mId}>
                    Groq — {mId}
                  </option>
                ))}
              </optgroup>
              <optgroup label="OpenAI Models">
                <option value="gpt-6.2-sol">OpenAI — gpt-6.2-sol (Primary)</option>
                <option value="gpt-6.2-astra">OpenAI — gpt-6.2-astra (Advanced Reasoning)</option>
              </optgroup>
              <optgroup label="Google Gemini Models">
                <option value="gemini-4-hydrogen">Gemini — gemini-4-hydrogen (Primary)</option>
                <option value="gemini-3.1-flash-lite">Gemini — gemini-3.1-flash-lite (Fast)</option>
              </optgroup>
            </select>
            {serverHealth && (
              <p className="mt-1.5 text-[11px] text-slate-500 font-mono">
                Server active: {serverHealth.provider.toUpperCase()} / {serverHealth.model}
                {serverHealth.fallbackProvider ? ` (fallback: ${serverHealth.fallbackProvider.toUpperCase()})` : ''}
                {' · '}Groq: {serverHealth.groqConfigured ? 'ready' : 'not set'}
                {' · '}OpenAI: {serverHealth.openaiConfigured ? 'ready' : 'not set'}
                {' · '}Gemini: {serverHealth.geminiConfigured ? 'ready' : 'not set'}
              </p>
            )}
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Default Monthly Limit</label>
            <input
              type="number"
              min={1}
              value={defaultLimit}
              onChange={(e) => setDefaultLimit(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg tabular-nums"
            />
          </div>
          <div className="flex items-end pb-2">
            <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={announcementActive}
                onChange={(e) => setAnnouncementActive(e.target.checked)}
              />
              Show Platform Announcement Banner
            </label>
          </div>
        </div>

        <div>
          <label className="block text-xs text-slate-500 mb-1">Platform Announcement Text</label>
          <input
            value={announcement}
            onChange={(e) => setAnnouncement(e.target.value)}
            placeholder="System notice, exam season update, maintenance schedule..."
            className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">Enabled Languages</p>
            <div className="flex flex-wrap gap-2">
              {SUPPORTED_LANGUAGES.map((l) => {
                const enabled = enabledLanguages.includes(l.code);
                return (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => toggleEnabledLang(l.code)}
                    className={`px-3 py-1.5 text-xs rounded-lg border cursor-pointer ${
                      enabled
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-500 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {l.nativeName}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-2">
              Available Tools (Click to pause/enable)
            </p>
            <div className="flex flex-wrap gap-2">
              {TOGGLEABLE_TOOLS.map((tool) => {
                const disabled = disabledTools.includes(tool.id);
                return (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => toggleDisabledTool(tool.id)}
                    className={`px-2.5 py-1 text-xs rounded-lg border cursor-pointer ${
                      disabled
                        ? 'bg-red-50 dark:bg-red-950/40 text-red-600 border-red-300 dark:border-red-900 line-through'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {tool.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </form>

      {/* User & Subscription Management */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Users, Subscriptions & Quotas
        </h2>
        {loading ? (
          <p className="text-sm text-slate-500">Loading users...</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                  <th className="py-2 pr-3">User</th>
                  <th className="py-2 pr-3">Role</th>
                  <th className="py-2 pr-3">Plan</th>
                  <th className="py-2 pr-3">Usage / Limit</th>
                  <th className="py-2 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => {
                  const ed = userEdits[u.uid] || { role: u.role, plan: u.plan, aiMonthlyLimit: u.aiMonthlyLimit };
                  return (
                    <tr key={u.uid}>
                      <td className="py-2.5 pr-3">
                        <p className="font-semibold text-slate-900 dark:text-slate-100">{u.displayName}</p>
                        <p className="text-slate-500">{u.email}</p>
                      </td>
                      <td className="py-2.5 pr-3">
                        <select
                          value={ed.role}
                          onChange={(e) =>
                            setUserEdits({ ...userEdits, [u.uid]: { ...ed, role: e.target.value as UserRole } })
                          }
                          className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                        >
                          <option value="student">student</option>
                          <option value="researcher">researcher</option>
                          <option value="instructor">instructor</option>
                          <option value="admin">admin</option>
                        </select>
                      </td>
                      <td className="py-2.5 pr-3">
                        <select
                          value={ed.plan}
                          onChange={(e) =>
                            setUserEdits({
                              ...userEdits,
                              [u.uid]: { ...ed, plan: e.target.value as SubscriptionPlan },
                            })
                          }
                          className="px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
                        >
                          <option value="free">free</option>
                          <option value="pro">pro</option>
                          <option value="university">university</option>
                        </select>
                      </td>
                      <td className="py-2.5 pr-3 tabular-nums">
                        <span>{u.aiRequestsUsed} / </span>
                        <input
                          type="number"
                          value={ed.aiMonthlyLimit}
                          onChange={(e) =>
                            setUserEdits({
                              ...userEdits,
                              [u.uid]: { ...ed, aiMonthlyLimit: Number(e.target.value) || 100 },
                            })
                          }
                          className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded tabular-nums"
                        />
                      </td>
                      <td className="py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => void handleSaveUser(u)}
                          className="px-3 py-1 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded font-medium cursor-pointer"
                        >
                          Save
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* System Logs & Errors */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            System Usage & Error Logs
          </h2>
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={showErrorsOnly} onChange={(e) => setShowErrorsOnly(e.target.checked)} />
            Errors Only ({errorLogs.length})
          </label>
        </div>

        <div className="overflow-x-auto max-h-80">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2 pr-3">User</th>
                <th className="py-2 pr-3">Tool</th>
                <th className="py-2 pr-3">Provider</th>
                <th className="py-2 pr-3">Model</th>
                <th className="py-2 pr-3">Tokens</th>
                <th className="py-2">Status / Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {visibleLogs.map((l) => {
                const pm = splitProviderModel(l.model);
                return (
                  <tr key={l.id}>
                    <td className="py-2 pr-3 text-slate-600 dark:text-slate-300">{l.userEmail || l.userId}</td>
                    <td className="py-2 pr-3 font-mono">{l.tool}</td>
                    <td className="py-2 pr-3 font-mono font-semibold text-blue-600 dark:text-blue-400">
                      {pm.provider}
                    </td>
                    <td className="py-2 pr-3 font-mono text-slate-500">{pm.model}</td>
                    <td className="py-2 pr-3 tabular-nums">{l.tokens}</td>
                    <td className="py-2">
                      <span className={l.status === 'ok' ? 'text-emerald-600' : 'text-red-600 font-semibold'}>
                        {l.status}
                      </span>
                      {l.errorMessage && <span className="ml-2 text-red-500">{l.errorMessage}</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
