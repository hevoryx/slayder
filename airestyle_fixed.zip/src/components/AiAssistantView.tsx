import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowUpRight,
  Paperclip,
  Plus,
  Send,
  Trash2,
  X,
} from 'lucide-react';
import type { AssistantChat, ChatMessage, ModuleId } from '../../types';
import { useAuth } from '../context/AuthContext';
import { UI_STRINGS } from '../i18n/translations';
import { callAiApi } from '../services/aiClient';
import { parseUploadedFile, type ParsedUpload } from '../utils/fileParsers';
import { deleteChat, saveChat } from '../lib/firestoreService';

interface AiAssistantViewProps {
  chats: AssistantChat[];
  onNavigate: (module: ModuleId) => void;
}

export const AiAssistantView: React.FC<AiAssistantViewProps> = ({ chats, onNavigate }) => {
  const { firebaseUser, language, signInWithGoogle } = useAuth();
  const t = UI_STRINGS[language];

  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [explanationMode, setExplanationMode] = useState<'simple' | 'advanced'>('simple');
  const [rememberContext, setRememberContext] = useState(true);
  const [attachments, setAttachments] = useState<ParsedUpload[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (activeChatId) {
      const found = chats.find((c) => c.id === activeChatId);
      if (found) {
        setMessages(found.messages || []);
        setRememberContext(found.rememberContext);
      }
    }
  }, [activeChatId, chats]);

  const handleNewChat = () => {
    setActiveChatId(null);
    setMessages([]);
    setAttachments([]);
    setError(null);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = Array.from(e.target.files ?? []);
    setError(null);
    for (const f of files.slice(0, 3)) {
      try {
        const parsed = await parseUploadedFile(f);
        setAttachments((prev) => [...prev.slice(-2), parsed]);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to read file.');
      }
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() && attachments.length === 0) return;
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }

    const userMsg: ChatMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: input.trim() || `Analyze attached file(s): ${attachments.map((a) => a.fileName).join(', ')}`,
      mode: explanationMode,
      attachments: attachments.map((a) => ({
        name: a.fileName,
        mimeType: a.mimeType,
        textExcerpt: a.extractedText?.slice(0, 200),
      })),
      createdAt: new Date().toISOString(),
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput('');
    const currentAttachments = attachments;
    setAttachments([]);
    setLoading(true);
    setError(null);

    try {
      const resp = await callAiApi<{ reply: string; recommendedTool?: ModuleId }>(
        '/api/assistant/chat',
        {
          message: userMsg.text,
          history: rememberContext ? messages.slice(-8) : [],
          language,
          explanationMode,
          rememberContext,
          attachments: currentAttachments,
        },
        'assistant'
      );

      if (typeof resp?.reply !== 'string' || !resp.reply.trim()) {
        throw new Error('AI Assistant returned an empty response. Please try again.');
      }

      const aiMsg: ChatMessage = {
        id: `a_${Date.now()}`,
        role: 'assistant',
        text: resp.reply,
        mode: explanationMode,
        recommendedTool: resp?.recommendedTool,
        createdAt: new Date().toISOString(),
      };

      const finalMessages = [...nextMessages, aiMsg];
      setMessages(finalMessages);

      const savedId = await saveChat({
        id: activeChatId || '',
        isNew: !activeChatId,
        userId: firebaseUser.uid,
        title: userMsg.text.slice(0, 80),
        language,
        rememberContext,
        messages: finalMessages,
      });
      if (!activeChatId) setActiveChatId(savedId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Assistant request failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[calc(100vh-11rem)]">
      {/* Saved Chats Sidebar */}
      <aside className="lg:col-span-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 flex flex-col">
        <button
          type="button"
          onClick={handleNewChat}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity cursor-pointer whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          New Session
        </button>

        <div className="mt-4 space-y-1 flex-1 overflow-y-auto">
          {chats.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400 px-2 py-4">
              {t.common.empty}
            </p>
          ) : (
            chats.map((chat) => (
              <div
                key={chat.id}
                className={`flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg text-xs ${
                  activeChatId === chat.id
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                <button
                  type="button"
                  onClick={() => setActiveChatId(chat.id)}
                  className="flex-1 text-left truncate cursor-pointer"
                >
                  {chat.title}
                </button>
                <button
                  type="button"
                  aria-label="Delete conversation"
                  onClick={() => {
                    void deleteChat(chat.id);
                    if (activeChatId === chat.id) handleNewChat();
                  }}
                  className="p-1 text-slate-400 hover:text-red-600 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </aside>

      {/* Main Chat Canvas */}
      <section className="lg:col-span-9 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col">
        {/* Controls Toolbar */}
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {t.nav.assistant}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Supports PDF, DOCX, XLSX, PPTX, JPG, PNG · Never invents citations
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
              {(['simple', 'advanced'] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setExplanationMode(m)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    explanationMode === m
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {m === 'simple' ? 'Simple' : 'Advanced'}
                </button>
              ))}
            </div>

            <label className="inline-flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={rememberContext}
                onChange={(e) => setRememberContext(e.target.checked)}
                className="rounded border-slate-300"
              />
              Remember context
            </label>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 p-5 space-y-4 overflow-y-auto max-h-[540px]">
          {messages.length === 0 && (
            <div className="py-12 text-center max-w-lg mx-auto space-y-3">
              <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                Ask any academic question or attach lecture materials
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Explain formulas, summarize chapters, translate academic texts, or route straight into coursework, slides, math solver, or research tools.
              </p>
            </div>
          )}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-3xl rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user'
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200'
                }`}
              >
                {msg.attachments && msg.attachments.length > 0 && (
                  <p className="text-xs opacity-75 mb-1.5">
                    Attached: {msg.attachments.map((a) => a.name).join(', ')}
                  </p>
                )}
                {msg.text}
                {msg.recommendedTool && (
                  <div className="mt-3 pt-2 border-t border-slate-200 dark:border-slate-700">
                    <button
                      type="button"
                      onClick={() => onNavigate(msg.recommendedTool!)}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
                    >
                      Open {t.nav[msg.recommendedTool]}
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="text-sm text-slate-500 dark:text-slate-400">{t.common.generating}</div>
          )}
          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-lg text-xs text-red-700 dark:text-red-300">
              {error}
            </div>
          )}
        </div>

        {/* Composer */}
        <form onSubmit={handleSend} className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {attachments.map((att, idx) => (
                <span
                  key={`${att.fileName}_${idx}`}
                  className="inline-flex items-center gap-1.5 text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2.5 py-1 rounded-md"
                >
                  {att.fileName}
                  <button
                    type="button"
                    onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== idx))}
                    className="hover:text-red-600 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}
            </div>
          )}

          <div className="flex items-end gap-2">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.docx,.xlsx,.xls,.pptx,.txt,.md,.csv,.jpg,.jpeg,.png,.webp"
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title={t.common.uploadFile}
              className="p-2.5 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              <Paperclip className="w-4 h-4" />
            </button>
            <textarea
              rows={2}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question, paste a math problem, or attach a file..."
              className="flex-1 px-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 cursor-pointer inline-flex items-center gap-1.5 shrink-0 whitespace-nowrap"
            >
              <Send className="w-4 h-4" />
              Send
            </button>
          </div>
        </form>
      </section>
    </div>
  );
};
