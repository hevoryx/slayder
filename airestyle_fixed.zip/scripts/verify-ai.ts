import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import Groq from 'groq-sdk';
import OpenAI from 'openai';
import {
  executeAiRequest,
  executeAiStreamRequest,
  getAiHealthStatus,
  getProvider,
  resetRuntimeProviderConfig,
  resolveFallbackProviderName,
  resolvePrimaryProviderName,
  setRuntimeProviderConfig,
} from '../src/server/ai/aiProviderFactory.ts';
import { normalizeProviderError, parseStructuredJson, sanitizeErrorText } from '../src/server/ai/aiErrors.ts';
import { aiUsageTracker } from '../src/server/ai/aiUsageTracker.ts';
import { OpenAiProvider, toOpenAiStrictSchema } from '../src/server/ai/providers/openaiProvider.ts';
import { toGeminiSchema } from '../src/server/ai/providers/geminiProvider.ts';
import { GroqProvider, getGroqModelCapabilities } from '../src/server/ai/providers/groqProvider.ts';
import { registerAiRoutes, requireAdmin, type AuthRequest } from '../src/server/aiRoutes.ts';

async function withEnv(vars: Record<string, string | undefined>, fn: () => void | Promise<void>) {
  const prev: Record<string, string | undefined> = {};
  for (const k of Object.keys(vars)) {
    prev[k] = process.env[k];
    if (vars[k] === undefined) delete process.env[k];
    else process.env[k] = vars[k];
  }
  try {
    await fn();
  } finally {
    for (const k of Object.keys(vars)) {
      if (prev[k] === undefined) delete process.env[k];
      else process.env[k] = prev[k];
    }
  }
}

async function runTests() {
  console.log('1. Testing 3-provider selection (OpenAI, Gemini, Groq), model switching & explicit fallback...');
  await withEnv(
    {
      AI_PROVIDER: 'groq',
      GROQ_API_KEY: 'gsk_test_key',
      GROQ_MODEL: 'openai/gpt-oss-20b',
      OPENAI_API_KEY: undefined,
      GEMINI_API_KEY: undefined,
      AI_FALLBACK_PROVIDER: undefined,
    },
    () => {
      assert.equal(resolvePrimaryProviderName(), 'groq');
      assert.equal(resolveFallbackProviderName('groq'), null);
      const h = getAiHealthStatus();
      assert.equal(h.provider, 'groq');
      assert.equal(h.model, 'openai/gpt-oss-20b');
      assert.equal(h.groqConfigured, true);
      assert.equal(h.openaiConfigured, false);
      assert.equal(h.geminiConfigured, false);
    }
  );

  await withEnv(
    {
      AI_PROVIDER: 'openai',
      OPENAI_API_KEY: 'sk-test',
      OPENAI_MODEL: 'gpt-6.2-astra',
      GROQ_API_KEY: 'gsk_test',
      GEMINI_API_KEY: undefined,
      AI_FALLBACK_PROVIDER: undefined,
    },
    () => {
      assert.equal(resolvePrimaryProviderName(), 'openai');
      assert.equal(getProvider('openai').getDefaultModel(), 'gpt-6.2-astra');
      assert.equal(getAiHealthStatus().model, 'gpt-6.2-astra');
    }
  );

  await withEnv(
    { AI_PROVIDER: 'gemini', OPENAI_API_KEY: 'sk-test', GEMINI_API_KEY: 'AIzaTest', GROQ_API_KEY: 'gsk_test' },
    () => {
      assert.equal(resolvePrimaryProviderName(), 'gemini');
      assert.equal(getAiHealthStatus().model, 'gemini-4-hydrogen');
    }
  );

  await withEnv({ AI_PROVIDER: undefined, OPENAI_API_KEY: undefined, GROQ_API_KEY: 'gsk_test', GEMINI_API_KEY: 'AIzaTest' }, () => {
    assert.equal(resolvePrimaryProviderName(), 'groq');
  });

  await withEnv({ AI_PROVIDER: undefined, OPENAI_API_KEY: undefined, GROQ_API_KEY: undefined, GEMINI_API_KEY: 'AIzaTest' }, () => {
    assert.equal(resolvePrimaryProviderName(), 'gemini');
  });

  await withEnv(
    { AI_PROVIDER: 'groq', GROQ_API_KEY: 'gsk_test', OPENAI_API_KEY: 'sk-test', AI_FALLBACK_PROVIDER: 'openai' },
    () => {
      assert.equal(resolveFallbackProviderName('groq'), 'openai');
    }
  );

  console.log('2. Testing Groq model capabilities, schema conversions & structured JSON...');
  const ossCaps = getGroqModelCapabilities('openai/gpt-oss-20b');
  assert.equal(ossCaps.supportsChat, true);
  assert.equal(ossCaps.supportsVision, false);
  assert.equal(ossCaps.supportsBrowserSearch, true);
  assert.equal(ossCaps.supportsStructuredOutput, true);
  assert.equal(ossCaps.supportsReasoningEffort, true);

  const scoutCaps = getGroqModelCapabilities('meta-llama/llama-4-scout-17b-16e-instruct');
  assert.equal(scoutCaps.supportsVision, true);
  assert.equal(scoutCaps.supportsStructuredOutput, true);
  assert.equal(scoutCaps.supportsBrowserSearch, false);

  const llama3Caps = getGroqModelCapabilities('llama-3.3-70b-versatile');
  assert.equal(llama3Caps.supportsStructuredOutput, false);
  assert.equal(llama3Caps.supportsJsonMode, true);
  assert.equal(llama3Caps.supportsVision, false);

  const whisperCaps = getGroqModelCapabilities('whisper-large-v3');
  assert.equal(whisperCaps.supportsChat, false);

  const sampleSchema = {
    type: 'object' as const,
    properties: {
      title: { type: 'string' as const },
      note: { type: 'string' as const },
      items: { type: 'array' as const, items: { type: 'string' as const } },
    },
    required: ['title'],
  };
  const strict = toOpenAiStrictSchema(sampleSchema);
  assert.equal(strict.additionalProperties, false);
  assert.deepEqual(strict.required, ['title', 'note', 'items']);
  const gemSchema = toGeminiSchema(sampleSchema);
  assert.ok(gemSchema.properties?.title);
  const parsed = parseStructuredJson<{ title: string; note?: string }>('```json\n{"title":"Ok","note":null}\n```', 'groq');
  assert.equal(parsed.title, 'Ok');
  assert.equal('note' in parsed, false);

  const proseWrapped = parseStructuredJson<{ outputText: string }>(
    'Here is your translation:\n{"outputText":"Salom dunyo"}\nDone.',
    'openai'
  );
  assert.equal(proseWrapped.outputText, 'Salom dunyo');

  assert.throws(
    () => parseStructuredJson('null', 'openai'),
    (err: unknown) => (err as { code?: string }).code === 'INVALID_STRUCTURED_OUTPUT'
  );
  assert.throws(
    () => parseStructuredJson('', 'openai'),
    (err: unknown) => (err as { code?: string }).code === 'INVALID_STRUCTURED_OUTPUT'
  );

  console.log('3. Testing Groq SDK integration (chat, structured JSON, browser_search citations, vision, streaming, model validation)...');
  await withEnv({ AI_PROVIDER: 'groq', GROQ_API_KEY: 'gsk_mock_secret', GROQ_MODEL: 'openai/gpt-oss-20b' }, async () => {
    const groqProv = new GroqProvider() as unknown as {
      clearModelCache: () => void;
      getClient: (timeoutMs: number) => Groq;
      generate: GroqProvider['generate'];
      generateStream: GroqProvider['generateStream'];
      listAvailableModels: GroqProvider['listAvailableModels'];
    };
    groqProv.clearModelCache();

    let lastParams: Record<string, unknown> | null = null;
    const availableModelList = [
      { id: 'openai/gpt-oss-20b', owned_by: 'openai' },
      { id: 'meta-llama/llama-4-scout-17b-16e-instruct', owned_by: 'meta' },
      { id: 'llama-3.3-70b-versatile', owned_by: 'meta' },
    ];

    groqProv.getClient = () =>
      ({
        models: {
          list: async () => ({ data: availableModelList }),
        },
        chat: {
          completions: {
            create: async (params: Record<string, unknown>) => {
              lastParams = params;
              if (params.stream) {
                return (async function* () {
                  yield { model: String(params.model), choices: [{ delta: { content: 'Salom, ' } }] };
                  yield {
                    model: String(params.model),
                    choices: [{ delta: { content: 'talaba!' } }],
                    x_groq: { usage: { prompt_tokens: 18, completion_tokens: 6, total_tokens: 24 } },
                  };
                })();
              }

              const hasTools = Array.isArray(params.tools) && params.tools.length > 0;
              return {
                id: 'chatcmpl-test',
                model: String(params.model),
                choices: [
                  {
                    index: 0,
                    finish_reason: 'stop',
                    message: {
                      role: 'assistant',
                      content: hasTools
                        ? 'Empirical macroeconomics study summary.'
                        : JSON.stringify({
                            title: 'Macroeconomics Coursework',
                            items: ['Introduction', 'Methodology', 'Practical Analysis'],
                          }),
                      ...(hasTools
                        ? {
                            executed_tools: [
                              {
                                index: 0,
                                type: 'browser_search',
                                arguments: '{}',
                                search_results: {
                                  results: [
                                    { title: 'IMF World Economic Outlook', url: 'https://www.imf.org/en/Publications/WEO' },
                                  ],
                                },
                                browser_results: [
                                  { title: 'Stat.uz Open Data', url: 'https://stat.uz/en/' },
                                ],
                              },
                            ],
                          }
                        : {}),
                    },
                  },
                ],
                usage: { prompt_tokens: 140, completion_tokens: 55, total_tokens: 195 },
              };
            },
          },
        },
      }) as unknown as Groq;

    // 3a. List live Groq models
    const models = await groqProv.listAvailableModels(true);
    assert.equal(models.length, 3);
    assert.equal(models[0].id, 'openai/gpt-oss-20b');

    // 3b. Structured JSON + reasoning_effort on openai/gpt-oss-20b
    const structResp = await groqProv.generate({
      taskType: 'document',
      systemInstruction: 'Write academic document JSON.',
      prompt: 'Generate outline for inflation analysis',
      reasoningEffort: 'medium',
      jsonSchema: { name: 'doc_test', schema: sampleSchema },
    });
    assert.equal(structResp.provider, 'groq');
    assert.equal(structResp.model, 'openai/gpt-oss-20b');
    assert.equal(structResp.usageStats.inputTokens, 140);
    assert.equal(structResp.usageStats.outputTokens, 55);
    assert.equal(structResp.usageStats.totalTokens, 195);
    assert.ok(typeof structResp.usageStats.durationMs === 'number');
    assert.equal((lastParams as { response_format?: { type: string } })?.response_format?.type, 'json_schema');
    assert.equal((lastParams as { reasoning_effort?: string })?.reasoning_effort, 'medium');

    // 3c. Browser search on openai/gpt-oss-20b + citation extraction
    const searchResp = await groqProv.generate({
      taskType: 'research',
      prompt: 'Find official macroeconomic indicators for Uzbekistan',
      useWebSearch: true,
    });
    assert.equal(searchResp.webSearchAvailable, true);
    assert.equal(searchResp.sources.length, 2);
    assert.equal(searchResp.sources[0].uri, 'https://stat.uz/en/');
    assert.equal(searchResp.sources[1].uri, 'https://www.imf.org/en/Publications/WEO');

    // 3d. Vision rejected honestly on non-vision model openai/gpt-oss-20b
    await assert.rejects(
      () =>
        groqProv.generate({
          taskType: 'reasoning',
          parts: [
            { inlineData: { mimeType: 'image/png', data: 'iVBORw0KGgo=' } },
            { text: 'Solve integral from image' },
          ],
        }),
      (err: unknown) =>
        (err as { code?: string; status?: number }).code === 'UNSUPPORTED_CAPABILITY' &&
        (err as { status?: number }).status === 422
    );

    // 3e. Vision succeeds with image_url on Llama 4 Scout
    const visionResp = await groqProv.generate({
      taskType: 'reasoning',
      modelOverride: 'meta-llama/llama-4-scout-17b-16e-instruct',
      parts: [
        { inlineData: { mimeType: 'image/png', data: 'iVBORw0KGgo=' } },
        { text: 'Solve x^2 - 9 = 0' },
      ],
      jsonSchema: { name: 'math_test', schema: sampleSchema },
    });
    assert.equal(visionResp.model, 'meta-llama/llama-4-scout-17b-16e-instruct');
    const sentMessages = (lastParams as { messages: Array<{ role: string; content: unknown }> }).messages;
    const userMsg = sentMessages.find((m) => m.role === 'user');
    assert.ok(Array.isArray(userMsg?.content));
    assert.equal((userMsg?.content as Array<{ type: string }>)[0].type, 'image_url');

    // 3f. Unavailable model rejected clearly
    await assert.rejects(
      () =>
        groqProv.generate({
          modelOverride: 'nonexistent/retired-model',
          prompt: 'Hello',
        }),
      (err: unknown) => (err as { code?: string }).code === 'MODEL_UNAVAILABLE'
    );

    // 3g. Streaming response works with token accumulation
    let streamed = '';
    const streamResp = await groqProv.generateStream(
      { taskType: 'chat', prompt: 'Greet student' },
      (d) => {
        streamed += d;
      }
    );
    assert.equal(streamed, 'Salom, talaba!');
    assert.equal(streamResp.text, 'Salom, talaba!');
    assert.equal(streamResp.usageStats.totalTokens, 24);
  });

  console.log('4. Testing OpenAI Responses API payload builder & usageStats...');
  await withEnv({ AI_PROVIDER: 'openai', OPENAI_API_KEY: 'sk-test-mock', OPENAI_MODEL: 'gpt-6.2-sol' }, async () => {
    const provider = new OpenAiProvider() as unknown as {
      getClient: (timeoutMs: number) => OpenAI;
      generate: OpenAiProvider['generate'];
    };
    provider.getClient = () =>
      ({
        responses: {
          create: async () => ({
            model: 'gpt-6.2-sol',
            output_text: '{"reply":"Assalomu alaykum","recommendedTool":"solver"}',
            usage: { input_tokens: 120, output_tokens: 45, total_tokens: 165 },
            output: [],
          }),
        },
      }) as unknown as OpenAI;

    const resp = await provider.generate({
      taskType: 'chat',
      prompt: 'Hello',
    });
    assert.equal(resp.provider, 'openai');
    assert.equal(resp.usageStats.totalTokens, 165);
    assert.ok(typeof resp.usageStats.durationMs === 'number');
  });

  console.log('5. Testing no-silent-fallback & separate per-provider usage tracking...');
  aiUsageTracker.reset();
  await withEnv(
    { AI_PROVIDER: 'groq', GROQ_API_KEY: undefined, OPENAI_API_KEY: 'sk-present', GEMINI_API_KEY: 'AIzaPresent', AI_FALLBACK_PROVIDER: undefined },
    async () => {
      await assert.rejects(
        () => executeAiRequest({ taskType: 'chat', prompt: 'Hello' }),
        (err: unknown) =>
          (err as { code?: string; provider?: string }).code === 'MISSING_API_KEY' &&
          (err as { provider?: string }).provider === 'groq'
      );
    }
  );
  const summary = aiUsageTracker.getSummary();
  assert.equal(summary.providers.groq.errorCount, 1);
  assert.equal(summary.providers.openai.totalRequests, 0);
  assert.equal(summary.providers.gemini.totalRequests, 0);

  // Also test streaming factory doesn't silently fall back
  await withEnv({ AI_PROVIDER: 'groq', GROQ_API_KEY: undefined, AI_FALLBACK_PROVIDER: undefined }, async () => {
    await assert.rejects(
      () => executeAiStreamRequest({ taskType: 'chat', prompt: 'Hello' }, () => {}),
      (err: unknown) => (err as { code?: string }).code === 'MISSING_API_KEY'
    );
  });

  console.log('6. Testing error normalization & secret redaction (OpenAI, Gemini, Groq)...');
  assert.equal(normalizeProviderError({ status: 401, message: 'Invalid API key gsk_1234567890abcdef' }, 'groq').code, 'INVALID_API_KEY');
  assert.equal(normalizeProviderError({ status: 429, message: 'Rate limit exceeded' }, 'groq').code, 'RATE_LIMIT');
  assert.equal(normalizeProviderError({ status: 404, message: 'model_decommissioned' }, 'groq').code, 'MODEL_UNAVAILABLE');
  assert.equal(normalizeProviderError(new Error('Request timed out'), 'groq').code, 'TIMEOUT');
  assert.equal(normalizeProviderError(new Error('fetch failed ECONNREFUSED'), 'groq').code, 'NETWORK_ERROR');
  assert.equal(normalizeProviderError(new SyntaxError('Unexpected token'), 'groq').code, 'INVALID_STRUCTURED_OUTPUT');

  const redacted = sanitizeErrorText(
    'Authorization: Bearer eyJhbGci.abc.xyz gsk_secretGroqKey12345678 sk-proj-abcdef1234567890 AIzaSyAbcdef1234567890 AQ.Abcdef1234567890xyz'
  );
  assert.equal(redacted.includes('gsk_'), false);
  assert.equal(redacted.includes('sk-proj'), false);
  assert.equal(redacted.includes('AIza'), false);
  assert.equal(redacted.includes('AQ.'), false);
  assert.equal(redacted.includes('eyJ'), false);

  console.log('7. Testing Express /api/health, auth enforcement on all AI endpoints...');
  const app = express();
  app.use(express.json());
  registerAiRoutes(app);

  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });

  try {
    const addr = server.address() as { port: number };
    const base = `http://127.0.0.1:${addr.port}`;

    await withEnv(
      {
        AI_PROVIDER: 'groq',
        GROQ_API_KEY: 'gsk_secret-never-leak',
        GROQ_MODEL: 'openai/gpt-oss-20b',
        OPENAI_API_KEY: 'sk-secret-never-leak',
        GEMINI_API_KEY: 'AIzaSecretNeverLeak',
      },
      async () => {
        const res = await fetch(`${base}/api/health`);
        assert.equal(res.status, 200);
        const body = (await res.json()) as Record<string, unknown>;
        assert.equal(body.ok, true);
        assert.equal(body.provider, 'groq');
        assert.equal(body.model, 'openai/gpt-oss-20b');
        assert.equal(body.groqConfigured, true);
        assert.equal(body.openaiConfigured, true);
        assert.equal(body.geminiConfigured, true);
        const raw = JSON.stringify(body);
        assert.equal(raw.includes('gsk_secret'), false);
        assert.equal(raw.includes('sk-secret'), false);
        assert.equal(raw.includes('AIzaSecret'), false);
      }
    );

    const protectedGetEndpoints = ['/api/ai/models', '/api/ai/usage', '/api/ai/provider'];
    for (const ep of protectedGetEndpoints) {
      const res = await fetch(`${base}${ep}`);
      assert.equal(res.status, 401, `GET ${ep} should require auth`);
    }

    const protectedPostEndpoints = [
      '/api/ai/provider',
      '/api/assistant/chat',
      '/api/assistant/chat/stream',
      '/api/documents/generate',
      '/api/documents/regenerate-section',
      '/api/presentation/plan',
      '/api/presentation/refine-slide',
      '/api/coursework/outline',
      '/api/coursework/part',
      '/api/solver/solve',
      '/api/analyzer/analyze',
      '/api/analyzer/ask',
      '/api/exam/generate',
      '/api/translate/process',
      '/api/research/explore',
      '/api/career/assist',
    ];
    for (const ep of protectedPostEndpoints) {
      const res = await fetch(`${base}${ep}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      assert.equal(res.status, 401, `POST ${ep} should require auth`);
    }
  } finally {
    server.close();
  }

  console.log('7b. Testing runtime AI provider switching & requireAdmin enforcement...');
  await withEnv(
    {
      AI_PROVIDER: 'gemini',
      GROQ_API_KEY: undefined,
      OPENAI_API_KEY: 'sk-test-switch',
      OPENAI_MODEL: 'gpt-6.2-astra',
      GEMINI_API_KEY: 'AIzaTestSwitch',
      AI_FALLBACK_PROVIDER: undefined,
    },
    () => {
      resetRuntimeProviderConfig();
      try {
        assert.equal(resolvePrimaryProviderName(), 'gemini');
        const switched = setRuntimeProviderConfig({
          provider: 'openai',
          model: 'gpt-6.2-sol',
          fallbackProvider: 'gemini',
        });
        assert.equal(switched.provider, 'openai');
        assert.equal(switched.envProvider, 'gemini');
        assert.equal(switched.model, 'gpt-6.2-sol');
        assert.equal(switched.fallbackProvider, 'gemini');

        assert.throws(
          () => setRuntimeProviderConfig({ provider: 'groq' }),
          (err: unknown) => (err as { code?: string }).code === 'MISSING_API_KEY'
        );

        assert.throws(
          () => setRuntimeProviderConfig({ provider: 'openai', model: 'bad model with spaces!' }),
          (err: unknown) => (err as { code?: string }).code === 'MODEL_UNAVAILABLE'
        );

        assert.throws(
          () => setRuntimeProviderConfig({ provider: 'gemini', model: 'ai' }),
          (err: unknown) => (err as { code?: string }).code === 'MODEL_UNAVAILABLE'
        );
      } finally {
        resetRuntimeProviderConfig();
      }
      assert.equal(resolvePrimaryProviderName(), 'gemini');
    }
  );

  // Direct requireAdmin middleware verification
  const createMockRes = () => {
    const res = {
      statusCode: 200,
      body: null as unknown,
      status(code: number) {
        this.statusCode = code;
        return this;
      },
      json(payload: unknown) {
        this.body = payload;
        return this;
      },
    };
    return res;
  };

  {
    let nextCalled = false;
    const res = createMockRes();
    await requireAdmin(
      { user: { uid: 'u1', email: 'student@example.edu', email_verified: true } } as unknown as AuthRequest,
      res as unknown as express.Response,
      () => {
        nextCalled = true;
      }
    );
    assert.equal(nextCalled, false);
    assert.equal(res.statusCode, 403);
  }

  {
    let nextCalled = false;
    const res = createMockRes();
    await requireAdmin(
      { user: { uid: 'u2', email: 'vickgang87@gmail.com', email_verified: true } } as unknown as AuthRequest,
      res as unknown as express.Response,
      () => {
        nextCalled = true;
      }
    );
    assert.equal(nextCalled, true);
  }

  await withEnv({ ADMIN_EMAILS: 'dean@university.uz' }, async () => {
    let nextCalled = false;
    const res = createMockRes();
    await requireAdmin(
      { user: { uid: 'u3', email: 'dean@university.uz', email_verified: true } } as unknown as AuthRequest,
      res as unknown as express.Response,
      () => {
        nextCalled = true;
      }
    );
    assert.equal(nextCalled, true);
  });

  console.log('8. Testing client & repository API key security...');
  const clientFiles = [
    'App.tsx',
    'index.tsx',
    'src/services/aiClient.ts',
    'src/components/ProfileAndAdminView.tsx',
    'services/geminiService.ts',
    'services/courseworkService.ts',
  ];
  for (const rel of clientFiles) {
    const content = fs.readFileSync(path.resolve(process.cwd(), rel), 'utf-8');
    assert.equal(content.includes('GROQ_API_KEY'), false, `${rel} must not reference GROQ_API_KEY`);
    assert.equal(content.includes('VITE_GROQ_API_KEY'), false, `${rel} must not reference VITE_GROQ_API_KEY`);
    assert.equal(content.includes('OPENAI_API_KEY'), false, `${rel} must not reference OPENAI_API_KEY`);
    assert.equal(content.includes('VITE_OPENAI_API_KEY'), false, `${rel} must not reference VITE_OPENAI_API_KEY`);
    assert.equal(content.includes('gsk_'), false, `${rel} must not contain any literal Groq key`);
  }

  const envExample = fs.readFileSync(path.resolve(process.cwd(), '.env.example'), 'utf-8');
  assert.equal(/AQ\.|AIza|sk-[A-Za-z0-9]|gsk_/.test(envExample), false, '.env.example must not contain secrets');

  console.log('ALL VERIFICATION CHECKS PASSED!');
}

runTests().catch((err) => {
  console.error('Verification failed:', err);
  process.exit(1);
});
