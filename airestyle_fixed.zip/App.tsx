import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  Calculator,
  Calendar,
  FileSearch,
  FileText,
  FolderOpen,
  GraduationCap,
  Languages,
  LayoutDashboard,
  Menu,
  Moon,
  Presentation,
  Shield,
  Sparkles,
  Zap,
  Sun,
  User,
  Wrench,
  X,
} from 'lucide-react';
import {
  SUPPORTED_LANGUAGES,
  type AcademicTask,
  type AssistantChat,
  type Language,
  type ModuleId,
  type StudyProgress,
  type WorkspaceItem,
} from './types';
import { useAuth } from './src/context/AuthContext';
import { UI_STRINGS } from './src/i18n/translations';
import { testConnection } from './src/lib/firebase';
import {
  subscribeChats,
  subscribeStudyProgress,
  subscribeTasks,
  subscribeWorkspaces,
} from './src/lib/firestoreService';
import { DashboardView } from './src/components/DashboardView';
import { AiAssistantView } from './src/components/AiAssistantView';
import { AcademicDocumentsView } from './src/components/AcademicDocumentsView';
import { PresentationsView } from './src/components/PresentationsView';
import { MathEconomicsSolverView } from './src/components/MathEconomicsSolverView';
import { DocumentAnalyzerView } from './src/components/DocumentAnalyzerView';
import { ExamSystemView } from './src/components/ExamSystemView';
import { TranslatorWritingView } from './src/components/TranslatorWritingView';
import { ResearchAssistantView } from './src/components/ResearchAssistantView';
import { PlannerView } from './src/components/PlannerView';
import { WorkspaceFilesView } from './src/components/WorkspaceFilesView';
import { StudyBoostView } from './src/components/StudyBoostView';
import { StudentToolsView } from './src/components/StudentToolsView';
import { AdminView, ProfileView } from './src/components/ProfileAndAdminView';

interface NavGroup {
  labelKey: 'workspace' | 'create' | 'solve' | 'utilities' | 'account';
  items: { id: ModuleId; icon: React.FC<{ className?: string }> }[];
}

const NAV_GROUPS: NavGroup[] = [
  {
    labelKey: 'workspace',
    items: [
      { id: 'dashboard', icon: LayoutDashboard },
      { id: 'assistant', icon: Sparkles },
      { id: 'workspace', icon: FolderOpen },
      { id: 'planner', icon: Calendar },
    ],
  },
  {
    labelKey: 'create',
    items: [
      { id: 'documents', icon: FileText },
      { id: 'presentations', icon: Presentation },
      { id: 'translator', icon: Languages },
    ],
  },
  {
    labelKey: 'solve',
    items: [
      { id: 'solver', icon: Calculator },
      { id: 'analyzer', icon: FileSearch },
      { id: 'exams', icon: GraduationCap },
      { id: 'research', icon: BookOpen },
    ],
  },
  {
    labelKey: 'utilities',
    items: [
      { id: 'studyboost', icon: Zap },
      { id: 'tools', icon: Wrench },
    ],
  },
  {
    labelKey: 'account',
    items: [{ id: 'profile', icon: User }],
  },
];

export default function App() {
  const {
    firebaseUser,
    profile,
    isAdmin,
    authReady,
    authError,
    clearAuthError,
    platformConfig,
    language,
    setLanguage,
    themeMode,
    toggleThemeMode,
    signInWithGoogle,
  } = useAuth();

  const t = UI_STRINGS[language];
  const [activeModule, setActiveModule] = useState<ModuleId>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [workspaces, setWorkspaces] = useState<WorkspaceItem[]>([]);
  const [tasks, setTasks] = useState<AcademicTask[]>([]);
  const [chats, setChats] = useState<AssistantChat[]>([]);
  const [studyProgress, setStudyProgress] = useState<StudyProgress[]>([]);
  const [loadedWorkspaceItem, setLoadedWorkspaceItem] = useState<WorkspaceItem | null>(null);

  useEffect(() => {
    void testConnection();
  }, []);

  useEffect(() => {
    if (!firebaseUser) {
      setWorkspaces([]);
      setTasks([]);
      setChats([]);
      setStudyProgress([]);
      return;
    }

    const unsubW = subscribeWorkspaces(firebaseUser.uid, setWorkspaces);
    const unsubT = subscribeTasks(firebaseUser.uid, setTasks);
    const unsubC = subscribeChats(firebaseUser.uid, setChats);
    const unsubS = subscribeStudyProgress(firebaseUser.uid, setStudyProgress);

    return () => {
      unsubW();
      unsubT();
      unsubC();
      unsubS();
    };
  }, [firebaseUser]);

  const handleNavigate = (mod: ModuleId) => {
    setActiveModule(mod);
    setMobileMenuOpen(false);
  };

  const handleOpenWorkspaceItem = (item: WorkspaceItem) => {
    setLoadedWorkspaceItem(item);
    if (item.type === 'document') {
      setActiveModule('documents');
    } else if (item.type === 'presentation') {
      setActiveModule('presentations');
    } else if (item.type === 'math') {
      setActiveModule('solver');
    } else if (item.type === 'research') {
      setActiveModule('research');
    } else {
      setActiveModule('workspace');
    }
    setMobileMenuOpen(false);
  };

  const availableLanguages = SUPPORTED_LANGUAGES.filter((l) =>
    platformConfig.enabledLanguages.includes(l.code)
  );

  const isToolDisabled = platformConfig.disabledTools.includes(activeModule);

  const renderSidebarNav = () => (
    <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
      {NAV_GROUPS.map((group) => (
        <div key={group.labelKey}>
          <p className="px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            {t.groups[group.labelKey]}
          </p>
          <div className="space-y-0.5">
            {group.items.map((item) => {
              const Icon = item.icon;
              const active = activeModule === item.id;
              const paused = platformConfig.disabledTools.includes(item.id);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
                    active
                      ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80'
                  }`}
                >
                  <span className="flex items-center gap-2.5 min-w-0">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{t.nav[item.id]}</span>
                  </span>
                  {paused && <span className="text-[10px] text-amber-500 shrink-0">Paused</span>}
                </button>
              );
            })}
            {group.labelKey === 'account' && isAdmin && (
              <button
                type="button"
                onClick={() => handleNavigate('admin')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${
                  activeModule === 'admin'
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80'
                }`}
              >
                <Shield className="w-4 h-4 shrink-0" />
                <span className="truncate">{t.nav.admin}</span>
              </button>
            )}
          </div>
        </div>
      ))}
    </nav>
  );

  const renderActiveView = () => {
    if (isToolDisabled) {
      return (
        <div className="max-w-lg mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-2">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
            Module Temporarily Paused
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            This module is currently paused by the platform administrator. Please try another tool or check back later.
          </p>
        </div>
      );
    }

    switch (activeModule) {
      case 'dashboard':
        return (
          <DashboardView
            onNavigate={handleNavigate}
            workspaces={workspaces}
            tasks={tasks}
            studyProgress={studyProgress}
            onOpenWorkspaceItem={handleOpenWorkspaceItem}
          />
        );
      case 'assistant':
        return <AiAssistantView chats={chats} onNavigate={handleNavigate} />;
      case 'documents':
        return <AcademicDocumentsView loadedWorkspaceItem={loadedWorkspaceItem} />;
      case 'presentations':
        return <PresentationsView loadedWorkspaceItem={loadedWorkspaceItem} />;
      case 'solver':
        return <MathEconomicsSolverView loadedWorkspaceItem={loadedWorkspaceItem} />;
      case 'analyzer':
        return <DocumentAnalyzerView />;
      case 'exams':
        return <ExamSystemView studyProgress={studyProgress} />;
      case 'translator':
        return <TranslatorWritingView />;
      case 'research':
        return <ResearchAssistantView loadedWorkspaceItem={loadedWorkspaceItem} />;
      case 'planner':
        return <PlannerView tasks={tasks} />;
      case 'workspace':
        return (
          <WorkspaceFilesView
            workspaces={workspaces}
            onOpenWorkspaceItem={handleOpenWorkspaceItem}
          />
        );
      case 'studyboost':
        return <StudyBoostView />;
      case 'tools':
        return <StudentToolsView />;
      case 'profile':
        return <ProfileView />;
      case 'admin':
        return <AdminView />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-30">
        <div className="h-16 px-5 flex items-center gap-2.5 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-display font-bold text-sm shrink-0">
            AI
          </div>
          <div className="min-w-0">
            <p className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
              {t.brandName}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
              Academic Ecosystem
            </p>
          </div>
        </div>
        {renderSidebarNav()}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-white dark:bg-slate-900 h-full flex flex-col border-r border-slate-200 dark:border-slate-800 z-10">
            <div className="h-16 px-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
              <span className="font-display text-sm font-bold">{t.brandName}</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {renderSidebarNav()}
          </aside>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* 3-Zone Top Bar */}
        <header className="sticky top-0 z-20 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur border-b border-slate-200 dark:border-slate-800 px-4 md:px-6 flex items-center justify-between gap-4">
          {/* Left: Hamburger + Module Title */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation"
              className="lg:hidden p-2 -ml-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display text-base md:text-lg font-semibold text-slate-900 dark:text-slate-100 truncate whitespace-nowrap">
              {t.nav[activeModule]}
            </h1>
          </div>

          {/* Center: Quick Top-Level Links */}
          <div className="hidden xl:flex items-center gap-1">
            {(['assistant', 'documents', 'presentations', 'solver', 'research'] as ModuleId[]).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => handleNavigate(id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  activeModule === id
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                }`}
              >
                {t.nav[id]}
              </button>
            ))}
          </div>

          {/* Right: Language + Theme + Auth */}
          <div className="flex items-center gap-2 shrink-0">
            <select
              aria-label="Select language"
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="px-2.5 py-1.5 text-xs font-medium bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
            >
              {availableLanguages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label} · {lang.nativeName}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={toggleThemeMode}
              aria-label="Toggle light or dark theme"
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer shrink-0"
            >
              {themeMode === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {authReady && (
              firebaseUser ? (
                <button
                  type="button"
                  onClick={() => handleNavigate('profile')}
                  className="inline-flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-medium cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[11px] font-bold">
                    {(profile?.displayName || firebaseUser.email || 'U').slice(0, 1).toUpperCase()}
                  </span>
                  <span className="hidden sm:inline max-w-[110px] truncate">
                    {profile?.displayName || 'Account'}
                  </span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => void signInWithGoogle()}
                  className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {t.auth.signInGoogle}
                </button>
              )
            )}
          </div>
        </header>

        {authError && (
          <div className="mx-4 md:mx-6 mt-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl px-4 py-2.5 text-xs text-red-700 dark:text-red-300 flex items-start justify-between gap-3">
            <span>{authError}</span>
            <button
              type="button"
              onClick={clearAuthError}
              aria-label="Dismiss authentication message"
              className="p-0.5 rounded hover:bg-red-100 dark:hover:bg-red-900/40 shrink-0 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <main className="flex-1 p-4 md:p-6">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
